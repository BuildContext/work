import 'package:test_project/core/models/user_profile_data.dart';

/// [_ProfileRepository] is an abstraction of profile capabilities in the app
abstract class _ProfileRepository {
  Future<UserProfileData> loadProfileData();
}

class ProfileService extends _ProfileRepository {
  ProfileService._();

  static ProfileService get instance => ProfileService._();

  @override
  Future<UserProfileData> loadProfileData() async {
    await Future.delayed(Duration(seconds: 2));
    return UserProfileData(
      name: 'somebody',
      surname: 'somebody',
      phone: '+998 (91) 297 82 93',
      email: 'donikmurodkulov98@gmail.com',
      age: 23,
      gender: 'M',
      nationality: 'Uzbek',
      country: 'Tashkent, Uzbekistan',
      height: 179,
      weight: 65,
      birthDay: DateTime(1998, 12, 25, 4, 23, 0, 0, 0),
    );
  }
}
