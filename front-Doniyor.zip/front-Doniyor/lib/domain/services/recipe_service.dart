import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/category_models.dart';
import 'package:test_project/core/models/recipe_category_item.dart';
import 'package:test_project/core/models/recipe_model.dart';
import 'package:test_project/data/ayumeal_api.dart';
import 'package:test_project/data/failure.dart';
import 'package:test_project/tools/mixins/quiz_mixin.dart';

/// [_RecipeRepository] is an abstraction layer that provides access to recipe related APIs

abstract class _RecipeRepository {
  Future<RecipeCategory> getOtherRecommendations();
  Future<RecipeCategoryItem> loadRecipeById(int id);
  Future<Either<RequestFailure, RecipeModel>> loadRecipes({
    required int page,
    required int size,
  });
}

/// [RecipeService] is an implementation of access to recipe related APIs

class RecipeService with QuizMixin implements _RecipeRepository {
  RecipeService._();

  static RecipeService get instance => RecipeService._();

  /// [getOtherRecommendations] loads recommended stuff for recipe at the bottom of the screen

  @override
  Future<RecipeCategory> getOtherRecommendations() async {
    await Future.delayed(Duration(seconds: 1));
    final popularRecipeItems = List<RecipeCategoryItem>.generate(
      5,
      (index) => RecipeCategoryItem(
        id: (index * 123).toString(),
        categoryName: 'Popular',
        isLiked: false,
        title: 'generated title ${index++}',
        description: 'sdgsdfsfb dsfbdfbdsfbd sfbdfsbdfbdfbd fbdfbgfnfgnf gnfgnfnf\nnndfndfdbsdvasdgdfk jhagjsaoidjsdvis djvisodjvsdi',
        time: Duration(minutes: ++index * 2),
        icons: [
          ContentCategoryIcon(iconPath: 'ether', isLocal: true),
          ContentCategoryIcon(iconPath: 'morning', isLocal: true),
          ContentCategoryIcon(iconPath: 'winter', isLocal: true),
        ],
        imageLink: 'imageLink',
        goodFor: [
          for (int i = 0; i < index; i++) ContentCategoryTag(title: 'title $index$index$index', iconLink: 'assets/svgs/leaf.svg'),
        ],
        protein: 120,
        steps: [
          for (int i = 0; i < 4; i++)
            RecipeStep(
              stepOrderNumber: i,
              title: 'Step $i',
              description: 'dvdvdvnjsnjdvnkjdvs  jsds jnk dsnkj sfdjnk sfdjnk sdfnjk sdfnjk',
              ingredients: List.generate(
                5,
                (index) => FoodElement(title: 'title ${index++}', measurementType: 'g', amount: 123),
              ),
            ),
        ],
        isAdded: ++index % 2 == 0,
        secondaryIngredients: [
          for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
        ],
        primaryIngredients: [
          for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
        ],
        badFor: [
          for (int i = 0; i < index; i++) ContentCategoryTag(title: 'title $index$index$index', iconLink: 'assets/svgs/leaf.svg'),
        ],
        fibre: 120,
        salt: 120,
        fats: 120,
        stepsTitle: '',
        fatsList: [
          for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
        ],
        carbohydratesList: [
          for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
        ],
        calories: 120,
        carbohydrates: 120,
      ),
    );

    final popularRecipes = RecipeCategory(
      name: 'Recommendations',
      items: popularRecipeItems,
      subCategories: [],
    );
    return popularRecipes;
  }

  /// [loadRecipeById] loads recipe data by its id

  @override
  Future<RecipeCategoryItem> loadRecipeById(int id) async {
    await Future.delayed(Duration(seconds: 1), () {});
    return RecipeCategoryItem(
      id: 123.toString(),
      categoryName: 'Popular',
      isLiked: false,
      title: 'generated title 123',
      description: 'sdgsdfsfb dsfbdfbdsfbd sfbdfsbdfbdfbd fbdfbgfnfgnf gnfgnfnf\nnndfndfdbsdvasdgdfk jhagjsaoidjsdvis djvisodjvsdi',
      time: Duration(minutes: 123),
      icons: [
        ContentCategoryIcon(iconPath: 'ether', isLocal: true),
        ContentCategoryIcon(iconPath: 'morning', isLocal: true),
        ContentCategoryIcon(iconPath: 'winter', isLocal: true),
      ],
      imageLink: 'imageLink',
      goodFor: [
        for (int i = 0; i < 3; i++) ContentCategoryTag(title: 'title $i$i$i', iconLink: 'assets/svgs/leaf.svg'),
      ],
      protein: 120,
      steps: [
        for (int i = 0; i < 4; i++)
          RecipeStep(
            stepOrderNumber: i,
            title: 'Step $i',
            description: 'dvdvdvnjsnjdvnkjdvs  jsds jnk dsnkj sfdjnk sfdjnk sdfnjk sdfnjk',
            ingredients: List.generate(
              5,
              (index) => FoodElement(title: 'title ${index++}', measurementType: 'g', amount: 123),
            ),
          ),
      ],
      isAdded: false,
      secondaryIngredients: [
        for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
      ],
      primaryIngredients: [
        for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
      ],
      badFor: [
        for (int i = 0; i < 3; i++) ContentCategoryTag(title: 'title $i$i$i', iconLink: 'assets/svgs/leaf.svg'),
      ],
      fibre: 120,
      salt: 120,
      fats: 120,
      stepsTitle: '',
      fatsList: [
        for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
      ],
      carbohydratesList: [
        for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
      ],
      calories: 120,
      carbohydrates: 120,
    );
  }

  @override
  Future<Either<RequestFailure, RecipeModel>> loadRecipes({
    required int page,
    required int size,
  }) async {
    return await Task<RecipeModel>(() => ApiClient.instance.getRecipes(page, size))
        .attempt()
        .map((a) => a.leftMap((l) {
              if (l is DioError) {
                return RequestFailure(error: l.message, code: l.response?.statusCode ?? 0);
              }
              return RequestFailure(error: l.toString(), code: 0);
            }))
        .run();
  }
}
