import 'package:dio/dio.dart';
import 'package:html/parser.dart';

class NamasteService {
  NamasteService._();

  final Dio _dio = Dio();

  static NamasteService get instance => NamasteService._();

  final String htmlDocUrl = 'https://wisdomquotes.com/life-quotes/';

  Future<QuoteModel> getQuoteFromHtmlDoc() async {
    final doc = await _dio.request(htmlDocUrl);
    final namastesText = parse(doc.data.toString()).querySelectorAll('.entry-content > blockquote > p');
    // final namastesImages = parse(doc.data.toString()).querySelectorAll('.lazyloaded');
    final randomIndex = DateTime.now().millisecondsSinceEpoch % namastesText.length;
    String quote = namastesText.elementAt(randomIndex).innerHtml;
    final hasSpecialSymbol = quote.contains('<');
    if (hasSpecialSymbol) {
      final quoteString = quote.split('<').first;
      final author = quote.substring(quote.indexOf('>') + 1, quote.lastIndexOf('<'));
      return QuoteModel(
        quote: quoteString,
        author: author,
      );
    } else {
      return QuoteModel(
        quote: quote.substring(0, quote.lastIndexOf('.')),
        author: quote.split('.').last,
      );
    }
  }
}

class QuoteModel {
  final String quote;
  final String author;

  factory QuoteModel.empty() => QuoteModel(quote: '', author: '');

  QuoteModel({
    required this.quote,
    required this.author,
  });
}
