import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:test_project/core/models/youtube_video_details.dart';
import 'package:test_project/data/failure.dart';
import 'package:test_project/data/youtube_api.dart';

/// [_YoutubeRepository] represents authorized Youtube APIs in the app
abstract class _YoutubeRepository {
  Future<Either<RequestFailure, YoutubeVideoDetails>> getVideoDetails(String url);
}

class YoutubeService implements _YoutubeRepository {
  YoutubeService._();

  static YoutubeService get instance => YoutubeService._();

  @override
  Future<Either<RequestFailure, YoutubeVideoDetails>> getVideoDetails(String url) async {
    return await Task<YoutubeVideoDetails>(() => YoutubeApi.instance.getYoutubeVideoData(url))
        .attempt()
        .map((a) => a.leftMap((l) {
              if (l is DioError) {
                return RequestFailure(error: l.message, code: l.response?.statusCode ?? 0);
              }
              return RequestFailure(error: l.toString(), code: 0);
            }))
        .run();
  }
}
