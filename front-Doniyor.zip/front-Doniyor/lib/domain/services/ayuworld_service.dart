import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/category_models.dart';
import 'package:test_project/core/models/news_model.dart';
import 'package:test_project/core/models/post.dart';
import 'package:test_project/data/ayumeal_api.dart';
import 'package:test_project/data/failure.dart';
import 'package:test_project/tools/mixins/quiz_mixin.dart';

/// [_AyuworldRepository] is an abstraction layer for accessing external APIs

abstract class _AyuworldRepository {
  Future<Either<RequestFailure, NewsModel>> loadNews({
    required int page,
    required int size,
  });
  Future<Either<RequestFailure, NewsResult>> loadNewsById({required String id});
  Future<List<RecommendedReading>> loadReadings();
  Future<ContentCategory> loadRecommendedPosts();
}

/// [AyuworldService] is an implementation of accessing external APIs

class AyuworldService with QuizMixin implements _AyuworldRepository {
  AyuworldService._();

  static AyuworldService get instance => AyuworldService._();

  /// [loadNews] loads posts filtered by category for user
  @override
  Future<Either<RequestFailure, NewsModel>> loadNews({
    required int page,
    required int size,
  }) async {
    return await Task<NewsModel>(() => ApiClient.instance.getNews(page, size))
        .attempt()
        .map((a) => a.leftMap((l) {
              if (l is DioError) {
                return RequestFailure(error: l.message, code: l.response?.statusCode ?? 0);
              }
              return RequestFailure(error: l.toString(), code: 0);
            }))
        .run();
  }

  /// [loadReadings] loads recommended readings for user with post details

  @override
  Future<List<RecommendedReading>> loadReadings() async {
    await Future.delayed(Duration(seconds: 1), () {});
    return List.generate(
      5,
      (index) => RecommendedReading(
        heading: 'Sscasdvfd',
        description:
            'asldsln aklmdamslk mdgk lsmgklsmkldasnjakgngjkasndjkg nasgjk nas jkgans jdgk nas jdgn asjgn skadng kjads ngaskd g sajdgn asjdg nasdk jgnsaj',
        icons: [
          ContentCategoryIcon(iconPath: 'ether', isLocal: true),
          ContentCategoryIcon(iconPath: 'morning', isLocal: true),
          ContentCategoryIcon(iconPath: 'winter', isLocal: true),
        ],
        isLiked: false,
        hexColor: '#F7E9CD',
      ),
    );
  }

  /// [loadRecommendedPosts] loads recommended posts for current user

  @override
  Future<ContentCategory> loadRecommendedPosts() async {
    await Future.delayed(Duration(seconds: 1), () {});
    final recommendedItems = List.generate(
      5,
      (index) => PostCategoryItem(
        categoryName: 'Popular',
        id: (index * 123).toString(),
        author: PostAuthor(
          avatar: '',
          name: 'Name Surname',
          position: 'Position',
          description: 'avsdbfsffsdfgdfbgdvs vsds vsd sd vsd gdfgdsfgsdfvgdsvgf vsd gvsdfvg svdfg vsdfgvsdfvg',
        ),
        instructions: List.generate(
          ++index * 2,
          (index) => PostInstruction(
            time: Duration(minutes: ++index * 2),
            icons: [
              ContentCategoryIcon(iconPath: 'ether', isLocal: true),
              ContentCategoryIcon(iconPath: 'morning', isLocal: true),
              ContentCategoryIcon(iconPath: 'winter', isLocal: true),
            ],
            title: 'njklnkjvsnds nkjknjlnkljnjkl',
            imageLink: 'asvbfdngfhmg',
          ),
        ),
        isLiked: false,
        imageLink: 'recommendation',
        title: 'Generated title',
        description: 'asvsdjkdnfvjkdfnbkjdnfbkjdnfbjkndkjfbdfbfdbdfbdf\ndsvklndsbjlnfjlbnsdklnsdlvkm',
        time: Duration(minutes: index * (10 % ++index)),
        goodFor: List.generate(
          index * 2,
          (index) => ContentCategoryTag(title: 'title $index', iconLink: index % 2 == 0 ? 'assets/svgs/leaf.svg' : null),
        ),
        icons: [
          ContentCategoryIcon(iconPath: 'ether', isLocal: true),
          ContentCategoryIcon(iconPath: 'morning', isLocal: true),
          ContentCategoryIcon(iconPath: 'winter', isLocal: true),
        ],
      ),
    );
    return PostCategory(name: 'Recommendations', items: recommendedItems, subCategories: []);
  }

  Future<PostCategory> loadPostRelatedContent() async {
    await Future.delayed(Duration(seconds: 1), () {});

    final popularRecipeItems = List<PostCategoryItem>.generate(
      5,
      (index) => PostCategoryItem(
        categoryName: 'Popular',
        id: (index * 123).toString(),
        author: PostAuthor(
          avatar: '',
          name: 'Name Surname',
          position: 'Position',
          description: 'avsdbfsffsdfgdfbgdvs vsds vsd sd vsd gdfgdsfgsdfvgdsvgf vsd gvsdfvg svdfg vsdfgvsdfvg',
        ),
        instructions: List.generate(
          ++index * 2,
          (index) => PostInstruction(
            time: Duration(minutes: ++index * 2),
            icons: [
              ContentCategoryIcon(iconPath: 'ether', isLocal: true),
              ContentCategoryIcon(iconPath: 'morning', isLocal: true),
              ContentCategoryIcon(iconPath: 'winter', isLocal: true),
            ],
            title: 'njklnkjvsnds nkjknjlnkljnjkl',
            imageLink: 'asvbfdngfhmg',
          ),
        ),
        isLiked: false,
        title: 'generated title ${index++}',
        description: 'sdgsdfsfb dsfbdfbdsfbd sfbdfsbdfbdfbd fbdfbgfnfgnf gnfgnfnf\nnndfndfdbsdvasdgdfk jhagjsaoidjsdvis djvisodjvsdi',
        time: Duration(minutes: ++index * 2),
        goodFor: [
          for (int i = 0; i < index; i++) ContentCategoryTag(title: 'title $index$index$index', iconLink: 'assets/svgs/leaf.svg'),
        ],
        icons: [
          ContentCategoryIcon(iconPath: 'ether', isLocal: true),
          ContentCategoryIcon(iconPath: 'morning', isLocal: true),
          ContentCategoryIcon(iconPath: 'winter', isLocal: true),
        ],
        imageLink: 'imageLink',
      ),
    );

    return PostCategory(
      name: 'Popular recipes',
      items: popularRecipeItems,
      subCategories: [],
    );
  }

  /// [loadNewsById] loads news by id
  @override
  Future<Either<RequestFailure, NewsResult>> loadNewsById({required String id}) async {
    return await Task<NewsResult>(() => ApiClient.instance.getNewsById(id))
        .attempt()
        .map((a) => a.leftMap((l) {
              if (l is DioError) {
                return RequestFailure(error: l.message, code: l.response?.statusCode ?? 0);
              }
              return RequestFailure(error: l.toString(), code: 0);
            }))
        .run();
  }
}
