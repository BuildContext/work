import 'dart:math';

import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/category_models.dart';
import 'package:test_project/core/models/mealplan.dart';
import 'package:test_project/core/models/recipe_category_item.dart';

/// [_AyuplanRepository] is abstraction of AYULPAN capabilities in terms of APIs
abstract class _AyuplanRepository {
  Future<MealPlan> getMealPlan();
}

/// [AyuplanService] is implementation of AYUPLAN capabilities in terms of APIs
class AyuplanService extends _AyuplanRepository {
  AyuplanService._();

  static AyuplanService get instance => AyuplanService._();

  @override
  Future<MealPlan> getMealPlan() async {
    final list = await Future<MealPlan>.delayed(
      Duration(seconds: 1),
      () => MealPlan(
        breakfast: RecipeCategory(
          items: List<RecipeCategoryItem>.generate(
            2,
            (index) => RecipeCategoryItem(
              id: (index * 123).toString(),
              categoryName: 'Popular',
              isLiked: false,
              title: 'generated title ${index++}',
              description:
                  'sdgsdfsfb dsfbdfbdsfbd sfbdfsbdfbdfbd fbdfbgfnfgnf gnfgnfnf\nnndfndfdbsdvasdgdfk jhagjsaoidjsdvis djvisodjvsdi',
              time: Duration(minutes: ++index * 2),
              icons: [
                ContentCategoryIcon(iconPath: 'ether', isLocal: true),
                ContentCategoryIcon(iconPath: 'morning', isLocal: true),
                ContentCategoryIcon(iconPath: 'winter', isLocal: true),
              ],
              imageLink: 'imageLink',
              goodFor: [
                for (int i = 0; i < index; i++)
                  ContentCategoryTag(title: 'title $index$index$index', iconLink: 'assets/svgs/leaf.svg'),
              ],
              protein: 120,
              steps: [
                for (int i = 0; i < 4; i++)
                  RecipeStep(
                    stepOrderNumber: i,
                    title: 'Step $i',
                    description: 'dvdvdvnjsnjdvnkjdvs  jsds jnk dsnkj sfdjnk sfdjnk sdfnjk sdfnjk',
                    secondsToComplete: 20 * Random().nextInt(100),
                    temperature: 160,
                    ingredients: List.generate(
                      5,
                      (index) => FoodElement(title: 'title ${index++}', measurementType: 'g', amount: 123),
                    ),
                  ),
              ],
              isAdded: ++index % 2 == 0,
              secondaryIngredients: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              primaryIngredients: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              badFor: [
                for (int i = 0; i < index; i++)
                  ContentCategoryTag(title: 'title $index$index$index', iconLink: 'assets/svgs/leaf.svg'),
              ],
              fibre: 120,
              salt: 120,
              fats: 120,
              stepsTitle: '',
              fatsList: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              carbohydratesList: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              calories: 120,
              carbohydrates: 120,
            ),
          ),
          subCategories: [],
          name: 'breakfast',
        ),
        lunch: RecipeCategory(
          items: List<RecipeCategoryItem>.generate(
            2,
            (index) => RecipeCategoryItem(
              id: (index * 123).toString(),
              categoryName: 'Popular',
              isLiked: false,
              title: 'generated title ${index++}',
              description:
                  'sdgsdfsfb dsfbdfbdsfbd sfbdfsbdfbdfbd fbdfbgfnfgnf gnfgnfnf\nnndfndfdbsdvasdgdfk jhagjsaoidjsdvis djvisodjvsdi',
              time: Duration(minutes: ++index * 2),
              icons: [
                ContentCategoryIcon(iconPath: 'ether', isLocal: true),
                ContentCategoryIcon(iconPath: 'morning', isLocal: true),
                ContentCategoryIcon(iconPath: 'winter', isLocal: true),
              ],
              imageLink: 'imageLink',
              goodFor: [
                for (int i = 0; i < index; i++)
                  ContentCategoryTag(title: 'title $index$index$index', iconLink: 'assets/svgs/leaf.svg'),
              ],
              protein: 120,
              steps: [
                for (int i = 0; i < 4; i++)
                  RecipeStep(
                    stepOrderNumber: i,
                    title: 'Step $i',
                    description: 'dvdvdvnjsnjdvnkjdvs  jsds jnk dsnkj sfdjnk sfdjnk sdfnjk sdfnjk',
                    secondsToComplete: 20 * Random().nextInt(100),
                    temperature: 160,
                    ingredients: List.generate(
                      5,
                      (index) => FoodElement(title: 'title ${index++}', measurementType: 'g', amount: 123),
                    ),
                  ),
              ],
              isAdded: ++index % 2 == 0,
              secondaryIngredients: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              primaryIngredients: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              badFor: [
                for (int i = 0; i < index; i++)
                  ContentCategoryTag(title: 'title $index$index$index', iconLink: 'assets/svgs/leaf.svg'),
              ],
              fibre: 120,
              salt: 120,
              fats: 120,
              stepsTitle: '',
              fatsList: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              carbohydratesList: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              calories: 120,
              carbohydrates: 120,
            ),
          ),
          subCategories: [],
          name: 'lunch',
        ),
        snack: RecipeCategory(
          items: List<RecipeCategoryItem>.generate(
            2,
            (index) => RecipeCategoryItem(
              id: (index * 123).toString(),
              categoryName: 'Popular',
              isLiked: false,
              title: 'generated title ${index++}',
              description:
                  'sdgsdfsfb dsfbdfbdsfbd sfbdfsbdfbdfbd fbdfbgfnfgnf gnfgnfnf\nnndfndfdbsdvasdgdfk jhagjsaoidjsdvis djvisodjvsdi',
              time: Duration(minutes: ++index * 2),
              icons: [
                ContentCategoryIcon(iconPath: 'ether', isLocal: true),
                ContentCategoryIcon(iconPath: 'morning', isLocal: true),
                ContentCategoryIcon(iconPath: 'winter', isLocal: true),
              ],
              imageLink: 'imageLink',
              goodFor: [
                for (int i = 0; i < index; i++)
                  ContentCategoryTag(title: 'title $index$index$index', iconLink: 'assets/svgs/leaf.svg'),
              ],
              protein: 120,
              steps: [
                for (int i = 0; i < 4; i++)
                  RecipeStep(
                    stepOrderNumber: i,
                    title: 'Step $i',
                    description: 'dvdvdvnjsnjdvnkjdvs  jsds jnk dsnkj sfdjnk sfdjnk sdfnjk sdfnjk',
                    secondsToComplete: 20 * Random().nextInt(100),
                    temperature: 160,
                    ingredients: List.generate(
                      5,
                      (index) => FoodElement(title: 'title ${index++}', measurementType: 'g', amount: 123),
                    ),
                  ),
              ],
              isAdded: ++index % 2 == 0,
              secondaryIngredients: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              primaryIngredients: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              badFor: [
                for (int i = 0; i < index; i++)
                  ContentCategoryTag(title: 'title $index$index$index', iconLink: 'assets/svgs/leaf.svg'),
              ],
              fibre: 120,
              salt: 120,
              fats: 120,
              stepsTitle: '',
              fatsList: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              carbohydratesList: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              calories: 120,
              carbohydrates: 120,
            ),
          ),
          subCategories: [],
          name: 'snack',
        ),
        dinner: RecipeCategory(
          items: List<RecipeCategoryItem>.generate(
            2,
            (index) => RecipeCategoryItem(
              id: (index * 123).toString(),
              categoryName: 'Popular',
              isLiked: false,
              title: 'generated title ${index++}',
              description:
                  'sdgsdfsfb dsfbdfbdsfbd sfbdfsbdfbdfbd fbdfbgfnfgnf gnfgnfnf\nnndfndfdbsdvasdgdfk jhagjsaoidjsdvis djvisodjvsdi',
              time: Duration(minutes: ++index * 2),
              icons: [
                ContentCategoryIcon(iconPath: 'ether', isLocal: true),
                ContentCategoryIcon(iconPath: 'morning', isLocal: true),
                ContentCategoryIcon(iconPath: 'winter', isLocal: true),
              ],
              imageLink: 'imageLink',
              goodFor: [
                for (int i = 0; i < index; i++)
                  ContentCategoryTag(title: 'title $index$index$index', iconLink: 'assets/svgs/leaf.svg'),
              ],
              protein: 120,
              steps: [
                for (int i = 0; i < 4; i++)
                  RecipeStep(
                    stepOrderNumber: i,
                    title: 'Step $i',
                    description: 'dvdvdvnjsnjdvnkjdvs  jsds jnk dsnkj sfdjnk sfdjnk sdfnjk sdfnjk',
                    secondsToComplete: 20 * Random().nextInt(100),
                    temperature: 160,
                    ingredients: List.generate(
                      5,
                      (index) => FoodElement(title: 'title ${index++}', measurementType: 'g', amount: 123),
                    ),
                  ),
              ],
              isAdded: ++index % 2 == 0,
              secondaryIngredients: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              primaryIngredients: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              badFor: [
                for (int i = 0; i < index; i++)
                  ContentCategoryTag(title: 'title $index$index$index', iconLink: 'assets/svgs/leaf.svg'),
              ],
              fibre: 120,
              salt: 120,
              fats: 120,
              stepsTitle: '',
              fatsList: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              carbohydratesList: [
                for (int i = 0; i < 5; i++) FoodElement(title: 'title ${i++}', measurementType: 'g', amount: 123),
              ],
              calories: 120,
              carbohydrates: 120,
            ),
          ),
          subCategories: [],
          name: 'dinner',
        ),
      ),
    );
    return list;
  }
}
