import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

/// [_AuthRepository] is an abstraction layer of auth related APIs

abstract class _AuthRepository {
  Future<dynamic> loginWithGoogle();
  Future<void> loginWithFacebook();
  Future<void> loginWithApple();
  Future<void> logout();
}

/// [AuthService] is an implementation of auth related features
/// derived from [_AuthRepository] APIs

class AuthService extends _AuthRepository {
  AuthService._();

  GoogleSignIn _googleSignIn = GoogleSignIn();

  static AuthService get instance => AuthService._();

  @override
  Future<dynamic> loginWithGoogle() async {
    try {
      final googleUser = await GoogleSignIn().signIn();
      final googleUserAuth = await googleUser?.authentication;
      final credential = GoogleAuthProvider.credential(idToken: googleUserAuth?.idToken, accessToken: googleUserAuth?.accessToken);
      await FirebaseAuth.instance.signInWithCredential(credential);
      return true;
    } catch (e) {
      return e.toString();
    }
  }

  @override
  Future<void> loginWithApple() async {
    await Future.delayed(Duration(seconds: 1), () {});
  }

  @override
  Future<void> loginWithFacebook() async {
    await Future.delayed(Duration(seconds: 1), () {});
  }

  @override
  Future<void> logout() async {
    bool hasGoogleAccount = await _googleSignIn.isSignedIn();
    if (hasGoogleAccount) await _googleSignIn.signOut();
    if (FirebaseAuth.instance.currentUser?.uid != null) await FirebaseAuth.instance.signOut();
  }
}
