import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:test_project/core/models/ingredient.dart';
import 'package:test_project/data/ayumeal_api.dart';
import 'package:test_project/data/failure.dart';
import 'package:test_project/tools/mixins/suggested_titles_mixin.dart';

/// [_IngredientService] is an abstraction layer for accessing ingredients related APIs

abstract class _IngredientService {
  Future<Either<RequestFailure, Ingredient>> loadIngredients({
    required int page,
    required int size,
  });
  Future<Either<RequestFailure, IngredientResult>> loadIngredientById(String id);
}

class IngredientService with SuggestedTitlesMixin implements _IngredientService {
  IngredientService._();

  static IngredientService get instance => IngredientService._();

  @override
  Future<Either<RequestFailure, Ingredient>> loadIngredients({
    required int page,
    required int size,
  }) async {
    return await Task<Ingredient>(() => ApiClient.instance.getIngredients(page, size))
        .attempt()
        .map((a) => a.leftMap((l) {
              if (l is DioError)
                return RequestFailure(
                  error: l.message,
                  code: l.response?.statusCode ?? 0,
                );
              else
                return RequestFailure(error: 'error', code: 0);
            }))
        .run();
  }

  @override
  Future<Either<RequestFailure, IngredientResult>> loadIngredientById(String id) async {
    return await Task<IngredientResult>(() => ApiClient.instance.getIngredientById(id))
        .attempt()
        .map((a) => a.leftMap((l) {
              if (l is DioError)
                return RequestFailure(
                  error: l.message,
                  code: l.response?.statusCode ?? 0,
                );
              else
                return RequestFailure(error: 'error', code: 0);
            }))
        .run();
  }
}
