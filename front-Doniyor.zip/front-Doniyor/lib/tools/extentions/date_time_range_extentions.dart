import 'package:flutter/material.dart';

extension OffsetDays on DateTimeRange {
  DateTime getDayByOffsetIndex(int offsetDays) {
    final result = this.start.add(Duration(days: offsetDays));
    if (offsetDays == 0)
      return this.start;
    else if (result.isAfter(this.end))
      return this.end;
    else
      return result;
  }
}
