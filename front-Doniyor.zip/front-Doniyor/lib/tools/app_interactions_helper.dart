import 'package:flutter/material.dart';
import 'package:test_project/presentation/custom_widgets/blur_back_bottom_sheet_container.dart';
import 'package:test_project/presentation/custom_widgets/bottom_sheet_container.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';

class AppInteractionsHelper {
  AppInteractionsHelper._();

  static Future<dynamic> showBottomSheet({
    required BuildContext context,
    required Widget child,
    String? title,
    bool hasBlurBarrier = false,
    bool enableDrag = true,
    Color? color,
    Color? barrierColor,
  }) async {
    if (hasBlurBarrier)
      showModalBottomSheet(
        context: context,
        enableDrag: enableDrag,
        builder: (context) => Padding(
          padding: MediaQuery.of(context).viewInsets,
          child: BlurBackBottomSheetContainer(child: BottomSheetContainer(child: child, color: color, title: title)),
        ),
        isDismissible: false,
        isScrollControlled: true,
        barrierColor: barrierColor ?? Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: AppBorderRadius.borderRadiusOnlyTop16),
      );
    else
      showModalBottomSheet(
        context: context,
        enableDrag: enableDrag,
        builder: (context) => Padding(
          padding: MediaQuery.of(context).viewInsets,
          child: BottomSheetContainer(child: child, color: color, title: title),
        ),
        isDismissible: false,
        isScrollControlled: true,
        barrierColor: barrierColor ?? Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: AppBorderRadius.borderRadiusOnlyTop16),
      );
  }
}
