import 'package:test_project/core/models/ingredient.dart';

class ThreadFunctions {
  ThreadFunctions._();

  static List<String> deriveIngredientCategories(Ingredient item) {
    final list = List<String>.empty(growable: true);
    if (item.results == null || (item.results?.isEmpty ?? true)) return [];
    for (final item in item.results!) {
      if (!list.contains(item.classificationType?.title)) {
        if (item.classificationType?.title != null) {
          list.add(item.classificationType!.title!);
        }
      }
    }
    return list;
  }
}
