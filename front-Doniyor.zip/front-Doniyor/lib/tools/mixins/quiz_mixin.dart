import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/quiz.dart';
import 'package:test_project/core/models/quiz_option.dart';
import 'package:test_project/presentation/pages/quiz_pages/quiz_page_selector.dart';

mixin QuizMixin {
  /// [loadQuiz] loads quiz for user if needed

  Future<Quiz> loadQuiz() async {
    await Future.delayed(Duration(seconds: 1), () {});
    return Quiz(
      title: 'Quiz',
      description:
          'nvlsabdsfbdbsbadfbdsgbsfgnabj nk kjsjdkfs jhbf hjs db ghdbf ghjdb gjhsdbf gjh sdb gjhsdfb gjhdb aknsdj nlaks ndgkjdfsngjk dnfg kjasnd gkjsndgjkdfngkjdsngjkdsngkdjfsg jkdsfngjkdfngkjdsnfgk jdsnf gkj ndsfjk gndfjgk dnf gkjds nfgkj sndfk',
      icons: [
        ContentCategoryIcon(iconPath: 'sunset', isLocal: true),
        ContentCategoryIcon(iconPath: 'wind', isLocal: true),
      ],
      colorHex: '#F2E3E8',
      time: Duration(minutes: 50),
      options: List.generate(
        5,
        (index) => SelectableQuizOption(
          isSelected: false,
          title: 'title $index',
          value: index.toString(),
        ),
      ),
      type: QuizTypes.getByIndex(0),
    );
  }
}
