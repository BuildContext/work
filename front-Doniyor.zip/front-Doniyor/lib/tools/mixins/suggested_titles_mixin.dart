import 'package:test_project/core/models/suggested_title.dart';

class SuggestedTitlesMixin {
  Future<List<SuggestedTitle>> loadSuggestedTitles() async {
    await Future.delayed(Duration(seconds: 1));
    return List.generate(5, (index) => SuggestedTitle(title: 'asdafdgdfhg'));
  }
}
