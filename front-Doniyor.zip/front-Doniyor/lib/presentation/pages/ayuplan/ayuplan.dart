import 'dart:math';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/chart_models/mini_chart_data.dart';
import 'package:test_project/domain/services/auth_service.dart';
import 'package:test_project/presentation/custom_widgets/content_section.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/custom_widgets/dosha_card.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/custom_widgets/mealplan_recipe_card.dart';
import 'package:test_project/presentation/custom_widgets/quiz_card.dart';
import 'package:test_project/presentation/pages/ayuplan/cubit/ayuplan_cubit.dart';
import 'package:test_project/presentation/pages/ayuplan/cubit/ayuplan_state.dart';
import 'package:test_project/presentation/pages/ayuplan/widget/mini_stacked_chart.dart';
import 'package:test_project/presentation/pages/ayuplan/widget/mini_weekday_selector.dart';
import 'package:test_project/presentation/pages/ayuplan/widget/shopping_list_sheet.dart';
import 'package:test_project/presentation/pages/ayuworld/detailed_post_category/detailed_category_page.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

class AyuplanPage extends StatefulWidget {
  const AyuplanPage({Key? key}) : super(key: key);

  @override
  State<AyuplanPage> createState() => _AyuplanPageState();
}

class _AyuplanPageState extends State<AyuplanPage> {
  final cubit = AyuplanCubit();
  DateTime _currentDate = DateTime.now();
  DateTimeRange currentRange = DateTimeRange(
    start: DateTime.now(),
    end: DateTime.now().add(Duration(days: 6)),
  );

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance?.addPostFrameCallback((timeStamp) async {
      await cubit.loadData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ayuplan'),
        actions: [
          TextButton(
            onPressed: () => AuthService.instance.logout(),
            child: Text(
              'menu'.tr(),
              style: TypographyTwCenW01Medium.subtitle1,
            ),
          ),
        ],
      ),
      body: BlocConsumer<AyuplanCubit, AyuplanState>(
        bloc: cubit,
        listener: (context, state) {},
        builder: (context, state) {
          if (state is AyuplanLoading)
            return Loader();
          else if (state is AyuplanSuccess)
            return ListView(
              padding: AppInsets.horizontalInsets28,
              children: [
                AppSpacing.verticalSpace14,
                MiniWeekDaySelector(
                  initialWeek: currentRange,
                  onDayChosen: (day) => setState(() => _currentDate = day),
                ),
                AppSpacing.verticalSpace16,
                AppSpacing.verticalSpace10,
                Divider(),
                AppSpacing.verticalSpace14,
                Text(
                  'Ayu…?',
                  style: TypographyTwCenW01Medium.title3,
                ),
                AppSpacing.verticalSpace24,
                SizedBox(
                  height: 210,
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(
                        child: ProfileStatCard(
                          icon: Stack(
                            children: [
                              Image.asset('assets/pngs/lines/blue_line.png'),
                              Image.asset('assets/pngs/lines/pink_line.png'),
                              Center(child: Image.asset('assets/pngs/lines/slider.png')),
                              Center(child: Image.asset('assets/pngs/lines/slider_shadow.png')),
                              Image.asset('assets/pngs/lines/yellow_line.png'),
                            ],
                          ),
                          footer: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text('Kapha', style: TypographyNeueHaasUnicaW1G.basic2),
                              Text('10:45', style: TypographyNeueHaasUnicaW1G.menu3),
                            ],
                          ),
                          header: 'AYURTIME',
                        ),
                      ),
                      AppSpacing.horizontalSpace16,
                      Expanded(
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Expanded(
                              child: ProfileStatCard(
                                icon: MiniStackedChart(
                                  data: List<MiniChartDataSeries>.generate(
                                    7,
                                    (index) => MiniChartDataSeries(
                                      items: List.generate(
                                        3,
                                        (index) => MiniChartDataItem(
                                          color: index == 0
                                              ? AppColors.lavender
                                              : index == 1
                                                  ? AppColors.orangeLight
                                                  : AppColors.ice,
                                          percentage: min((0.33 - (Random().nextInt(100) / 100)).abs(), 0.33),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                header: '',
                                footer: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Text(
                                      'Thamasik',
                                      style: TypographyNeueHaasUnicaW1G.basic2,
                                    ),
                                    Text(
                                      'Weekly',
                                      style: TypographyNeueHaasUnicaW1G.menu3,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            AppSpacing.verticalSpace16,
                            Expanded(
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Expanded(
                                    child: ProfileStatCard(
                                      icon: Flexible(child: SvgPicture.asset('assets/svgs/pitta.svg')),
                                      header: 'dosha'.tr().toUpperCase(),
                                      footer: Text(
                                        'Thamasik',
                                        style: TypographyNeueHaasUnicaW1G.menu3,
                                      ),
                                    ),
                                  ),
                                  AppSpacing.horizontalSpace16,
                                  Expanded(
                                    child: ProfileStatCard(
                                      icon: Flexible(child: SvgPicture.asset('assets/svgs/rajas.svg')),
                                      header: 'dosha'.tr().toUpperCase(),
                                      footer: Text(
                                        'Thamasik',
                                        style: TypographyNeueHaasUnicaW1G.menu3,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                AppSpacing.verticalSpace24,
                Divider(),
                AppSpacing.verticalSpace14,
                Text('Mealplan', style: TypographyTwCenW01Medium.title3),
                AppSpacing.verticalSpace16,
                ContentSection(
                  titleStyle: TypographyTwCenW01Medium.subtitle2,
                  displayDivider: false,
                  displayTopSpacing: false,
                  title: state.mealPlan.breakfast.categoryName.toUpperCase(),
                  scrollDirection: Axis.vertical,
                  children: state.mealPlan.breakfast.items.map<Widget>((e) => MealplanRecipeCard(recipe: e, onTap: () {})).toList(),
                  onMore: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => DetailedCategoryPage(categoryId: state.mealPlan.breakfast.categoryName),
                    ),
                  ),
                ),
                ContentSection(
                  titleStyle: TypographyTwCenW01Medium.subtitle2,
                  displayDivider: false,
                  displayTopSpacing: false,
                  title: state.mealPlan.lunch.categoryName.toUpperCase(),
                  scrollDirection: Axis.vertical,
                  children: state.mealPlan.lunch.items.map<Widget>((e) => MealplanRecipeCard(recipe: e, onTap: () {})).toList(),
                  onMore: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => DetailedCategoryPage(
                        categoryId: state.mealPlan.lunch.categoryName,
                      ),
                    ),
                  ),
                ),
                ContentSection(
                  titleStyle: TypographyTwCenW01Medium.subtitle2,
                  displayDivider: false,
                  displayTopSpacing: false,
                  title: state.mealPlan.snack.categoryName.toUpperCase(),
                  scrollDirection: Axis.vertical,
                  children: state.mealPlan.snack.items.map<Widget>((e) => MealplanRecipeCard(recipe: e, onTap: () {})).toList(),
                  onMore: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => DetailedCategoryPage(
                        categoryId: state.mealPlan.snack.categoryName,
                      ),
                    ),
                  ),
                ),
                ContentSection(
                  titleStyle: TypographyTwCenW01Medium.subtitle2,
                  displayDivider: false,
                  displayTopSpacing: false,
                  title: state.mealPlan.dinner.categoryName.toUpperCase(),
                  scrollDirection: Axis.vertical,
                  children: state.mealPlan.dinner.items.map<Widget>((e) => MealplanRecipeCard(recipe: e, onTap: () {})).toList(),
                  onMore: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => DetailedCategoryPage(
                        categoryId: state.mealPlan.dinner.categoryName,
                      ),
                    ),
                  ),
                ),
                AppSpacing.verticalSpace24,
                CustomButton(
                  text: 'shopping_list'.tr(),
                  textStyle: TypographyNeueHaasUnicaW1G.buttonBold,
                  onTap: () => AppInteractionsHelper.showBottomSheet(
                    context: context,
                    child: ShoppingListSheet(mealPlan: state.mealPlan, initialWeek: currentRange),
                    color: Colors.white,
                    barrierColor: AppColors.oliveDark,
                  ),
                ),
                AppSpacing.verticalSpace24,
                QuizCard(quiz: state.quiz),
                AppSpacing.verticalSpace24,
              ],
            );
          else
            return Container();
        },
      ),
    );
  }
}

class AyurtimeChartData {
  final String name;
  final int value;

  AyurtimeChartData(this.name, this.value);
}
