import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/mealplan.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/pages/ayuplan/widget/calendar_sheet.dart';
import 'package:test_project/presentation/pages/ayuplan/widget/shopping_list_item_tile.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

class ShoppingListSheet extends StatefulWidget {
  final MealPlan mealPlan;
  final DateTimeRange initialWeek;

  const ShoppingListSheet({
    Key? key,
    required this.mealPlan,
    required this.initialWeek,
  }) : super(key: key);

  @override
  State<ShoppingListSheet> createState() => _ShoppingListSheetState();
}

class _ShoppingListSheetState extends State<ShoppingListSheet> {
  List<FoodElement> _ingredients = [];
  bool _isLoading = true;
  List<FoodElement> _selectedElements = [];
  DateTime? _selectedDate;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      final ingredientsList = await widget.mealPlan.getShoppingListFromMealplan();
      setState(() {
        _isLoading = false;
        _ingredients = ingredientsList;
        _selectedDate = widget.initialWeek.start;
      });
    });
  }

  void _addElement(FoodElement element) {
    if (_selectedElements.contains(element)) {
      _selectedElements.remove(element);
    } else {
      _selectedElements.add(element);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.7,
      width: MediaQuery.of(context).size.width,
      child: _isLoading
          ? Loader()
          : ListView(
              children: [
                AppSpacing.verticalSpace24,
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text('shopping_list'.tr(), style: TypographyTwCenW01Medium.title1),
                    Expanded(child: SizedBox()),
                    Text(
                      '${DateFormat(DateFormat.ABBR_MONTH_DAY).format(_selectedDate!)}',
                      style: TypographyTwCenW01Medium.subtitle2,
                    ),
                    AppSpacing.horizontalSpace8,
                    GestureDetector(
                      onTap: () => AppInteractionsHelper.showBottomSheet(
                        context: context,
                        child: CalendarSheet(selectedPeriod: widget.initialWeek),
                        color: Colors.white,
                        barrierColor: AppColors.oliveDark,
                      ),
                      child: SvgPicture.asset('assets/svgs/calendar.svg'),
                    ),
                  ],
                ),
                AppSpacing.verticalSpace24,
                Divider(),
                AppSpacing.verticalSpace14,
                ..._ingredients.map<Widget>(
                  (ingredient) => ShoppingListItemTile(
                    item: ingredient,
                    onSelected: (checked) {
                      final elementIndex = _ingredients.indexOf(ingredient);
                      if (elementIndex.isNegative) return;
                      _ingredients.removeAt(elementIndex);
                      _ingredients.insert(elementIndex, ingredient.copyWith(isChecked: checked));
                      setState(() {});
                    },
                  ),
                ),
              ],
            ),
    );
  }
}
