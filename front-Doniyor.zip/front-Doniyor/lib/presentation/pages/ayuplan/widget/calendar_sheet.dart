import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class CalendarSheet extends StatefulWidget {
  final DateTimeRange selectedPeriod;
  const CalendarSheet({
    Key? key,
    required this.selectedPeriod,
  }) : super(key: key);

  @override
  State<CalendarSheet> createState() => _CalendarSheetState();
}

class _CalendarSheetState extends State<CalendarSheet> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.6,
      width: MediaQuery.of(context).size.width,
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: [
              Text(
                DateFormat(DateFormat.MONTH).format(widget.selectedPeriod.start),
                style: TypographyTwCenW01Medium.title1,
              ),
              Text(
                '${DateFormat(DateFormat.DAY).format(widget.selectedPeriod.start)}-${DateFormat(DateFormat.DAY).format(widget.selectedPeriod.end)}',
                style: TypographyTwCenW01Medium.subtitle1,
              ),
            ],
          ),
          AppSpacing.verticalSpace20,
          Expanded(
            child: TableCalendar(
              locale: EasyLocalization.of(context)!.locale.languageCode,
              firstDay: DateTime.now(),
              lastDay: DateTime.now().add(Duration(days: 365)),
              focusedDay: DateTime.now(),
              headerVisible: false,
              onDaySelected: (day, date) {
                Navigator.pop(context);
              },
              rangeStartDay: widget.selectedPeriod.start,
              rangeEndDay: widget.selectedPeriod.end,
              calendarStyle: CalendarStyle(
                todayDecoration: BoxDecoration(
                  border: Border.all(color: AppColors.oliveDark, width: 0.5),
                  shape: BoxShape.circle,
                  color: AppColors.oliveDark,
                ),
                weekendTextStyle: TypographyNeueHaasUnicaW1G.menu1.copyWith(fontWeight: FontWeight.bold),
                defaultTextStyle: TypographyNeueHaasUnicaW1G.menu1.copyWith(fontWeight: FontWeight.bold),
                // todayTextStyle: TypographyNeueHaasUnicaW1G.menu1.copyWith(fontWeight: FontWeight.bold),
                // withinRangeTextStyle: TypographyNeueHaasUnicaW1G.menu1.copyWith(fontWeight: FontWeight.bold),
              ),
              daysOfWeekStyle: DaysOfWeekStyle(
                weekdayStyle: TypographyNeueHaasUnicaW1G.menu3,
                weekendStyle: TypographyNeueHaasUnicaW1G.menu3,
                dowTextFormatter: (day, locale) {
                  return DateFormat(DateFormat.WEEKDAY).format(day).substring(0, 1);
                },
              ),
              calendarBuilders: CalendarBuilders(
                rangeHighlightBuilder: (context, day, isWithinRange) => SizedBox(),
                outsideBuilder: (context, date1, date2) => Container(
                  width: 36,
                  height: 36,
                  padding: AppInsets.insetsAll8,
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.oliveDark, width: 0.5),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      DateFormat(DateFormat.DAY).format(date1),
                      style: TypographyNeueHaasUnicaW1G.menu1.copyWith(
                        fontWeight: FontWeight.bold,
                        color: AppColors.dark.withOpacity(0.5),
                      ),
                    ),
                  ),
                ),
                rangeStartBuilder: (context, date1, date2) => Container(
                  width: 36,
                  height: 36,
                  padding: AppInsets.insetsAll8,
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.oliveDark, width: 0.5),
                    shape: BoxShape.circle,
                    color: AppColors.oliveDark,
                  ),
                  child: Center(
                    child: Text(
                      DateFormat(DateFormat.DAY).format(date1),
                      style: TypographyNeueHaasUnicaW1G.menu1.copyWith(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                rangeEndBuilder: (context, date1, date2) => Container(
                  width: 36,
                  height: 36,
                  padding: AppInsets.insetsAll8,
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.oliveDark, width: 0.5),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      DateFormat(DateFormat.DAY).format(date1),
                      style: TypographyNeueHaasUnicaW1G.menu1.copyWith(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                withinRangeBuilder: (context, date1, date2) => Container(
                  width: 36,
                  height: 36,
                  padding: AppInsets.insetsAll8,
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.oliveDark, width: 0.5),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      DateFormat(DateFormat.DAY).format(date1),
                      style: TypographyNeueHaasUnicaW1G.menu1.copyWith(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                defaultBuilder: (context, date1, date2) => Container(
                  width: 36,
                  height: 36,
                  padding: AppInsets.insetsAll8,
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.oliveDark, width: 0.5),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      DateFormat(DateFormat.DAY).format(date1),
                      style: TypographyNeueHaasUnicaW1G.menu1.copyWith(
                        fontWeight: FontWeight.bold,
                        color: AppColors.dark.withOpacity(0.5),
                      ),
                    ),
                  ),
                ),
                todayBuilder: (context, date1, date2) => Container(
                  width: 36,
                  height: 36,
                  padding: AppInsets.insetsAll8,
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.oliveDark, width: 0.5),
                    shape: BoxShape.circle,
                    color: AppColors.oliveDark,
                  ),
                  child: Center(
                    child: Text(
                      DateFormat(DateFormat.DAY).format(date1),
                      style: TypographyNeueHaasUnicaW1G.menu1.copyWith(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                selectedBuilder: (context, date1, date2) => Container(
                  width: 36,
                  height: 36,
                  padding: AppInsets.insetsAll8,
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.oliveDark, width: 0.5),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      DateFormat(DateFormat.DAY).format(date1),
                      style: TypographyNeueHaasUnicaW1G.menu1.copyWith(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                disabledBuilder: (context, date1, date2) => Container(
                  width: 36,
                  height: 36,
                  padding: AppInsets.insetsAll8,
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.oliveDark, width: 0.5),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      DateFormat(DateFormat.DAY).format(date1),
                      style: TypographyNeueHaasUnicaW1G.menu1.copyWith(
                        fontWeight: FontWeight.bold,
                        color: AppColors.dark.withOpacity(0.5),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          AppSpacing.verticalSpace20,
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              GestureDetector(
                child: SvgPicture.asset('assets/svgs/left_chevron.svg'),
              ),
              AppSpacing.horizontalSpace12,
              AppSpacing.horizontalSpace24,
              GestureDetector(
                child: SvgPicture.asset('assets/svgs/right_chevron.svg'),
              ),
            ],
          ),
          AppSpacing.verticalSpace20,
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Expanded(
                child: CustomButton(
                  onTap: () {},
                  color: Colors.white,
                  text: 'reset'.tr(),
                ),
              ),
              AppSpacing.horizontalSpace16,
              Expanded(
                child: CustomButton(
                  onTap: () {},
                  text: 'choose'.tr(),
                ),
              ),
            ],
          ),
          AppSpacing.verticalSpace16,
        ],
      ),
    );
  }
}
