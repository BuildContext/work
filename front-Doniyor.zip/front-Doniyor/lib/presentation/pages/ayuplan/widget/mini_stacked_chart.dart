import 'package:flutter/material.dart';
import 'package:test_project/core/models/chart_models/mini_chart_data.dart';

class MiniStackedChart extends StatelessWidget {
  final List<MiniChartDataSeries> data;

  const MiniStackedChart({Key? key, required this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 36,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: List<Widget>.from(data.map((item) => _MiniChartDataWidget(dataItem: item))),
      ),
    );
  }
}

class _MiniChartDataWidget extends StatelessWidget {
  final MiniChartDataSeries dataItem;

  const _MiniChartDataWidget({
    Key? key,
    required this.dataItem,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, boxSize) {
        return Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: List<Widget>.from(
            dataItem.items.map(
              (item) => SizedBox(
                height: boxSize.maxHeight * item.percentage,
                width: 8,
                child: ColoredBox(color: item.color, child: SizedBox()),
              ),
            ),
          ),
        );
      },
    );
  }
}
