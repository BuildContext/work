import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/presentation/pages/ayuplan/widget/day_selector_button.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/extentions/date_time_range_extentions.dart';
import 'package:test_project/tools/extentions/string_extensions.dart';

class MiniWeekDaySelector extends StatefulWidget {
  final DateTimeRange initialWeek;
  final ValueChanged<DateTime> onDayChosen;

  const MiniWeekDaySelector({
    Key? key,
    required this.initialWeek,
    required this.onDayChosen,
  }) : super(key: key);

  @override
  State<MiniWeekDaySelector> createState() => _MiniWeekDaySelectorState();
}

class _MiniWeekDaySelectorState extends State<MiniWeekDaySelector> {
  late DateTime _selectedDay = widget.initialWeek.start;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final langCode = context.locale.languageCode;
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              DateFormat(DateFormat.WEEKDAY, langCode).format(_selectedDay).capitalize,
              style: TypographyTwCenW01Medium.title1,
            ),
            Text(
              '${DateFormat(DateFormat.MONTH, langCode).format(widget.initialWeek.end)} ${DateFormat(DateFormat.DAY).format(widget.initialWeek.start)}-${DateFormat(DateFormat.DAY).format(widget.initialWeek.end)}',
              style: TypographyTwCenW01Medium.subtitle2,
            ),
          ],
        ),
        AppSpacing.verticalSpace20,
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: List.generate(
            widget.initialWeek.duration.inDays + 1,
            (index) {
              final day = widget.initialWeek.getDayByOffsetIndex(index);
              return DaySelectionButton(
                isSelected: _selectedDay == day,
                onTap: () {
                  setState(() {
                    _selectedDay = day;
                  });
                },
                date: day,
              );
            },
          ),
        ),
      ],
    );
  }
}
