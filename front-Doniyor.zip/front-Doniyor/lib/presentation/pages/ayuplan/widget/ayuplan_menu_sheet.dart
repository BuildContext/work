import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/recipe_category_item.dart';
import 'package:test_project/presentation/pages/ayumeal/recipe/recipe_overview/recipe_overview_page.dart';
import 'package:test_project/presentation/pages/ayuplan/widget/calendar_sheet.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

class AyuplanMenuSheet extends StatelessWidget {
  final RecipeCategoryItem recipe;

  const AyuplanMenuSheet({Key? key, required this.recipe}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.5,
      width: MediaQuery.of(context).size.width,
      child: ListView(
        children: [
          MenuItem(
            onTap: () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => RecipeIngredientsOverviewPage(recipe: recipe),
              ),
            ),
            title: 'start_cocking'.tr(),
            trailing: SvgPicture.asset('assets/svgs/start_cocking.svg'),
          ),
          MenuItem(onTap: () {}, title: 'mark_as_cocked'.tr(), trailing: SvgPicture.asset('assets/svgs/checked_square.svg')),
          MenuItem(onTap: () {}, title: 'replace'.tr(), trailing: SvgPicture.asset('assets/svgs/reload.svg')),
          MenuItem(onTap: () {}, title: 'favourite'.tr(), trailing: SvgPicture.asset('assets/svgs/favourites.svg')),
          MenuItem(
            onTap: () {
              Navigator.pop(context);
              AppInteractionsHelper.showBottomSheet(
                context: context,
                barrierColor: AppColors.oliveDark,
                child: CalendarSheet(
                  selectedPeriod: DateTimeRange(start: DateTime.now(), end: DateTime.now().add(Duration(days: 6))),
                ),
              );
            },
            title: 'planning'.tr(),
            trailing: SvgPicture.asset('assets/svgs/calendar.svg'),
          ),
          MenuItem(onTap: () {}, title: 'share'.tr(), trailing: SvgPicture.asset('assets/svgs/share.svg')),
          MenuItem(onTap: () {}, title: 'exclude'.tr(), trailing: SvgPicture.asset('assets/svgs/delete.svg')),
          MenuItem(onTap: () {}, title: 'add_more'.tr(), trailing: SvgPicture.asset('assets/svgs/add.svg')),
        ],
      ),
    );
  }
}

class MenuItem extends StatelessWidget {
  final VoidCallback onTap;
  final String title;
  final Widget trailing;

  const MenuItem({
    Key? key,
    required this.onTap,
    required this.title,
    required this.trailing,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      child: ListTile(
        title: Text(
          title,
          style: TypographyNeueHaasUnicaW1G.basic1,
        ),
        trailing: trailing,
        tileColor: Colors.white,
        onTap: onTap,
      ),
    );
  }
}
