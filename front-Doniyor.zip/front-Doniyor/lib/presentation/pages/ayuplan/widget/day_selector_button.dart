import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class DaySelectionButton extends StatelessWidget {
  final bool isSelected;
  final VoidCallback onTap;
  final DateTime date;

  const DaySelectionButton({
    Key? key,
    required this.isSelected,
    required this.onTap,
    required this.date,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Material(
          elevation: 0,
          color: isSelected ? AppColors.oliveDark : AppColors.oliveLight,
          borderRadius: AppBorderRadius.enoughToMakeItCircle,
          child: InkWell(
            borderRadius: AppBorderRadius.enoughToMakeItCircle,
            onTap: onTap,
            child: Ink(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.oliveDark, width: 0.5),
                color: isSelected ? AppColors.oliveDark : AppColors.oliveLight,
              ),
              child: Center(
                child: Text(DateFormat(DateFormat.DAY).format(date), style: TypographyNeueHaasUnicaW1G.menu1),
              ),
            ),
          ),
        ),
        AppSpacing.verticalSpace8,
        Text(DateFormat(DateFormat.ABBR_WEEKDAY, context.locale.languageCode).format(date).substring(0, 1),
            style: TypographyNeueHaasUnicaW1G.menu3),
      ],
    );
  }
}
