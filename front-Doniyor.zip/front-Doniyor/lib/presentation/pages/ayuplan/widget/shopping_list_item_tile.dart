import 'package:flutter/material.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/presentation/theme/typography.dart';

class ShoppingListItemTile extends StatelessWidget {
  final FoodElement item;
  final ValueChanged<bool> onSelected;

  const ShoppingListItemTile({
    Key? key,
    required this.item,
    required this.onSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child: CheckboxListTile(
        tileColor: Colors.white,
        onChanged: (value) => onSelected(value ?? false),
        value: item.isChecked,
        title: Text(
          item.title,
          style: TypographyNeueHaasUnicaW1G.basic2,
        ),
        subtitle: Text(
          '${item.amount} ${item.measurementType}',
          style: TypographyNeueHaasUnicaW1G.basic3,
        ),
      ),
    );
  }
}
