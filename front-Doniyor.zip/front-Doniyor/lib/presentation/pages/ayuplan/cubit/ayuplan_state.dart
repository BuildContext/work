import 'package:test_project/core/models/mealplan.dart';
import 'package:test_project/core/models/quiz.dart';

abstract class AyuplanState {}

class AyuplanInitial extends AyuplanState {}

class AyuplanLoading extends AyuplanState {}

class AyuplanSuccess extends AyuplanState {
  final MealPlan mealPlan;
  final Quiz quiz;

  AyuplanSuccess({
    required this.mealPlan,
    required this.quiz,
  });
}

class AyuplanError extends AyuplanState {
  final String error;

  AyuplanError({required this.error});
}
