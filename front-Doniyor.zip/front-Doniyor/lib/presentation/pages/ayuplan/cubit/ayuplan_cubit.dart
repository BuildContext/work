import 'package:bloc/bloc.dart';
import 'package:test_project/domain/services/ayuplan_service.dart';
import 'package:test_project/presentation/pages/ayuplan/cubit/ayuplan_state.dart';
import 'package:test_project/tools/mixins/quiz_mixin.dart';

class AyuplanCubit extends Cubit<AyuplanState> with QuizMixin {
  AyuplanCubit() : super(AyuplanInitial());

  Future<void> loadData() async {
    emit(AyuplanLoading());
    final mealplan = await AyuplanService.instance.getMealPlan();
    final quiz = await loadQuiz();
    emit(AyuplanSuccess(mealPlan: mealplan, quiz: quiz));
  }
}
