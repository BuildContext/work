import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/quiz.dart';
import 'package:test_project/core/models/quiz_option.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';

class QuizWithToggleableOptionsPage extends StatelessWidget {
  final Quiz quiz;

  QuizWithToggleableOptionsPage({
    Key? key,
    required this.quiz,
  }) : assert(!(quiz.options is List<SelectableQuizOption>));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SvgPicture.asset('assets/svgs/left_chevron.svg'),
            AppSpacing.horizontalSpace12,
            AppSpacing.horizontalSpace24,
            SvgPicture.asset('assets/svgs/right_chevron.svg'),
          ],
        ),
      ),
      body: Container(),
    );
  }
}
