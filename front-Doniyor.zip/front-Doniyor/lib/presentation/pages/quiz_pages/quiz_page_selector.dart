import 'package:flutter/material.dart';
import 'package:test_project/core/models/quiz.dart';
import 'package:test_project/presentation/pages/quiz_pages/quiz_with_toggleable_options_page.dart';

class QuizPage extends StatelessWidget {
  final Quiz quiz;

  const QuizPage({Key? key, required this.quiz}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (quiz.type == QuizTypes._WITH_TOGGLEABLE_OPTIONS) return QuizWithToggleableOptionsPage(quiz: quiz);
    return Container();
  }
}

class QuizTypes {
  QuizTypes._();

  static String getByIndex(int index) {
    switch (index) {
      case 0:
        return _WITH_TOGGLEABLE_OPTIONS;
      default:
        return '';
    }
  }

  static const String _WITH_TOGGLEABLE_OPTIONS = 'with_toggle_options';
}
