import 'package:flutter/material.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/category_models.dart';
import 'package:test_project/core/models/quiz.dart';
import 'package:test_project/core/models/suggested_title.dart';
import 'package:test_project/presentation/custom_widgets/content_section.dart';
import 'package:test_project/presentation/custom_widgets/custom_drop_down_button.dart';
import 'package:test_project/presentation/custom_widgets/suggested_titles.dart';
import 'package:test_project/presentation/custom_widgets/vertical_small_content_card.dart';
import 'package:test_project/presentation/pages/ayumeal/ingredient/detailed_ingredient/detailed_ingredient_page.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class IngredientsTab extends StatelessWidget {
  final List<IngredientCategory> ingredients;
  final List<SuggestedTitle> suggestedTitles;
  final Quiz quiz;
  final Future<void> Function() onRefresh;

  const IngredientsTab({
    Key? key,
    required this.ingredients,
    required this.quiz,
    required this.suggestedTitles,
    required this.onRefresh,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView(
        padding: AppInsets.horizontalInsets28,
        children: [
          AppSpacing.verticalSpace24,
          Text('Ingredient Categories', style: TypographyTwCenW01Medium.title3),
          AppSpacing.verticalSpace24,
          SingleChildScrollView(
            child: Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                CustomDropDownButton<String>(
                  onChanged: (value) {},
                  backgroundColor: AppColors.oliveLight,
                  items: List<CustomDropDownOption<String>>.generate(
                    5,
                    (index) => CustomDropDownOption<String>(title: 'Ingredients', value: 'value $index'),
                  ),
                ),
                AppSpacing.horizontalSpace20,
                CustomDropDownButton<String>(
                  onChanged: (value) {},
                  items: List<CustomDropDownOption<String>>.generate(
                    5,
                    (index) => CustomDropDownOption<String>(title: 'Most popular', value: 'value $index'),
                  ),
                ),
              ],
            ),
          ),
          for (final category in ingredients)
            ContentSection(
              titleStyle: TypographyTwCenW01Medium.title2,
              title: category.categoryName,
              onMore: () {},
              children: category.items
                  .map<Widget>(
                    (e) => VerticalSmallContentCard(
                      calories: e.energy,
                      placeholderPath: 'assets/pngs/ingredient_placeholder.png',
                      post: ContentCategoryItem(
                        id: e.id ?? '',
                        categoryName: e.classificationType?.title ?? '',
                        imageLink: e.imageUrl ?? '',
                        icons: [],
                        time: Duration(minutes: 8),
                        goodFor: e.goodFor?.map((e) => ContentCategoryTag(title: e.title ?? '')).toList() ?? [],
                        title: e.title ?? '',
                      ),
                      onLikePressed: () {},
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => DetailedIngredientPage(id: e.id ?? '')),
                      ),
                    ),
                  )
                  .toList(),
            ),
          AppSpacing.verticalSpace20,
          AppSpacing.verticalSpace24,
          SuggestedTitles(titles: suggestedTitles),
          AppSpacing.verticalSpace30,
          // for (final ingredient in ingredients)
          //   ContentSection(
          //     displayDivider: false,
          //     title: ingredient.title,
          //     subCategories: [],
          //     children: [],
          //     // children: ingredient.items
          //     //     .map<Widget>(
          //     //       (e) => VerticalSmallContentCard(
          //     //         placeholderPath: 'assets/pngs/ingredient_placeholder.png',
          //     //         post: e,
          //     //         onLikePressed: () {},
          //     //         onTap: () => Navigator.push(
          //     //           context,
          //     //           MaterialPageRoute(builder: (context) => DetailedIngredientPage(id: 123)),
          //     //         ),
          //     //       ),
          //     //     )
          //     //     .toList(),
          //     titleStyle: TypographyTwCenW01Medium.title3,
          //   ),
          // AppSpacing.verticalSpace20,
          // AppSpacing.verticalSpace24,
          // QuizCard(quiz: quiz),
          // AppSpacing.verticalSpace24,
        ],
      ),
    );
  }
}
