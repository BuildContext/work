import 'package:bloc/bloc.dart';
import 'package:test_project/core/models/ingredient.dart';
import 'package:test_project/domain/services/ayuworld_service.dart';
import 'package:test_project/domain/services/ingredients_service.dart';
import 'package:test_project/domain/services/recipe_service.dart';

import 'detailed_ingredient_page_state.dart';

class DetailedIngredientPageCubit extends Cubit<DetailedIngredientPageState> {
  DetailedIngredientPageCubit() : super(DetailedIngredientInitial());
  IngredientResult ingredient = IngredientResult();

  Future<void> loadData(String id) async {
    emit(DetailedIngredientLoading());

    final recommendation = await RecipeService.instance.getOtherRecommendations();
    final quiz = await AyuworldService.instance.loadQuiz();
    final ingredientResult = await IngredientService.instance.loadIngredientById(id);
    ingredientResult.fold(
      (l) => emit(DetailedIngredientError(error: l.error)),
      (r) => ingredient = r,
    );

    emit(DetailedIngredientSuccess(
      quiz: quiz,
      otherRecommendations: recommendation,
      ingredient: ingredient,
    ));
  }
}
