import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/ingredient.dart';
import 'package:test_project/core/models/quiz.dart';

abstract class DetailedIngredientPageState {}

class DetailedIngredientInitial extends DetailedIngredientPageState {}

class DetailedIngredientLoading extends DetailedIngredientPageState {}

class DetailedIngredientSuccess extends DetailedIngredientPageState {
  final Quiz quiz;
  final ContentCategory otherRecommendations;
  final IngredientResult ingredient;

  DetailedIngredientSuccess({
    required this.otherRecommendations,
    required this.ingredient,
    required this.quiz,
  });
}

class DetailedIngredientError extends DetailedIngredientPageState {
  final String error;

  DetailedIngredientError({required this.error});
}
