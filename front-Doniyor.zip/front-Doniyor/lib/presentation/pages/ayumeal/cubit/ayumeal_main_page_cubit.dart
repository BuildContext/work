import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_project/core/models/category_models.dart';
import 'package:test_project/core/models/ingredient.dart';
import 'package:test_project/domain/services/ingredients_service.dart';
import 'package:test_project/domain/services/recipe_service.dart';
import 'package:test_project/presentation/pages/ayumeal/cubit/ayumeal_main_page_state.dart';
import 'package:test_project/tools/thread_functions.dart';

class AyumealMainPageCubit extends Cubit<AyumealMainPageState> {
  AyumealMainPageCubit() : super(AyumealMainInitial());
  Ingredient ingredients = Ingredient();

  Future<void> loadData() async {
    emit(AyumealMainLoading());
    final recommendations = await RecipeService.instance.getOtherRecommendations();
    final recipes = await RecipeService.instance.loadRecipes(page: 1, size: 5);
    final quiz = await RecipeService.instance.loadQuiz();
    final ingredientsResult = await IngredientService.instance.loadIngredients(page: 1, size: 5);
    ingredientsResult.fold(
      (l) => emit(AyumealMainError(error: l.error)),
      (r) => ingredients = r,
    );
    final titles = await IngredientService.instance.loadSuggestedTitles();

    final categoriesList = await compute(ThreadFunctions.deriveIngredientCategories, ingredients);
    final ingredientCategories = List<IngredientCategory>.empty(growable: true);
    for (final category in categoriesList) {
      ingredientCategories.add(
        IngredientCategory(
          categoryName: category,
          items: ingredients.results?.where((element) => element.classificationType?.title == category).toList() ?? [],
        ),
      );
    }
    recipes.fold(
      (l) => emit(AyumealMainError(error: l.error)),
      (r) {
        emit(
          AyumealMainSuccess(
            recommendations: recommendations,
            quiz: quiz,
            mainIngredients: ingredientCategories.isEmpty
                ? IngredientCategory(
                    items: [],
                    categoryName: 'none',
                  )
                : ingredientCategories.first,
            recipes: r,
            ingredients: ingredientCategories,
            suggestedTitles: titles,
          ),
        );
      },
    );
  }
}
