import 'package:test_project/core/models/category_models.dart';
import 'package:test_project/core/models/quiz.dart';
import 'package:test_project/core/models/recipe_model.dart';
import 'package:test_project/core/models/suggested_title.dart';

abstract class AyumealMainPageState {}

class AyumealMainInitial extends AyumealMainPageState {}

class AyumealMainLoading extends AyumealMainPageState {}

class AyumealMainSuccess extends AyumealMainPageState {
  final RecipeCategory recommendations;
  final RecipeModel recipes;
  final List<IngredientCategory> ingredients;
  final IngredientCategory mainIngredients;
  final List<SuggestedTitle> suggestedTitles;
  final Quiz quiz;

  AyumealMainSuccess({
    required this.recommendations,
    required this.quiz,
    required this.mainIngredients,
    required this.recipes,
    required this.ingredients,
    required this.suggestedTitles,
  });
}

class AyumealMainError extends AyumealMainPageState {
  final String error;

  AyumealMainError({required this.error});
}
