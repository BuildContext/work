import 'package:flutter/material.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/category_models.dart';
import 'package:test_project/core/models/quiz.dart';
import 'package:test_project/core/models/recipe_category_item.dart';
import 'package:test_project/core/models/recipe_model.dart';
import 'package:test_project/presentation/custom_widgets/app_switch_button.dart';
import 'package:test_project/presentation/custom_widgets/content_section.dart';
import 'package:test_project/presentation/custom_widgets/vertical_small_content_card.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';

import 'detailed_recipe/detailed_recipe_page.dart';

class RecipesTab extends StatelessWidget {
  final RecipeModel recipes;
  final Quiz quiz;
  final RecipeCategory recommendations;
  final Future<void> Function() onRefresh;

  const RecipesTab({
    Key? key,
    required this.recipes,
    required this.recommendations,
    required this.quiz,
    required this.onRefresh,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView(
        padding: AppInsets.horizontalInsets28,
        children: [
          AppSpacing.verticalSpace24,
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Meal for me', style: TypographyNeueHaasUnicaW1G.basic2),
                  AppSpacing.verticalSpace8,
                  Text('Individually selected', style: TypographyNeueHaasUnicaW1G.basic3),
                ],
              ),
              AppSwitchButton(onSwitched: (value) {}),
            ],
          ),
          AppSpacing.verticalSpace16,
          AppSpacing.verticalSpace16,
          // ContentSection(
          //   title: recommendations.categoryName,
          //   children: recommendations.items
          //       .map<Widget>(
          //         (e) => LargeContentCard(
          //           placeholderPath: 'assets/pngs/recipe_large_placeholder.png',
          //           onLikePressed: () {},
          //           onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => DetailedRecipePage(item: e))),
          //           item: e,
          //         ),
          //       )
          //       .toList(),
          //   displayTopSpacing: false,
          //   displayDivider: false,
          //   titleStyle: TypographyTwCenW01Medium.title1,
          // ),
          if (recipes.results?.isEmpty ?? false)
            Text(
              'No content to display',
              style: TypographyNeueHaasUnicaW1G.buttonBold,
              textAlign: TextAlign.center,
            ),
          if (recipes.results?.isNotEmpty ?? false)
            ContentSection(
              onMore: () {},
              children: recipes.results?.map<Widget>(
                    (e) {
                      final recipe = RecipeCategoryItem(
                        calories: 0,
                        description: e.description ?? '',
                        salt: 0,
                        isAdded: false,
                        fibre: 0,
                        primaryIngredients: [
                          ...e.ingredients?.map((e) => FoodElement(
                                    title: '${e.type}',
                                    measurementType: '${e.unit}',
                                    amount: e.quantity ?? 0,
                                    id: e.ingredient ?? '',
                                  )) ??
                              [],
                        ],
                        secondaryIngredients: [],
                        goodFor: [
                          ...e.goodForAgni?.map((e) => ContentCategoryTag(title: e.title ?? '')).toList() ?? [],
                          ...e.goodForDisease?.map((e) => ContentCategoryTag(title: e.title ?? '')).toList() ?? [],
                          ...e.goodForDoshaType?.map((e) => ContentCategoryTag(title: e.title ?? '')).toList() ?? [],
                          ...e.goodForMindGunas?.map((e) => ContentCategoryTag(title: e.title ?? '')).toList() ?? [],
                          ...e.goodForPhysicalActivity?.map((e) => ContentCategoryTag(title: e.title ?? '')).toList() ?? [],
                          ...e.goodForPhysiology?.map((e) => ContentCategoryTag(title: e.title ?? '')).toList() ?? [],
                        ],
                        badFor: [
                          ...e.badForAgni?.map((e) => ContentCategoryTag(title: e.title ?? '')).toList() ?? [],
                          ...e.badForDisease?.map((e) => ContentCategoryTag(title: e.title ?? '')).toList() ?? [],
                          ...e.badForDoshaType?.map((e) => ContentCategoryTag(title: e.title ?? '')).toList() ?? [],
                          ...e.badForMindGunas?.map((e) => ContentCategoryTag(title: e.title ?? '')).toList() ?? [],
                          ...e.badForPhysicalActivity?.map((e) => ContentCategoryTag(title: e.title ?? '')).toList() ?? [],
                          ...e.badForPhysiology?.map((e) => ContentCategoryTag(title: e.title ?? '')).toList() ?? [],
                        ],
                        steps: e.cookingSteps
                                ?.map<RecipeStep>(
                                  (step) => RecipeStep(
                                    stepOrderNumber: e.cookingSteps?.indexOf(step) ?? -1,
                                    title: '',
                                    description: step,
                                    ingredients: [],
                                  ),
                                )
                                .toList() ??
                            [],
                        stepsTitle: e.nutrionalFacts ?? '',
                        fats: 0,
                        fatsList: [],
                        carbohydrates: 0,
                        carbohydratesList: [],
                        protein: 0,
                        title: e.title ?? '',
                        isLiked: false,
                        time: Duration(minutes: int.tryParse(e.cookingTime?.split(' ').first ?? '') ?? 0),
                        categoryName: '',
                        id: e.id ?? '',
                        icons: [],
                        imageLink: e.image ?? '',
                      );
                      return VerticalSmallContentCard(
                        placeholderPath: 'assets/pngs/recipe_small_placeholder.png',
                        post: recipe,
                        onLikePressed: () {},
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => DetailedRecipePage(item: recipe),
                          ),
                        ),
                      );
                    },
                  ).toList() ??
                  [],
              displayDivider: true,
              title: 'Recipes',
              titleStyle: TypographyTwCenW01Medium.title3,
            ),
          // AppSpacing.verticalSpace20,
          // AppSpacing.verticalSpace24,
          // QuizCard(quiz: quiz),
          // AppSpacing.verticalSpace24,
        ],
      ),
    );
  }
}
