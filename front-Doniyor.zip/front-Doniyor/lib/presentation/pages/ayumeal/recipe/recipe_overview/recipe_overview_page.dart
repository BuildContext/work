import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/core/models/recipe_category_item.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/custom_widgets/ingredient_element_tile.dart';
import 'package:test_project/presentation/pages/ayumeal/recipe/cocking_page/coocking_page.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';

class RecipeIngredientsOverviewPage extends StatelessWidget {
  final RecipeCategoryItem recipe;

  const RecipeIngredientsOverviewPage({
    Key? key,
    required this.recipe,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          recipe.title,
          style: TypographyTwCenW01Medium.title3,
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: AppInsets.horizontalInsets28,
          children: [
            AppSpacing.verticalSpace20,
            AppSpacing.verticalSpace20,
            Text('Ingredients for the main dish'.toUpperCase(), style: TypographyTwCenW01Medium.subtitle2),
            AppSpacing.verticalSpace20,
            AppSpacing.verticalSpace12,
            Column(
              mainAxisSize: MainAxisSize.min,
              children: recipe.primaryIngredients
                  .map<Widget>(
                    (e) => FoodItemElementTile(
                      element: e,
                      textStyle: TypographyNeueHaasUnicaW1G.basic3,
                      onOptionsClicked: () {},
                    ),
                  )
                  .toList(),
            ),
            AppSpacing.verticalSpace20,
            Text('Ingredients for th...'.toUpperCase(), style: TypographyTwCenW01Medium.subtitle2),
            AppSpacing.verticalSpace20,
            AppSpacing.verticalSpace12,
            Column(
              mainAxisSize: MainAxisSize.min,
              children: recipe.secondaryIngredients
                  .map<Widget>(
                    (e) => FoodItemElementTile(
                      element: e,
                      textStyle: TypographyNeueHaasUnicaW1G.basic3,
                      onOptionsClicked: () {},
                    ),
                  )
                  .toList(),
            ),
          ],
        ),
      ),
      bottomSheet: Container(
        padding: AppInsets.horizontalInsets28.copyWith(bottom: 20),
        color: Colors.white,
        child: Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            Expanded(
              child: CustomButton(
                onTap: () {},
                color: Colors.white,
                text: 'mark_as_cocked'.tr(),
              ),
            ),
            AppSpacing.horizontalSpace16,
            Expanded(
              child: CustomButton(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => CoockingPage(recipe: recipe),
                  ),
                ),
                text: 'next'.tr(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
