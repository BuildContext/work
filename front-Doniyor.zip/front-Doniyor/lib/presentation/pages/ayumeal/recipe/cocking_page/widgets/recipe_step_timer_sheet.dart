import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:test_project/core/models/recipe_category_item.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/pages/ayumeal/recipe/cocking_page/coocking_page.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';

class RecipeStepTimerSheet extends StatefulWidget {
  final RecipeStep step;

  const RecipeStepTimerSheet({Key? key, required this.step}) : super(key: key);

  @override
  State<RecipeStepTimerSheet> createState() => _RecipeStepTimerSheetState();
}

class _RecipeStepTimerSheetState extends State<RecipeStepTimerSheet> {
  int timeRemained = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance?.addPostFrameCallback((timeStamp) {
      _startCountDown();
    });
  }

  _startCountDown() async {
    setState(() => timeRemained = widget.step.secondsToComplete);
    for (int i = 0; i < 119; i++) {
      if (timeRemained == 0 || timeRemained < 0) {
        setState(() => timeRemained = 0);
        break;
      }
      if (timeRemained > 0) {
        await Future.delayed(Duration(seconds: 1), () => setState(() => timeRemained--));
      }
    }
  }

  String _getFormattedTimerTime(int seconds) {
    Duration currentDuration = Duration(seconds: seconds);
    int mins = currentDuration.inMinutes;
    int secondsRemained = seconds - (mins * 60);
    return '$mins:$secondsRemained';
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          '${_getFormattedTimerTime(timeRemained)}',
          style: TypographyTwCenW01Medium.header2,
        ),
        AppSpacing.verticalSpace24,
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            HeatTreatmentTile(
              title: '${widget.step.temperature}\u00b0 C',
              leading: SvgPicture.asset('assets/svgs/temperature.svg'),
            ),
            AppSpacing.horizontalSpace16,
            HeatTreatmentTile(
              title: '${Duration(seconds: widget.step.secondsToComplete).inMinutes} ${'minutes'.tr()}',
              leading: SvgPicture.asset('assets/svgs/alarm.svg'),
            ),
          ],
        ),
        AppSpacing.verticalSpace24,
        Text(
          widget.step.description,
          style: TypographyNeueHaasUnicaW1G.basic2,
        ),
        AppSpacing.verticalSpace24,
        Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            Expanded(
              child: CustomButton(
                onTap: () => Navigator.pop(context),
                color: Colors.white,
                text: 'cancel_timer'.tr(),
              ),
            ),
            AppSpacing.horizontalSpace16,
            Expanded(
              child: CustomButton(
                onTap: () {},
                text: 'next'.tr(),
              ),
            ),
          ],
        ),
        AppSpacing.verticalSpace24,
      ],
    );
  }
}
