import 'dart:math';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/recipe_category_item.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/pages/ayumeal/recipe/cocking_page/widgets/recipe_step_timer_sheet.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

class CoockingPage extends StatefulWidget {
  final RecipeCategoryItem recipe;

  const CoockingPage({Key? key, required this.recipe}) : super(key: key);

  @override
  State<CoockingPage> createState() => _CoockingPageState();
}

class _CoockingPageState extends State<CoockingPage> {
  late RecipeStep currentStep = widget.recipe.steps.first;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              widget.recipe.title,
              style: TypographyTwCenW01Medium.title3,
            ),
            Text(
              '${currentStep.stepOrderNumber + 1} ${'of'.tr()} ${widget.recipe.steps.length}',
              style: TypographyTwCenW01Medium.subtitle1,
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: AppInsets.horizontalInsets28,
          children: [
            AppSpacing.verticalSpace20,
            AppSpacing.verticalSpace12,
            Text(
              (currentStep.stepOrderNumber + 1).toString(),
              style: TypographyTwCenW01Medium.header2,
            ),
            AppSpacing.verticalSpace16,
            Text(
              currentStep.description,
              style: TypographyTwCenW01Medium.title1,
            ),
            AppSpacing.verticalSpace24,
            if (currentStep.needsHeatTreatment)
              Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  HeatTreatmentTile(
                    title: '${currentStep.temperature}\u00b0 C',
                    leading: SvgPicture.asset('assets/svgs/temperature.svg'),
                  ),
                  AppSpacing.horizontalSpace16,
                  HeatTreatmentTile(
                    title: '${Duration(seconds: currentStep.secondsToComplete).inMinutes} ${'minutes'.tr()}',
                    leading: SvgPicture.asset('assets/svgs/alarm.svg'),
                  ),
                ],
              ),
            AppSpacing.verticalSpace24,
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: currentStep.ingredients
                  .map((e) => Text(
                        '${e.title} - ${e.amount} ${e.measurementType}',
                        style: TypographyNeueHaasUnicaW1G.basic2,
                      ))
                  .toList(),
            )
          ],
        ),
      ),
      bottomSheet: Container(
        padding: AppInsets.horizontalInsets28.copyWith(bottom: 20),
        color: Colors.white,
        child: Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            Expanded(
              child: CustomButton(
                onTap: () {},
                color: Colors.white,
                text: 'mark_as_cocked'.tr(),
              ),
            ),
            AppSpacing.horizontalSpace16,
            Expanded(
              child: CustomButton(
                onTap: () {
                  if (currentStep.needsHeatTreatment)
                    AppInteractionsHelper.showBottomSheet(
                      context: context,
                      child: RecipeStepTimerSheet(step: currentStep),
                      title: 'timer'.tr(),
                    );
                  else
                    setState(() {
                      currentStep = widget.recipe.steps.elementAt(
                        min(currentStep.stepOrderNumber + 1, widget.recipe.steps.length),
                      );
                    });
                },
                text: 'next'.tr(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class HeatTreatmentTile extends StatelessWidget {
  final String title;
  final Widget leading;

  const HeatTreatmentTile({
    Key? key,
    required this.title,
    required this.leading,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: AppInsets.insetsAll8,
      decoration: BoxDecoration(
        borderRadius: AppBorderRadius.borderRadiusAll6,
        border: Border.all(color: AppColors.oliveDark, width: 0.5),
        color: AppColors.oliveLight,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          leading,
          AppSpacing.horizontalSpace8,
          Text(
            title,
            style: TypographyNeueHaasUnicaW1G.link3,
          ),
        ],
      ),
    );
  }
}
