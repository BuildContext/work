import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/recipe_category_item.dart';
import 'package:test_project/presentation/custom_widgets/content_section.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/custom_widgets/custom_linear_progress_indicator.dart';
import 'package:test_project/presentation/custom_widgets/ingredient_element_tile.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/custom_widgets/tag_tile.dart';
import 'package:test_project/presentation/custom_widgets/vertical_small_content_card.dart';
import 'package:test_project/presentation/pages/ayumeal/recipe/detailed_recipe/cubit/detailed_recipe_page_cubit.dart';
import 'package:test_project/presentation/pages/ayumeal/recipe/detailed_recipe/cubit/detailed_recipe_page_state.dart';
import 'package:test_project/presentation/pages/ayumeal/recipe/detailed_recipe/widgets/recipte_step_description.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class DetailedRecipePage extends StatefulWidget {
  final RecipeCategoryItem item;

  const DetailedRecipePage({Key? key, required this.item}) : super(key: key);

  @override
  _DetailedRecipePageState createState() => _DetailedRecipePageState();
}

class _DetailedRecipePageState extends State<DetailedRecipePage> {
  final cubit = DetailedRecipePageCubit();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      Map<String, double> amounts = {};
      for (final ingredient in widget.item.primaryIngredients) {
        amounts.addAll({'${ingredient.id}': ingredient.amount});
      }
      await cubit.loadData(
        recipeIngredientsIds: [
          ...widget.item.primaryIngredients.map<String>((e) => e.id).toList(),
        ],
        ingredientAmounts: amounts,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    double imageHeight = 484;
    return Scaffold(
      body: BlocConsumer<DetailedRecipePageCubit, DetailedRecipePageState>(
        bloc: cubit,
        listener: (context, state) {},
        builder: (context, state) {
          if (state is DetailedRecipeLoading) return Loader();
          if (state is DetailedRecipeSuccess) {
            return ListView(
              children: [
                Stack(
                  fit: StackFit.passthrough,
                  children: [
                    CachedNetworkImage(
                      imageUrl: widget.item.imageLink,
                      errorWidget: (context, url, trace) =>
                          Image.asset('assets/pngs/recipe_details_place_holder.png', fit: BoxFit.cover),
                      progressIndicatorBuilder: (context, url, progress) => SizedBox(height: imageHeight, child: Loader()),
                      imageBuilder: (context, imageProvider) => Container(
                        height: imageHeight,
                        decoration: BoxDecoration(borderRadius: AppBorderRadius.borderRadiusAll6),
                        child: Image(image: imageProvider),
                      ),
                    ),
                    Positioned(
                      bottom: 0,
                      child: Container(
                        height: imageHeight,
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.white, Colors.white.withOpacity(0)],
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 50,
                      left: 32,
                      right: 28,
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                              onPressed: () => Navigator.pop(context),
                              icon: Platform.isIOS ? Icon(Icons.arrow_back_ios) : Icon(Icons.arrow_back)),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(onPressed: () {}, icon: SvgPicture.asset('assets/svgs/share.svg')),
                              AppSpacing.horizontalSpace24,
                              IconButton(onPressed: () {}, icon: Icon(Icons.favorite_border)),
                            ],
                          )
                        ],
                      ),
                    ),
                    Positioned(
                      bottom: 28,
                      width: MediaQuery.of(context).size.width,
                      child: Padding(
                        padding: AppInsets.horizontalInsets28,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(widget.item.categoryName.toUpperCase(), style: TypographyTwCenW01Medium.caption2),
                            AppSpacing.verticalSpace16,
                            Text(widget.item.title, style: TypographyTwCenW01Medium.title1),
                            AppSpacing.verticalSpace24,
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                SvgPicture.asset('assets/svgs/kCal.svg'),
                                AppSpacing.horizontalSpace4,
                                Text('${state.calories} kCal', style: TypographyNeueHaasUnicaW1G.menu1),
                              ],
                            ),
                            AppSpacing.verticalSpace30,
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Expanded(
                                  child: CustomButton(
                                    text: 'Replace',
                                    textStyle: TypographyNeueHaasUnicaW1G.buttonBold,
                                    onTap: () {},
                                    borderRadius: AppBorderRadius.borderRadiusAll6,
                                    color: AppColors.greyLight.withOpacity(0.1),
                                  ),
                                ),
                                AppSpacing.horizontalSpace16,
                                Expanded(
                                  child: CustomButton(
                                    text: 'Exclude',
                                    textStyle: TypographyNeueHaasUnicaW1G.buttonBold,
                                    onTap: () {},
                                    borderRadius: AppBorderRadius.borderRadiusAll6,
                                    color: AppColors.greyLight.withOpacity(0.1),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: AppInsets.horizontalInsets28,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      AppSpacing.verticalSpace24,
                      Divider(thickness: 0.5),
                      AppSpacing.verticalSpace16,
                      Text('GOOD FOR', style: TypographyTwCenW01Medium.subtitle2),
                      AppSpacing.verticalSpace24,
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: widget.item.badFor.map<Widget>((e) => TagTile(tag: e, onTap: () {})).toList(),
                      ),
                      AppSpacing.verticalSpace24,
                      Divider(thickness: 0.5),
                      AppSpacing.verticalSpace16,
                      Text('NOT GOOD FOR', style: TypographyTwCenW01Medium.subtitle2),
                      AppSpacing.verticalSpace24,
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: widget.item.goodFor.map<Widget>((e) => TagTile(tag: e, onTap: () {})).toList(),
                      ),
                      AppSpacing.verticalSpace24,
                      Text(widget.item.title, style: TypographyTwCenW01Medium.title1),
                      AppSpacing.verticalSpace16,
                      Text(widget.item.description, style: TypographyNeueHaasUnicaW1G.basic2),
                      AppSpacing.verticalSpace24,
                      Divider(thickness: 0.5),
                      AppSpacing.verticalSpace16,
                      Text('Ingredients for the main dish'.toUpperCase(), style: TypographyTwCenW01Medium.subtitle2),
                      AppSpacing.verticalSpace20,
                      AppSpacing.verticalSpace12,
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: widget.item.primaryIngredients
                            .map<Widget>((e) => FoodItemElementTile(element: e, textStyle: TypographyNeueHaasUnicaW1G.basic3))
                            .toList(),
                      ),
                      AppSpacing.verticalSpace24,
                      Divider(thickness: 0.5),
                      // AppSpacing.verticalSpace16,
                      // Text('Ingredients for th...'.toUpperCase(), style: TypographyTwCenW01Medium.subtitle2),
                      // AppSpacing.verticalSpace20,
                      // AppSpacing.verticalSpace12,
                      // Column(
                      //   mainAxisSize: MainAxisSize.min,
                      //   children: widget.item.secondaryIngredients
                      //       .map<Widget>((e) => FoodItemElementTile(
                      //             element: e,
                      //             textStyle: TypographyNeueHaasUnicaW1G.basic3,
                      //             onOptionsClicked: () {},
                      //           ))
                      //       .toList(),
                      // ),
                      // AppSpacing.verticalSpace20,
                      // AppSpacing.verticalSpace20,
                      // AppSpacing.verticalSpace12,
                      // Divider(thickness: 0.5),
                      AppSpacing.verticalSpace16,
                      Text('METHOD', style: TypographyTwCenW01Medium.subtitle2),
                      AppSpacing.verticalSpace24,
                      Text(
                        widget.item.stepsTitle,
                        style: TypographyNeueHaasUnicaW1G.basic2.copyWith(fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                      ),
                      AppSpacing.verticalSpace24,
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          for (int i = 0; i < widget.item.numberOfSteps; i++)
                            RecipeStepDescription(step: widget.item.steps.singleWhere((element) => element.stepOrderNumber == i)),
                        ],
                      ),
                      AppSpacing.verticalSpace20,
                      if (state.proteins > 0) ...[
                        AppSpacing.verticalSpace20,
                        Divider(thickness: 0.5),
                        AppSpacing.verticalSpace20,
                        NutrientProgressIndicator(title: 'Protein', value: state.proteins),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: state.proteinsList
                              .map<Widget>((e) => FoodItemElementTile(
                                    element: FoodElement(
                                      title: e.title ?? '',
                                      amount: e.amount ?? 0,
                                      measurementType: e.unit ?? '',
                                    ),
                                    textStyle: TypographyNeueHaasUnicaW1G.basic3,
                                  ))
                              .toList(),
                        ),
                      ],
                      if (state.fats > 0) ...[
                        AppSpacing.verticalSpace24,
                        Divider(thickness: 0.5),
                        AppSpacing.verticalSpace20,
                        NutrientProgressIndicator(title: 'Fats', value: state.fats),
                        AppSpacing.verticalSpace20,
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: state.fatsList
                              .map<Widget>((e) => FoodItemElementTile(
                                    element: FoodElement(
                                      title: e.title ?? '',
                                      measurementType: e.unit ?? '',
                                      amount: e.amount ?? 0,
                                    ),
                                    textStyle: TypographyNeueHaasUnicaW1G.basic3,
                                  ))
                              .toList(),
                        ),
                      ],
                      AppSpacing.verticalSpace24,
                      if (state.carbohydrates > 0) ...[
                        AppSpacing.verticalSpace24,
                        Divider(thickness: 0.5),
                        AppSpacing.verticalSpace20,
                        NutrientProgressIndicator(title: 'Carbohydrates', value: state.carbohydrates),
                        AppSpacing.verticalSpace24,
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: state.carbohydratesList
                              .map<Widget>((e) => FoodItemElementTile(
                                    element: FoodElement(
                                      title: e.title ?? '',
                                      measurementType: e.unit ?? '',
                                      amount: e.amount ?? 0,
                                    ),
                                    textStyle: TypographyNeueHaasUnicaW1G.basic3,
                                  ))
                              .toList(),
                        ),
                      ],

                      // AppSpacing.verticalSpace20,
                      // Divider(thickness: 0.5),
                      // AppSpacing.verticalSpace24,
                      // NutrientProgressIndicator(title: 'Fibre', value: widget.item.fibre.toDouble()),
                      // AppSpacing.verticalSpace20,
                      // Divider(thickness: 0.5),
                      // AppSpacing.verticalSpace24,
                      // NutrientProgressIndicator(title: 'Salt', value: widget.item.salt.toDouble()),
                      ContentSection(
                        title: state.otherRecommendations.categoryName,
                        children: state.otherRecommendations.items
                            .map<Widget>(
                              (e) => VerticalSmallContentCard(
                                placeholderPath: 'assets/pngs/recipe_small_placeholder.png',
                                post: e,
                                onLikePressed: () {},
                                onTap: () {},
                              ),
                            )
                            .toList(),
                        subCategories: state.otherRecommendations.subcategoryItems,
                        titleStyle: TypographyTwCenW01Medium.title3,
                      ),
                      AppSpacing.verticalSpace24,
                      CustomButton(
                        text: 'Save',
                        onTap: () {},
                        borderRadius: AppBorderRadius.borderRadiusAll6,
                        color: AppColors.oliveColor,
                        height: 50,
                        width: MediaQuery.of(context).size.width,
                        textStyle: TypographyNeueHaasUnicaW1G.buttonBold,
                      ),
                      AppSpacing.verticalSpace24,
                    ],
                  ),
                ),
              ],
            );
          }
          return Container();
        },
      ),
    );
  }
}
