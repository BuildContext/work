import 'package:flutter/material.dart';
import 'package:test_project/core/models/recipe_category_item.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';

class RecipeStepDescription extends StatelessWidget {
  final RecipeStep step;

  const RecipeStepDescription({Key? key, required this.step}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text('${step.stepOrderNumber + 1}', style: Theme.of(context).textTheme.subtitle2?.copyWith(fontSize: 18)),
        AppSpacing.verticalSpace24,
        if (step.title.isNotEmpty) Text(step.title, style: Theme.of(context).textTheme.subtitle2?.copyWith(fontSize: 16)),
        if (step.title.isNotEmpty) AppSpacing.verticalSpace24,
        if (step.description.isNotEmpty) Text(step.description, style: Theme.of(context).textTheme.subtitle2),
        if (step.description.isNotEmpty) AppSpacing.verticalSpace24,
      ],
    );
  }
}
