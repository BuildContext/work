import 'package:test_project/core/models/category_models.dart';
import 'package:test_project/core/models/ingredient.dart';

abstract class DetailedRecipePageState {}

class DetailedRecipeInitial extends DetailedRecipePageState {}

class DetailedRecipeLoading extends DetailedRecipePageState {}

class DetailedRecipeSuccess extends DetailedRecipePageState {
  final RecipeCategory otherRecommendations;
  final double fats;
  final double proteins;
  final double carbohydrates;
  final double calories;
  final List<Nutrient> fatsList;
  final List<Nutrient> proteinsList;
  final List<Nutrient> carbohydratesList;

  DetailedRecipeSuccess({
    required this.calories,
    required this.fats,
    required this.fatsList,
    required this.carbohydratesList,
    required this.proteinsList,
    required this.proteins,
    required this.carbohydrates,
    required this.otherRecommendations,
  });
}

class DetailedRecipeError extends DetailedRecipePageState {
  final String error;

  DetailedRecipeError({required this.error});
}
