import 'package:bloc/bloc.dart';
import 'package:test_project/core/models/ingredient.dart';
import 'package:test_project/domain/services/ingredients_service.dart';
import 'package:test_project/domain/services/recipe_service.dart';

import 'detailed_recipe_page_state.dart';

class DetailedRecipePageCubit extends Cubit<DetailedRecipePageState> {
  DetailedRecipePageCubit() : super(DetailedRecipeInitial());

  /// [ingredientAmounts] is map that stores ingredient id as key and it's amount as value
  /// So, [ingredientAmounts] has following format
  /// {'ingredient_id': 'ingredient_amount'}

  Future<void> loadData({required List<String> recipeIngredientsIds, required Map<String, double> ingredientAmounts}) async {
    emit(DetailedRecipeLoading());
    final recommendations = await RecipeService.instance.getOtherRecommendations();
    final List<IngredientResult> ingredients = List.empty(growable: true);
    final List<Nutrient> proteinsList = List.empty(growable: true);
    final List<Nutrient> carbohydratesList = List.empty(growable: true);
    final List<Nutrient> fatsList = List.empty(growable: true);
    for (final id in recipeIngredientsIds) {
      final ingredientData = await IngredientService.instance.loadIngredientById(id);
      if (ingredientData.isLeft()) break;
      ingredientData.fold(
        (l) => emit(DetailedRecipeError(error: l.error)),
        (r) => ingredients.add(r),
      );
    }
    double fats = 0;
    double proteins = 0;
    double carbohydrates = 0;
    double calories = 0;
    for (final ingredient in ingredients) {
      final nutrientScale = (ingredientAmounts['${ingredient.id}'] ?? 0) / 100;
      calories += (ingredient.energy ?? 0) * nutrientScale;
      for (final protein in ingredient.proteins) {
        final index = proteinsList.indexWhere((element) => element.title == protein.title);
        if (index.isNegative) {
          proteinsList.add(protein.copyWith(amount: (protein.amount ?? 0) * nutrientScale));
        } else {
          final nutrient = proteinsList.elementAt(index);
          proteinsList[index] = nutrient.copyWith(amount: (protein.amount ?? 0) + ((nutrient.amount ?? 0) * nutrientScale));
        }
      }
      for (final fat in ingredient.fats) {
        final index = fatsList.indexWhere((element) => element.title == fat.title);
        if (index.isNegative) {
          fatsList.add(fat.copyWith(amount: (fat.amount ?? 0) * nutrientScale));
        } else {
          final nutrient = fatsList.elementAt(index);
          fatsList[index] = nutrient.copyWith(amount: (fat.amount ?? 0) + ((nutrient.amount ?? 0) * nutrientScale));
        }
      }
      for (final carbohydrate in ingredient.carbohydrates) {
        final index = carbohydratesList.indexWhere((element) => element.title == carbohydrate.title);
        if (index.isNegative) {
          carbohydratesList.add(carbohydrate.copyWith(amount: (carbohydrate.amount ?? 0) * nutrientScale));
        } else {
          final nutrient = carbohydratesList.elementAt(index);
          carbohydratesList[index] = nutrient.copyWith(amount: (carbohydrate.amount ?? 0) + ((nutrient.amount ?? 0) * nutrientScale));
        }
      }
    }
    for (final protein in proteinsList) proteins += (protein.amount ?? 0);
    for (final carbohydrates in carbohydratesList) proteins += (carbohydrates.amount ?? 0);
    for (final fats in fatsList) proteins += (fats.amount ?? 0);

    emit(DetailedRecipeSuccess(
      calories: calories,
      proteinsList: proteinsList,
      carbohydratesList: carbohydratesList,
      fatsList: fatsList,
      otherRecommendations: recommendations,
      fats: fats,
      proteins: proteins,
      carbohydrates: carbohydrates,
    ));
  }
}
