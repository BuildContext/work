import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/presentation/custom_widgets/filter_sheet.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/custom_widgets/search_sheet.dart';
import 'package:test_project/presentation/pages/ayumeal/recipe/recipe.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

import 'cubit/ayumeal_main_page_cubit.dart';
import 'cubit/ayumeal_main_page_state.dart';
import 'ingredient/ingredients.dart';

class AyumealMainPage extends StatefulWidget {
  const AyumealMainPage({Key? key}) : super(key: key);

  @override
  _RecipesMainPAgeState createState() => _RecipesMainPAgeState();
}

class _RecipesMainPAgeState extends State<AyumealMainPage> with TickerProviderStateMixin {
  late TabController tabController;
  final cubit = AyumealMainPageCubit();

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 2, vsync: this);
    cubit.loadData();
  }

  @override
  void dispose() {
    tabController.dispose();
    cubit.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ayumeal'),
        actions: [
          IconButton(
            onPressed: () => AppInteractionsHelper.showBottomSheet(
              context: context,
              child: FilterSheet(),
              hasBlurBarrier: true,
              title: 'filter'.tr(),
            ),
            icon: SvgPicture.asset('assets/svgs/filter.svg'),
          ),
          IconButton(
            onPressed: () => AppInteractionsHelper.showBottomSheet(
              context: context,
              child: SearchSheet(),
              hasBlurBarrier: true,
              title: 'search'.tr(),
            ),
            icon: SvgPicture.asset('assets/svgs/search.svg'),
          ),
        ],
      ),
      body: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          AppSpacing.verticalSpace24,
          SizedBox(
            height: 24,
            child: TabBar(
              padding: AppInsets.horizontalInsets28,
              controller: tabController,
              indicatorColor: AppColors.darkLight,
              labelStyle: TypographyTwCenW01Medium.caption2,
              unselectedLabelStyle: TypographyTwCenW01Medium.caption2.copyWith(color: AppColors.greyLight),
              labelColor: AppColors.dark,
              unselectedLabelColor: AppColors.darkLight.withOpacity(0.5),
              labelPadding: AppInsets.insetsOnlyBottom8,
              indicatorPadding: EdgeInsets.zero,
              indicatorWeight: 1.5,
              tabs: [
                Tab(text: 'RECIPES', iconMargin: EdgeInsets.zero),
                Tab(text: 'INGREDIENTS', iconMargin: EdgeInsets.zero),
              ],
            ),
          ),
          BlocConsumer<AyumealMainPageCubit, AyumealMainPageState>(
            bloc: cubit,
            listener: (context, state) {},
            builder: (context, state) {
              if (state is AyumealMainLoading) return Expanded(child: Loader());
              if (state is AyumealMainSuccess)
                return Expanded(
                  child: TabBarView(
                    controller: tabController,
                    children: [
                      RecipesTab(
                        onRefresh: () => cubit.loadData(),
                        recipes: state.recipes,
                        quiz: state.quiz,
                        recommendations: state.recommendations,
                      ),
                      IngredientsTab(
                        onRefresh: () => cubit.loadData(),
                        ingredients: state.ingredients,
                        suggestedTitles: state.suggestedTitles,
                        quiz: state.quiz,
                      ),
                    ],
                  ),
                );
              return Container();
            },
          ),
        ],
      ),
    );
  }
}
