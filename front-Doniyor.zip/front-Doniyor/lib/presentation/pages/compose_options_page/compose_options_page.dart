import 'dart:math';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/chart_models/mini_chart_data.dart';
import 'package:test_project/core/models/post.dart';
import 'package:test_project/core/models/quiz.dart';
import 'package:test_project/core/models/quiz_option.dart';
import 'package:test_project/presentation/custom_widgets/bottom_sheet_container.dart';
import 'package:test_project/presentation/custom_widgets/dosha_card.dart';
import 'package:test_project/presentation/custom_widgets/horizontal_small_content_card.dart';
import 'package:test_project/presentation/custom_widgets/quiz_card.dart';
import 'package:test_project/presentation/pages/ayuplan/widget/mini_stacked_chart.dart';
import 'package:test_project/presentation/pages/quiz_pages/quiz_page_selector.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class ComposeOptionsPage extends StatefulWidget {
  const ComposeOptionsPage({Key? key}) : super(key: key);

  @override
  State<ComposeOptionsPage> createState() => _ComposeOptionsPageState();
}

class _ComposeOptionsPageState extends State<ComposeOptionsPage> {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        Spacer(),
        BottomSheetContainer(
          child: SizedBox(
            height: MediaQuery.of(context).size.height * 0.6,
            width: MediaQuery.of(context).size.width,
            child: ListView(
              children: [
                SizedBox(
                  height: 210,
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(
                        child: ProfileStatCard(
                          icon: Stack(
                            children: [
                              Image.asset('assets/pngs/lines/blue_line.png'),
                              Image.asset('assets/pngs/lines/pink_line.png'),
                              Center(child: Image.asset('assets/pngs/lines/slider.png')),
                              Center(child: Image.asset('assets/pngs/lines/slider_shadow.png')),
                              Image.asset('assets/pngs/lines/yellow_line.png'),
                            ],
                          ),
                          footer: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text('Kapha Time', style: TypographyNeueHaasUnicaW1G.basic2),
                              Text('10:45', style: TypographyNeueHaasUnicaW1G.menu3),
                            ],
                          ),
                          header: 'AYURTIME',
                        ),
                      ),
                      AppSpacing.horizontalSpace16,
                      Expanded(
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Expanded(
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Expanded(
                                    child: ProfileStatCard(
                                      icon: Flexible(child: SvgPicture.asset('assets/svgs/vata.svg')),
                                      header: 'dosha'.tr().toUpperCase(),
                                      footer: Text(
                                        'Thamasik',
                                        style: TypographyNeueHaasUnicaW1G.menu3,
                                      ),
                                    ),
                                  ),
                                  AppSpacing.horizontalSpace16,
                                  Expanded(
                                    child: ProfileStatCard(
                                      icon: Flexible(child: SvgPicture.asset('assets/svgs/pie_chart_icon.svg')),
                                      header: 'current'.tr().toUpperCase(),
                                      footer: Text(
                                        '25%',
                                        style: TypographyNeueHaasUnicaW1G.menu3,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            AppSpacing.verticalSpace16,
                            Expanded(
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Expanded(
                                    child: ProfileStatCard(
                                      icon: Flexible(child: SvgPicture.asset('assets/svgs/Angry.svg')),
                                      header: 'mood'.tr().toUpperCase(),
                                      footer: Text(
                                        'Angry',
                                        style: TypographyNeueHaasUnicaW1G.menu3,
                                      ),
                                    ),
                                  ),
                                  AppSpacing.horizontalSpace16,
                                  Expanded(
                                    child: ProfileStatCard(
                                      icon: Flexible(child: SvgPicture.asset('assets/svgs/rajas.svg')),
                                      header: 'gune'.tr().toUpperCase(),
                                      footer: Text(
                                        'Rajasik',
                                        style: TypographyNeueHaasUnicaW1G.menu3,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                AppSpacing.verticalSpace16,
                SizedBox(
                  height: 97,
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(
                        child: ProfileStatCard(
                          icon: MiniStackedChart(
                            data: List<MiniChartDataSeries>.generate(
                              7,
                              (index) => MiniChartDataSeries(
                                items: List.generate(
                                  3,
                                  (index) => MiniChartDataItem(
                                    color: index == 0
                                        ? AppColors.lavender
                                        : index == 1
                                            ? AppColors.orangeLight
                                            : AppColors.ice,
                                    percentage: min((0.33 - (Random().nextInt(100) / 100)).abs(), 0.33),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          header: 'gune'.tr().toUpperCase(),
                          footer: Text(
                            'Weekly',
                            style: TypographyNeueHaasUnicaW1G.menu3,
                          ),
                        ),
                      ),
                      AppSpacing.horizontalSpace16,
                      Expanded(
                        child: ProfileStatCard(
                          icon: MiniStackedChart(
                            data: List<MiniChartDataSeries>.generate(
                              7,
                              (index) => MiniChartDataSeries(
                                items: List.generate(
                                  3,
                                  (index) => MiniChartDataItem(
                                    color: index == 0
                                        ? AppColors.lavender
                                        : index == 1
                                            ? AppColors.orangeLight
                                            : AppColors.ice,
                                    percentage: min((0.33 - (Random().nextInt(100) / 100)).abs(), 0.33),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          header: 'nutrition'.tr(),
                          footer: Text(
                            'Weekly',
                            style: TypographyNeueHaasUnicaW1G.menu3,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                AppSpacing.verticalSpace16,
                QuizCard(
                  quiz: Quiz(
                    title: 'Quiz',
                    description:
                        'nvlsabdsfbdbsbadfbdsgbsfgnabj nk kjsjdkfs jhbf hjs db ghdbf ghjdb gjhsdbf gjh sdb gjhsdfb gjhdb aknsdj nlaks ndgkjdfsngjk dnfg kjasnd gkjsndgjkdfngkjdsngjkdsngkdjfsg jkdsfngjkdfngkjdsnfgk jdsnf gkj ndsfjk gndfjgk dnf gkjds nfgkj sndfk',
                    icons: [
                      ContentCategoryIcon(iconPath: 'sunset', isLocal: true),
                      ContentCategoryIcon(iconPath: 'wind', isLocal: true),
                    ],
                    colorHex: '#F2E3E8',
                    time: Duration(minutes: 50),
                    options: List.generate(
                      5,
                      (index) => SelectableQuizOption(
                        isSelected: false,
                        title: 'title $index',
                        value: index.toString(),
                      ),
                    ),
                    type: QuizTypes.getByIndex(0),
                  ),
                ),
                AppSpacing.verticalSpace16,
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      for (int i = 0; i < 5; i++)
                        HorizontalSmallContentCard(
                          post: PostCategoryItem(
                            categoryName: 'Popular',
                            id: '123',
                            author: PostAuthor(
                              avatar: '',
                              name: 'Name Surname',
                              position: 'Position',
                              description: 'avsdbfsffsdfgdfbgdvs vsds vsd sd vsd gdfgdsfgsdfvgdsvgf vsd gvsdfvg svdfg vsdfgvsdfvg',
                            ),
                            instructions: List.generate(
                              5,
                              (index) => PostInstruction(
                                time: Duration(minutes: ++index * 2),
                                icons: [
                                  ContentCategoryIcon(iconPath: 'ether', isLocal: true),
                                  ContentCategoryIcon(iconPath: 'morning', isLocal: true),
                                  ContentCategoryIcon(iconPath: 'winter', isLocal: true),
                                ],
                                title: 'njklnkjvsnds nkjknjlnkljnjkl',
                                imageLink: 'asvbfdngfhmg',
                              ),
                            ),
                            isLiked: false,
                            imageLink: 'Popular',
                            title: 'Generated title',
                            description: 'asvsdjkdnfvjkdfnbkjdnfbkjdnfbjkndkjfbdfbfdbdfbdf\ndsvklndsbjlnfjlbnsdklnsdlvkm',
                            time: Duration(minutes: DateTime.now().minute),
                            goodFor: List.generate(
                              3,
                              (index) =>
                                  ContentCategoryTag(title: 'title $index', iconLink: index % 2 == 0 ? 'assets/svgs/leaf.svg' : null),
                            ),
                            icons: [
                              ContentCategoryIcon(iconPath: 'ether', isLocal: true),
                              ContentCategoryIcon(iconPath: 'morning', isLocal: true),
                              ContentCategoryIcon(iconPath: 'winter', isLocal: true),
                            ],
                          ),
                          onLikePressed: () {},
                          onTap: () {},
                          placeholderPath: 'assets/pngs/recipe_small_placeholder.png',
                        ),
                    ],
                  ),
                ),
                AppSpacing.verticalSpace12,
                AppSpacing.verticalSpace24,
                Text(
                  'How do you feel?',
                  textAlign: TextAlign.center,
                  style: TypographyNeueHaasUnicaW1G.link1,
                ),
                AppSpacing.verticalSpace16,
                AppSpacing.verticalSpace16,
              ],
            ),
          ),
        ),
      ],
    );
  }
}
