import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:persistent_bottom_nav_bar/persistent-tab-view.dart';
import 'package:test_project/presentation/custom_widgets/custom_bottom_nav_bar.dart';
import 'package:test_project/presentation/pages/ayumeal/ayumeal_page.dart';
import 'package:test_project/presentation/pages/ayuplan/ayuplan.dart';
import 'package:test_project/presentation/pages/ayuworld/ayuworld.dart';
import 'package:test_project/presentation/pages/compose_options_page/compose_options_page.dart';
import 'package:test_project/presentation/pages/profile/profile_page.dart';
import 'package:test_project/presentation/theme/app_theme.dart';

class RootPage extends StatefulWidget {
  const RootPage({Key? key}) : super(key: key);

  @override
  _RootPageState createState() => _RootPageState();
}

class _RootPageState extends State<RootPage> {
  final PersistentTabController _controller = PersistentTabController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: PersistentTabView.custom(
          context,
          controller: _controller,
          navBarHeight: 84,
          customWidget: CustomBottomNavigationBar(
            onIndexChanged: (index) => setState(() => _controller.index = index),
            items: [
              CustomNavigationBarItem(icon: 'assets/svgs/home.svg'),
              CustomNavigationBarItem(icon: 'assets/svgs/library.svg'),
              CustomNavigationBarItem(
                child: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(color: AppColors.oliveColor, shape: BoxShape.circle),
                  child: Center(child: SvgPicture.asset('assets/svgs/add.svg')),
                ),
              ),
              CustomNavigationBarItem(icon: 'assets/svgs/recommendations.svg'),
              CustomNavigationBarItem(icon: 'assets/svgs/profile.svg'),
            ],
          ),
          screens: [
            AyuplanPage(),
            AyuWorldPage(),
            ComposeOptionsPage(),
            AyumealMainPage(),
            ProfilePage(),
          ],
          itemCount: 5,
          resizeToAvoidBottomInset: true,
          handleAndroidBackButtonPress: true,
          stateManagement: true,
        ),
      ),
    );
  }
}
