import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';

class PainPointSheet extends StatelessWidget {
  const PainPointSheet({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        PainPointAction(
          title: 'home_remedies'.tr(),
          onTap: () {},
        ),
        AppSpacing.verticalSpace30,
        PainPointAction(
          title: 'recipes'.tr(),
          onTap: () {},
        ),
        AppSpacing.verticalSpace30,
        PainPointAction(
          title: 'ingredients'.tr(),
          onTap: () {},
        ),
        AppSpacing.verticalSpace30,
        PainPointAction(
          title: 'about_this_complaint'.tr(),
          onTap: () {},
        ),
        AppSpacing.verticalSpace30,
        PainPointAction(
          title: 'evaluate_condition'.tr(),
          onTap: () {},
        ),
        AppSpacing.verticalSpace30,
      ],
    );
  }
}

class PainPointAction extends StatelessWidget {
  final String title;
  final VoidCallback onTap;

  const PainPointAction({
    Key? key,
    required this.title,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      color: Colors.white,
      child: InkWell(
        onTap: onTap,
        child: Ink(
          height: 20,
          color: Colors.white,
          padding: AppInsets.onlyLeftInset8,
          child: Text(
            title,
            style: TypographyNeueHaasUnicaW1G.basic1,
          ),
        ),
      ),
    );
  }
}
