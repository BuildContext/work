import 'package:flutter/material.dart';
import 'package:test_project/core/models/chart_models/custom_pie_chart_data.dart';
import 'package:test_project/presentation/custom_widgets/ayulife_chart_legend_item.dart';
import 'package:test_project/presentation/pages/profile/dosha/widgets/chart_sorting_dome_button.dart';
import 'package:test_project/presentation/pages/profile/widgets/custom_pie_chart.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:touchable/touchable.dart';

class CoupledPieChart extends StatefulWidget {
  final List<CustomPieChartDataItem> firstChartItems, secondChartItems;

  const CoupledPieChart({
    Key? key,
    required this.firstChartItems,
    required this.secondChartItems,
  }) : super(key: key);

  @override
  State<CoupledPieChart> createState() => _CoupledPieChartState();
}

class _CoupledPieChartState extends State<CoupledPieChart> {
  String selectedMode = '1Y';
  int selectedFirstChartItem = 0;
  int selectedSecondChartItem = 1;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CanvasTouchDetector(
                    builder: (BuildContext context) {
                      return CustomPaint(
                        size: Size(112, 112),
                        painter: CustomPieChartPainter(
                          series: widget.firstChartItems,
                          context: context,
                          onSelected: (itemIndex) => setState(() => selectedFirstChartItem = itemIndex),
                          selectedIndex: 0,
                        ),
                      );
                    },
                    gesturesToOverride: [
                      GestureType.onTapDown,
                      GestureType.onTapUp,
                    ],
                  ),
                  AppSpacing.verticalSpace16,
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      for (final item in widget.firstChartItems)
                        AyulifeChartLegendItem(
                          isSelected: widget.firstChartItems.indexOf(item) == 0,
                          title: item.title,
                          dataText: '${item.value} %\n',
                          color: item.color,
                        ),
                    ],
                  )
                ],
              ),
            ),
            AppSpacing.horizontalSpace24,
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CanvasTouchDetector(
                    builder: (BuildContext context) {
                      return CustomPaint(
                        size: Size(112, 112),
                        painter: CustomPieChartPainter(
                          series: widget.secondChartItems,
                          context: context,
                          onSelected: (itemIndex) => setState(() => selectedSecondChartItem = itemIndex),
                          selectedIndex: 1,
                        ),
                      );
                    },
                    gesturesToOverride: [
                      GestureType.onTapDown,
                      GestureType.onTapUp,
                    ],
                  ),
                  AppSpacing.verticalSpace16,
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      for (final item in widget.secondChartItems)
                        AyulifeChartLegendItem(
                          isSelected: widget.secondChartItems.indexOf(item) == 1,
                          title: item.title,
                          dataText: '${item.value} %\n',
                          color: item.color,
                        ),
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
        AppSpacing.verticalSpace16,
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ChartSortingModeButton(
              modeName: '1D',
              onTap: () => setState(() => selectedMode = '1D'),
              isSelected: '1D' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: '1W',
              onTap: () => setState(() => selectedMode = '1W'),
              isSelected: '1W' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: '1M',
              onTap: () => setState(() => selectedMode = '1M'),
              isSelected: '1M' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: '1Y',
              onTap: () => setState(() => selectedMode = '1Y'),
              isSelected: '1Y' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: 'All',
              onTap: () => setState(() => selectedMode = 'All'),
              isSelected: 'All' == selectedMode,
            ),
          ],
        ),
      ],
    );
  }
}
