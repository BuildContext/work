import 'package:flutter/material.dart';
import 'package:test_project/core/models/chart_models/custom_pie_chart_data.dart';
import 'package:test_project/presentation/custom_widgets/ayulife_chart_legend_item.dart';
import 'package:test_project/presentation/pages/profile/dosha/widgets/chart_sorting_dome_button.dart';
import 'package:test_project/presentation/pages/profile/widgets/custom_pie_chart.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:touchable/touchable.dart';

class EmotionPieChart extends StatefulWidget {
  final List<CustomPieChartDataItem> series;

  const EmotionPieChart({
    Key? key,
    required this.series,
  }) : super(key: key);

  @override
  State<EmotionPieChart> createState() => _EmotionPieChartState();
}

class _EmotionPieChartState extends State<EmotionPieChart> {
  int selectedSeriesIndex = 0;
  String selectedMode = '1Y';

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (int i = 0; i < widget.series.length ~/ 2; i++)
                  AyulifeChartLegendItem(
                    title: widget.series.elementAt(i).title,
                    dataText: '${widget.series.elementAt(i).value} %\n',
                    isSelected: i == selectedSeriesIndex,
                    color: widget.series.elementAt(i).color,
                  ),
              ],
            ),
            SizedBox(
              height: 151,
              width: 151,
              child: CanvasTouchDetector(
                builder: (context) => CustomPaint(
                  painter: CustomPieChartPainter(
                    context: context,
                    series: widget.series,
                    onSelected: (value) => setState(() => selectedSeriesIndex = value),
                    selectedIndex: selectedSeriesIndex,
                  ),
                ),
                gesturesToOverride: [
                  GestureType.onTapDown,
                  GestureType.onTapUp,
                ],
              ),
            ),
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (int i = widget.series.length ~/ 2; i < widget.series.length; i++)
                  AyulifeChartLegendItem(
                    title: widget.series.elementAt(i).title,
                    dataText: '${widget.series.elementAt(i).value} %\n',
                    isSelected: i == selectedSeriesIndex,
                    color: widget.series.elementAt(i).color,
                  ),
              ],
            ),
          ],
        ),
        AppSpacing.verticalSpace16,
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ChartSortingModeButton(
              modeName: '1D',
              onTap: () => setState(() => selectedMode = '1D'),
              isSelected: '1D' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: '1W',
              onTap: () => setState(() => selectedMode = '1W'),
              isSelected: '1W' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: '1M',
              onTap: () => setState(() => selectedMode = '1M'),
              isSelected: '1M' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: '1Y',
              onTap: () => setState(() => selectedMode = '1Y'),
              isSelected: '1Y' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: 'All',
              onTap: () => setState(() => selectedMode = 'All'),
              isSelected: 'All' == selectedMode,
            ),
          ],
        ),
      ],
    );
  }
}
