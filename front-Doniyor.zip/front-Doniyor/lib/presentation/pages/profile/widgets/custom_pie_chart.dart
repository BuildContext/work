import 'dart:math';

import 'package:flutter/material.dart';
import 'package:test_project/core/models/chart_models/custom_pie_chart_data.dart';
import 'package:test_project/presentation/custom_widgets/ayulife_chart_legend_item.dart';
import 'package:test_project/presentation/pages/profile/dosha/widgets/chart_sorting_dome_button.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:touchable/touchable.dart';

class CustomPieChart extends StatefulWidget {
  final List<CustomPieChartDataItem> series;
  final ValueChanged<CustomPieChartDataItem> onDataItemSelected;

  const CustomPieChart({
    Key? key,
    required this.series,
    required this.onDataItemSelected,
  }) : super(key: key);

  @override
  State<CustomPieChart> createState() => _CustomPieChartState();
}

class _CustomPieChartState extends State<CustomPieChart> {
  String selectedMode = '1Y';
  late CustomPieChartDataItem selectedItem = widget.series.first;
  int selectedIndex = -1;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SizedBox(
          width: MediaQuery.of(context).size.width,
          height: 151,
          child: Row(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (final series in widget.series)
                    AyulifeChartLegendItem(
                      isSelected: selectedIndex == widget.series.indexOf(series),
                      title: series.title,
                      dataText: '${series.value} %\n',
                      color: series.color,
                    ),
                ],
              ),
              SizedBox(
                width: 151,
                height: 151,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    CanvasTouchDetector(
                      builder: (BuildContext context) => CustomPaint(
                        willChange: true,
                        painter: CustomPieChartPainter(
                          selectedIndex: selectedIndex,
                          series: widget.series,
                          context: context,
                          onSelected: (index) => setState(() => selectedIndex = index),
                        ),
                      ),
                      gesturesToOverride: [
                        GestureType.onTapDown,
                        GestureType.onTapUp,
                      ],
                    ),
                    Center(
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(text: getMyGuna(), style: TypographyNeueHaasUnicaW1G.basic2),
                            TextSpan(
                              text: '\nMy guna',
                              style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.dark.withOpacity(0.5)),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        AppSpacing.verticalSpace16,
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ChartSortingModeButton(
              modeName: '1D',
              onTap: () => setState(() => selectedMode = '1D'),
              isSelected: '1D' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: '1W',
              onTap: () => setState(() => selectedMode = '1W'),
              isSelected: '1W' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: '1M',
              onTap: () => setState(() => selectedMode = '1M'),
              isSelected: '1M' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: '1Y',
              onTap: () => setState(() => selectedMode = '1Y'),
              isSelected: '1Y' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: 'All',
              onTap: () => setState(() => selectedMode = 'All'),
              isSelected: 'All' == selectedMode,
            ),
          ],
        ),
      ],
    );
  }

  String getMyGuna() {
    final biggestGune = widget.series.fold<CustomPieChartDataItem>(
      widget.series.first,
      (previousValue, element) => previousValue.value > element.value ? previousValue : element,
    );
    return biggestGune.title;
  }
}

class CustomPieChartPainter extends CustomPainter {
  final List<CustomPieChartDataItem> series;
  final BuildContext context;
  final int selectedIndex;
  final ValueChanged<int> onSelected;

  CustomPieChartPainter({
    required this.series,
    required this.context,
    required this.onSelected,
    required this.selectedIndex,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final touchyCanvas = TouchyCanvas(context, canvas);
    List<double> radians = List.from(
      series.map((e) => 2 * pi * (e.value / 100)),
    );
    var rect = Rect.fromLTWH(8, 8, size.width - 16, size.height - 16);

    double startAngle = 0;
    var useCenter = false;
    var paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 16;

    for (int i = 0; i < series.length; i++) {
      paint.color = series.elementAt(i).color;
      if (i > 0) startAngle += radians.elementAt(i - 1);
      if (selectedIndex == i)
        paint.strokeWidth = 16;
      else
        paint.strokeWidth = 8;
      touchyCanvas.drawArc(
        rect,
        startAngle,
        radians.elementAt(i),
        useCenter,
        paint,
        onTapDown: (details) => onSelected(i),
        onTapUp: (details) => onSelected(i),
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
