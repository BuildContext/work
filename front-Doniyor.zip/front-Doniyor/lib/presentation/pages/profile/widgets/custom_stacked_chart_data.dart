import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/core/models/chart_models/profile_line_chart_data.dart';
import 'package:test_project/presentation/custom_widgets/ayulife_chart_legend_item.dart';
import 'package:test_project/presentation/pages/profile/dosha/widgets/chart_sorting_dome_button.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class CustomStackedChart extends StatefulWidget {
  final List<CustomProfileChartDataSeries> series;
  final ValueChanged<CustomProfileChartDataItem> onDataItemSelected;

  const CustomStackedChart({
    Key? key,
    required this.series,
    required this.onDataItemSelected,
  }) : super(key: key);

  @override
  State<CustomStackedChart> createState() => _CustomStackedChartState();
}

class _CustomStackedChartState extends State<CustomStackedChart> {
  late CustomProfileChartDataSeries selectedSeries = widget.series.first;
  CustomProfileChartDataItem? selectedItem;
  String selectedMode = '1Y';
  Map<String, List<CustomProfileChartDataItem>> _items = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance?.addPostFrameCallback((timeStamp) => _sortStuff());
  }

  _sortStuff() {
    for (int i = 1; i <= 12; i++) {
      for (final series in widget.series) {
        if (_items.containsKey('$i')) {
          _items['$i']!.addAll(series.items.where((element) => element.date.month == i));
        } else {
          _items['$i'] = List<CustomProfileChartDataItem>.from(series.items.where((element) => element.date.month == i));
        }
      }
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: 176,
          width: MediaQuery.of(context).size.width,
          child: Row(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  AppSpacing.verticalSpace12,
                  for (int i = 10; i >= 0; i--)
                    Text(
                      '${i * 10} %',
                      style: TypographyNeueHaasUnicaW1G.caption4.copyWith(
                        color: (i * 10) < (selectedItem?.value ?? 0) && (selectedItem?.value ?? 0) < (i + 1)
                            ? AppColors.dark
                            : AppColors.greyLight,
                      ),
                    ),
                ],
              ),
              Expanded(
                child: LayoutBuilder(
                  builder: (context, size) {
                    return Row(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: _items.keys
                          .map(
                            (key) => SizedBox(
                              width: size.maxWidth / 12,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Text(
                                    '${DateFormat.MMM(context.locale.languageCode).format(DateFormat('M').parse(key))}'.toUpperCase(),
                                    style: TypographyNeueHaasUnicaW1G.caption4.copyWith(
                                      color: AppColors.greyLight,
                                    ),
                                  ),
                                  Spacer(),
                                  for (final item in _items[key]!)
                                    Container(
                                      height: ((size.maxHeight - 20) / 100) * item.value,
                                      margin: AppInsets.horizontalInsets8,
                                      color: item.color,
                                    ),
                                ],
                              ),
                            ),
                          )
                          .toList(),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        AppSpacing.verticalSpace14,
        Padding(
          padding: AppInsets.horizontalInsets28,
          child: Text(
            getYearStamp(),
            textAlign: TextAlign.left,
            style: TypographyNeueHaasUnicaW1G.caption4.copyWith(color: AppColors.greyLight),
          ),
        ),
        AppSpacing.verticalSpace24,
        AppSpacing.verticalSpace10,
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ChartSortingModeButton(
              modeName: '1D',
              onTap: () => setState(() => selectedMode = '1D'),
              isSelected: '1D' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: '1W',
              onTap: () => setState(() => selectedMode = '1W'),
              isSelected: '1W' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: '1M',
              onTap: () => setState(() => selectedMode = '1M'),
              isSelected: '1M' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: '1Y',
              onTap: () => setState(() => selectedMode = '1Y'),
              isSelected: '1Y' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: 'All',
              onTap: () => setState(() => selectedMode = 'All'),
              isSelected: 'All' == selectedMode,
            ),
          ],
        ),
        AppSpacing.verticalSpace16,
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            for (final series in widget.series)
              AyulifeChartLegendItem(
                isSelected: selectedSeries.title == series.title,
                title: series.title,
                dataText: '',
                color: series.highlightColor,
              ),
          ],
        ),
      ],
    );
  }

  String getYearStamp() {
    List<int> years = List.empty(growable: true);
    for (final series in widget.series)
      for (final seriesItem in series.items) if (!years.contains(seriesItem.date.year)) years.add(seriesItem.date.year);
    if (years.length == 1) {
      return years.first.toString();
    } else {
      final minYear =
          years.fold<int>(DateTime.now().year, (previousValue, element) => previousValue > element ? element : previousValue);
      final maxYEar =
          years.fold<int>(DateTime.now().year, (previousValue, element) => previousValue < element ? element : previousValue);
      return '$minYear - $maxYEar';
    }
  }
}
