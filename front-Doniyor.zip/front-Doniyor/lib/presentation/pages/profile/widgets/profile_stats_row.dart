import 'package:flutter/material.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/theme/app_theme.dart';

class ProfileStatsModeRow extends StatefulWidget {
  const ProfileStatsModeRow({Key? key}) : super(key: key);

  @override
  State<ProfileStatsModeRow> createState() => _ProfileStatsModeRowState();
}

class _ProfileStatsModeRowState extends State<ProfileStatsModeRow> {
  ProfileStatMode _currentMode = ProfileStatMode.rename;
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.start,
      children: ProfileStatMode.values
          .map<Widget>(
            (e) => CustomButton(
              onTap: () => setState(() => _currentMode = e),
              color: _currentMode == e ? AppColors.oliveLight : Colors.white,
              showBorder: false,
              text: titleOfMode(e),
            ),
          )
          .toList(),
    );
  }

  String titleOfMode(ProfileStatMode mode) {
    switch (mode) {
      case ProfileStatMode.mood:
        return 'Mood';
      case ProfileStatMode.wellness:
        return 'Wellness';
      case ProfileStatMode.rename:
        return 'Rename';
      case ProfileStatMode.nutrition:
        return 'Nutrition';
    }
  }
}

enum ProfileStatMode { rename, mood, nutrition, wellness }
