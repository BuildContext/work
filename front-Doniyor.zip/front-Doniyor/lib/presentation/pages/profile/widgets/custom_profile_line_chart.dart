import 'dart:math';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/core/models/chart_models/profile_line_chart_data.dart';
import 'package:test_project/presentation/custom_widgets/ayulife_chart_legend_item.dart';
import 'package:test_project/presentation/pages/profile/dosha/widgets/chart_sorting_dome_button.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:touchable/touchable.dart';

class CustomProfileTimeLineChart extends StatefulWidget {
  final List<CustomProfileChartDataSeries> series;
  final ValueChanged<CustomProfileChartDataItem> onDataItemSelected;

  const CustomProfileTimeLineChart({
    Key? key,
    required this.series,
    required this.onDataItemSelected,
  }) : super(key: key);

  @override
  State<CustomProfileTimeLineChart> createState() => _CustomProfileTimeLineChartState();
}

class _CustomProfileTimeLineChartState extends State<CustomProfileTimeLineChart> {
  late CustomProfileChartDataSeries selectedSeries = widget.series.first;
  CustomProfileChartDataItem? selectedItem;
  String selectedMode = '1Y';

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: 176,
          width: MediaQuery.of(context).size.width,
          child: Row(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  AppSpacing.verticalSpace12,
                  for (int i = 10; i >= 0; i--)
                    Text(
                      '${i * 10} %',
                      style: TypographyNeueHaasUnicaW1G.caption4.copyWith(
                        color: (i * 10) < (selectedItem?.value ?? 0) && (selectedItem?.value ?? 0) < (i + 1)
                            ? AppColors.dark
                            : AppColors.greyLight,
                      ),
                    ),
                ],
              ),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    LayoutBuilder(
                      builder: (context, size) {
                        return Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            for (int i = 1; i <= 12; i++)
                              SizedBox(
                                width: size.maxWidth / 12,
                                child: Text(
                                  '${DateFormat.MMM(context.locale.languageCode).format(DateFormat('M').parse(i.toString()))}'
                                      .toUpperCase(),
                                  style: TypographyNeueHaasUnicaW1G.caption4.copyWith(
                                    color: (i * 10) < (selectedItem?.value ?? 0) && (selectedItem?.value ?? 0) < (i + 1)
                                        ? AppColors.dark
                                        : AppColors.greyLight,
                                  ),
                                ),
                              ),
                          ],
                        );
                      },
                    ),
                    AppSpacing.verticalSpace14,
                    Expanded(
                      child: CustomPaint(
                        painter: CustomLineChartPainter(
                          context: context,
                          items: widget.series,
                          selectedIndex: Random().nextInt(widget.series.length - 1),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        AppSpacing.verticalSpace14,
        Padding(
          padding: AppInsets.horizontalInsets28,
          child: Text(
            getYearStamp(),
            textAlign: TextAlign.left,
            style: TypographyNeueHaasUnicaW1G.caption4.copyWith(color: AppColors.greyLight),
          ),
        ),
        AppSpacing.verticalSpace24,
        AppSpacing.verticalSpace10,
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ChartSortingModeButton(
              modeName: '1D',
              onTap: () => setState(() => selectedMode = '1D'),
              isSelected: '1D' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: '1Y',
              onTap: () => setState(() => selectedMode = '1Y'),
              isSelected: '1Y' == selectedMode,
            ),
            AppSpacing.horizontalSpace16,
            ChartSortingModeButton(
              modeName: 'All',
              onTap: () => setState(() => selectedMode = 'All'),
              isSelected: 'All' == selectedMode,
            ),
          ],
        ),
        AppSpacing.verticalSpace16,
        for (final series in widget.series)
          Center(
            child: AyulifeChartLegendItem(
              isSelected: selectedSeries.title == series.title,
              title: series.title,
              dataText: '',
              color: series.highlightColor,
            ),
          ),
      ],
    );
  }

  String getYearStamp() {
    List<int> years = List.empty(growable: true);
    for (final series in widget.series)
      for (final seriesItem in series.items) if (!years.contains(seriesItem.date.year)) years.add(seriesItem.date.year);
    if (years.length == 1) {
      return years.first.toString();
    } else {
      final minYear =
          years.fold<int>(DateTime.now().year, (previousValue, element) => previousValue > element ? element : previousValue);
      final maxYEar =
          years.fold<int>(DateTime.now().year, (previousValue, element) => previousValue < element ? element : previousValue);
      return '$minYear - $maxYEar';
    }
  }
}

class CustomLineChartPainter extends CustomPainter {
  final List<CustomProfileChartDataSeries> items;
  final int selectedIndex;
  final BuildContext context;

  CustomLineChartPainter({
    required this.items,
    required this.selectedIndex,
    required this.context,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final touchyCanvas = TouchyCanvas(context, canvas);
    final sizePerItem = size.width / 12;

    for (final series in items) {
      final path = Path();
      path.moveTo(sizePerItem / 4, size.height);
      for (int itemsIndex = 0; itemsIndex < series.items.length - 1; itemsIndex++) {
        final item = series.items.elementAt(itemsIndex);
        final nextItem = series.items.elementAt(itemsIndex + 1);
        final p1 = Offset((sizePerItem * itemsIndex) + (sizePerItem / 4), size.height / 100 * item.value.toDouble());
        final p2 = Offset((sizePerItem * (itemsIndex + 1)) + (sizePerItem / 4), size.height / 100 * nextItem.value.toDouble());
        touchyCanvas.drawLine(
          p1,
          p2,
          Paint()
            ..color = series.highlightColor
            ..strokeWidth = 2.5,
          onTapDown: (details) {},
        );
      }
      if (selectedIndex == items.indexOf(series))
        for (int itemsIndex = 0; itemsIndex < series.items.length; itemsIndex++)
          path.lineTo(
            (sizePerItem * itemsIndex) + (sizePerItem / 4),
            size.height / 100 * series.items.elementAt(itemsIndex).value.toDouble(),
          );
      path.lineTo((sizePerItem * 11) + (sizePerItem / 4), size.height);
      path.close();
      touchyCanvas.drawPath(
        path,
        Paint()..color = series.highlightColor.withOpacity(0.25),
      );

      // touchyCanvas.drawPath(
      //   path,
      //   paint,
      //   onTapDown: (details) {},
      // );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
