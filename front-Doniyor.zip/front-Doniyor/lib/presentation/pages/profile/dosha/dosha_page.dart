import 'dart:math';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/chart_models/dosha_balance_chart_data_model.dart';
import 'package:test_project/core/models/pain_point_model.dart';
import 'package:test_project/presentation/custom_widgets/content_section.dart';
import 'package:test_project/presentation/custom_widgets/custom_arc_chart/custom_arc_chart.dart';
import 'package:test_project/presentation/custom_widgets/custom_arc_chart/data_models/custom_arc_chart_data_model.dart';
import 'package:test_project/presentation/custom_widgets/dosha_card.dart';
import 'package:test_project/presentation/custom_widgets/instruction_tile.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/custom_widgets/recommended_reading_tile.dart';
import 'package:test_project/presentation/custom_widgets/tag_tile.dart';
import 'package:test_project/presentation/custom_widgets/vertical_small_content_card.dart';
import 'package:test_project/presentation/pages/profile/dosha/bloc/dosha_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/dosha/bloc/dosha_page_state.dart';
import 'package:test_project/presentation/pages/profile/dosha/widgets/dosha_pie_chart.dart';
import 'package:test_project/presentation/pages/profile/dosha/widgets/pain_level_card.dart';
import 'package:test_project/presentation/pages/profile/dosha/widgets/pain_point_tile.dart';
import 'package:test_project/presentation/pages/profile/settings/settings_sheet.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

class DoshaPage extends StatelessWidget {
  const DoshaPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<DoshaPageCubit>();
    return Scaffold(
      appBar: AppBar(
        title: Text('dosha'.tr(), style: TypographyTwCenW01Medium.title2),
        actions: [
          TextButton(
            onPressed: () => AppInteractionsHelper.showBottomSheet(
              context: context,
              child: SettingsSheet(),
              color: Colors.white,
              barrierColor: AppColors.oliveDark,
            ),
            child: Text('settings'.tr(), style: TypographyTwCenW01Medium.subtitle1),
          ),
        ],
      ),
      body: BlocConsumer<DoshaPageCubit, DoshaPageState>(
        bloc: cubit,
        listener: (context, state) {},
        builder: (context, state) {
          if (state is DoshaPageLoading) return Loader();
          if (state is DoshaPageSuccess)
            return ListView(
              padding: AppInsets.horizontalInsets28.copyWith(top: 14),
              children: [
                Text(
                  'my_constitution'.tr(),
                  style: TypographyTwCenW01Medium.title3,
                ),
                AppSpacing.verticalSpace30,
                Text(
                  'Vata Pitta',
                  style: TypographyTwCenW01Medium.title1,
                ),
                AppSpacing.verticalSpace16,
                Text(
                  'But you can turn off the exercises that you are not interested in!',
                  style: TypographyNeueHaasUnicaW1G.basic2,
                ),
                AppSpacing.verticalSpace30,
                Text(
                  'dosha'.tr().toUpperCase(),
                  style: TypographyTwCenW01Medium.subtitle2,
                ),
                AppSpacing.verticalSpace24,
                Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ProfileStatCard(
                            height: 210,
                            header: '${'my'.tr()} ${'dosha'.tr()}',
                            icon: SvgPicture.asset('assets/svgs/vata.svg'),
                            footer: Text(
                              '${state.dosha.vataPercentage} % Vata',
                              style: TypographyNeueHaasUnicaW1G.basic2,
                            ),
                          ),
                          AppSpacing.verticalSpace16,
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Expanded(
                                child: ProfileStatCard(
                                  header: 'element'.tr(),
                                  icon: SvgPicture.asset('assets/svgs/ether_full.svg'),
                                  footer: Text(
                                    'Ether',
                                    style: TypographyNeueHaasUnicaW1G.menu3,
                                  ),
                                  height: 97,
                                ),
                              ),
                              AppSpacing.horizontalSpace16,
                              Expanded(
                                child: ProfileStatCard(
                                  header: 'element'.tr(),
                                  icon: SvgPicture.asset('assets/svgs/wind_full.svg'),
                                  footer: Text(
                                    'Wind',
                                    style: TypographyNeueHaasUnicaW1G.menu3,
                                  ),
                                  height: 97,
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                    AppSpacing.horizontalSpace16,
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ProfileStatCard(
                            height: 210,
                            header: '${'my'.tr()} ${'dosha'.tr()}',
                            icon: SvgPicture.asset('assets/svgs/pitta.svg'),
                            footer: Text(
                              '${state.dosha.pittaPercentage}% Pitta',
                              style: TypographyNeueHaasUnicaW1G.basic2,
                            ),
                          ),
                          AppSpacing.verticalSpace16,
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Expanded(
                                child: ProfileStatCard(
                                  header: 'element'.tr(),
                                  icon: SvgPicture.asset('assets/svgs/fire_full.svg'),
                                  footer: Text(
                                    'Fire',
                                    style: TypographyNeueHaasUnicaW1G.menu3,
                                  ),
                                  height: 97,
                                ),
                              ),
                              AppSpacing.horizontalSpace16,
                              Expanded(
                                child: ProfileStatCard(
                                  header: 'element'.tr(),
                                  icon: SvgPicture.asset('assets/svgs/water_full.svg'),
                                  footer: Text(
                                    'Water',
                                    style: TypographyNeueHaasUnicaW1G.menu3,
                                  ),
                                  height: 97,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                AppSpacing.verticalSpace24,
                Text(
                  'DOSHA BALANCE',
                  style: TypographyTwCenW01Medium.subtitle2,
                ),
                AppSpacing.verticalSpace24,
                CustomArcChart(
                  data: List<CustomArcChartData>.generate(
                    3,
                    (index) => CustomArcChartData(
                      title: 'Vata',
                      color: [
                        AppColors.lavender,
                        AppColors.orangeLight,
                        AppColors.ice,
                      ].elementAt(index),
                      percentage: 100 / 3,
                    ),
                  ),
                ),
                AppSpacing.verticalSpace20,
                Text(
                  'quiz'.tr(),
                  style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
                  textAlign: TextAlign.center,
                ),
                AppSpacing.verticalSpace20,
                AppSpacing.verticalSpace16,
                DoshaPieChart<DoshaBalanceData>(
                  chartHeading: 'My Physical DOSHA'.toUpperCase(),
                  data: [
                    DoshaBalanceData(title: 'Vata', percentage: 25, color: AppColors.lavender),
                    DoshaBalanceData(title: 'Pitta', percentage: 50, color: AppColors.orangeLight),
                    DoshaBalanceData(title: 'Kapha', percentage: 25, color: AppColors.ice),
                  ],
                  chartTitle: 'Pitta\n',
                  chartSubtitle: 'Physical',
                ),
                AppSpacing.verticalSpace30,
                DoshaPieChart<DoshaBalanceData>(
                  chartHeading: 'MY Physiological DOSHA'.toUpperCase(),
                  data: [
                    DoshaBalanceData(title: 'Vata', percentage: 25, color: AppColors.lavender),
                    DoshaBalanceData(title: 'Pitta', percentage: 50, color: AppColors.orangeLight),
                    DoshaBalanceData(title: 'Kapha', percentage: 25, color: AppColors.ice),
                  ],
                  chartTitle: 'Pitta\n',
                  chartSubtitle: 'Physical',
                ),
                AppSpacing.verticalSpace30,
                DoshaPieChart<DoshaBalanceData>(
                  chartHeading: 'MY Psychological DOSHA'.toUpperCase(),
                  data: [
                    DoshaBalanceData(title: 'Vata', percentage: 25, color: AppColors.lavender),
                    DoshaBalanceData(title: 'Pitta', percentage: 50, color: AppColors.orangeLight),
                    DoshaBalanceData(title: 'Kapha', percentage: 25, color: AppColors.ice),
                  ],
                  chartTitle: 'Pitta\n',
                  chartSubtitle: 'Physical',
                ),
                AppSpacing.verticalSpace20,
                Text(
                  'quiz'.tr(),
                  style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
                  textAlign: TextAlign.center,
                ),
                AppSpacing.verticalSpace20,
                Divider(),
                ContentSection(
                  displayDivider: false,
                  displayTopSpacing: false,
                  titleStyle: TypographyTwCenW01Medium.title3,
                  title: state.readContent.categoryName,
                  onMore: () {},
                  children: state.readContent.items
                      .map(
                        (post) => VerticalSmallContentCard(
                          placeholderPath: 'assets/pngs/recipe_small_placeholder.png',
                          post: post,
                          onLikePressed: () {},
                          onTap: () {},
                        ),
                      )
                      .toList(),
                ),
                AppSpacing.verticalSpace20,
                AppSpacing.verticalSpace20,
                Text(
                  'The offer to pass a full quiz to determine your constitution and Vikrity.',
                  style: TypographyTwCenW01Medium.title2,
                ),
                AppSpacing.verticalSpace16,
                Text(
                  'The offer to pass a full quiz to determine your constitution and Vikrity.',
                  style: TypographyNeueHaasUnicaW1G.basic1,
                ),
                AppSpacing.verticalSpace24,
                AppSpacing.verticalSpace8,
                Text('INSTRUCTIONS', style: TypographyTwCenW01Medium.subtitle2),
                AppSpacing.verticalSpace24,
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: state.instructions
                      .map<Widget>(
                        (instruction) => InstructionTile(
                          instructions: instruction,
                          isEnabled: state.instructions.first == instruction,
                        ),
                      )
                      .toList(),
                ),
                AppSpacing.verticalSpace20,
                AppSpacing.verticalSpace20,
                Text('RECOMENDATIONS', style: TypographyTwCenW01Medium.subtitle2),
                AppSpacing.verticalSpace20,
                Text('Qualities', style: TypographyNeueHaasUnicaW1G.basic1),
                AppSpacing.verticalSpace20,
                Text('Large intestine, chest, throat, head, pancreas', style: TypographyNeueHaasUnicaW1G.basic2),
                AppSpacing.verticalSpace20,
                Text('Qualities', style: TypographyNeueHaasUnicaW1G.basic1),
                AppSpacing.verticalSpace20,
                Text('Dryness, lightness, humidity, heaviness', style: TypographyNeueHaasUnicaW1G.basic2),
                AppSpacing.verticalSpace20,
                Text('Diet', style: TypographyNeueHaasUnicaW1G.basic1),
                AppSpacing.verticalSpace20,
                Text(
                  'Eat warm, sweet, sour or salty food three times a day. Drink more water, fruit juices, soothing teas, consume dairy products, seasonings. Reduce the amount of sweet food. Try to eat most of the daily allowance between 10 and 13 hours. It is not recommended to drink a lot. It is not necessary to have lunch or dinner alone.',
                  style: TypographyNeueHaasUnicaW1G.basic2,
                ),
                AppSpacing.verticalSpace20,
                Text('Source of power', style: TypographyNeueHaasUnicaW1G.basic1),
                AppSpacing.verticalSpace20,
                Text(
                  'There is no sleep at night, talking loudly, hypothermia. And also when eating bitter, salty and dry food. The season is winter and summer. The time is evening.',
                  style: TypographyNeueHaasUnicaW1G.basic2,
                ),
                AppSpacing.verticalSpace20,
                Text('Side effect', style: TypographyNeueHaasUnicaW1G.basic1),
                AppSpacing.verticalSpace20,
                Text(
                  'Increased pigmentation, chills, insomnia, indigestion, constipation, rapid fatigue.',
                  style: TypographyNeueHaasUnicaW1G.basic3,
                ),
                AppSpacing.verticalSpace20,
                Text('Behaviour', style: TypographyNeueHaasUnicaW1G.basic1),
                AppSpacing.verticalSpace20,
                Text(
                  'Impatience, leadership qualities, self-development, tendency to self-criticism, vindictiveness, irregular diet, intermittent sleep, constipation, frequent mood swings, fast gait',
                  style: TypographyNeueHaasUnicaW1G.basic3,
                ),
                AppSpacing.verticalSpace20,
                AppSpacing.verticalSpace16,
                Text('WELLNESS', style: TypographyTwCenW01Medium.subtitle2),
                AppSpacing.verticalSpace24,
                SizedBox(
                  height: 97,
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(
                        child: MeasurementCard(
                          value: 8.2,
                          headerText: 'PAIN',
                          footerText: 'Level',
                        ),
                      ),
                      AppSpacing.horizontalSpace16,
                      Expanded(
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Expanded(
                              child: ProfileStatCard(
                                icon: SvgPicture.asset('assets/svgs/pie_chart_icon.svg'),
                                footer: Text(
                                  '50%',
                                  style: TypographyNeueHaasUnicaW1G.menu3.copyWith(color: AppColors.dark.withOpacity(0.5)),
                                ),
                                header: 'ENERGY',
                              ),
                            ),
                            AppSpacing.horizontalSpace16,
                            Expanded(
                              child: ProfileStatCard(
                                icon: SvgPicture.asset('assets/svgs/pie_chart_icon.svg'),
                                footer: Text(
                                  '50%',
                                  style: TypographyNeueHaasUnicaW1G.menu3.copyWith(color: AppColors.dark.withOpacity(0.5)),
                                ),
                                header: 'ENERGY',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                AppSpacing.verticalSpace20,
                SizedBox(
                  height: 305,
                  width: MediaQuery.of(context).size.width,
                  child: Stack(
                    children: [
                      Center(child: Image.asset('assets/pngs/full_height_man.png', height: 305, width: 105)),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Expanded(
                            child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: List.generate(
                                  2,
                                  (index) => PainPointModel(
                                    title: 'Migrane',
                                    frequency: Random().nextInt(100),
                                    levelOfDiscomfort: Random().nextInt(10),
                                  ),
                                ).map((e) => SimplePainPointTile(point: e)).toList()),
                          ),
                          AppSpacing.horizontalSpace30,
                          AppSpacing.horizontalSpace30,
                          AppSpacing.horizontalSpace24,
                          AppSpacing.horizontalSpace24,
                          Expanded(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: List.generate(
                                2,
                                (index) => PainPointModel(
                                  title: 'Migrane',
                                  frequency: Random().nextInt(100),
                                  levelOfDiscomfort: Random().nextInt(10),
                                ),
                              ).map((e) => SimplePainPointTile(point: e)).toList(),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                AppSpacing.verticalSpace20,
                Text('RECOMENDATIONS', style: TypographyTwCenW01Medium.subtitle2),
                AppSpacing.verticalSpace24,
                for (final reading in state.readings) RecommendedReadingTile(reading: reading, onTap: () {}),
                AppSpacing.verticalSpace16,
                Text('GOOD FOR', style: TypographyTwCenW01Medium.subtitle2),
                AppSpacing.verticalSpace24,
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: state.goodFor.map<Widget>((e) => TagTile(tag: e, onTap: () {})).toList(),
                ),
                AppSpacing.verticalSpace20,
                AppSpacing.verticalSpace20,
                Text('NOT GOOD FOR', style: TypographyTwCenW01Medium.subtitle2),
                AppSpacing.verticalSpace24,
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: state.badFor.map<Widget>((e) => TagTile(tag: e, onTap: () {})).toList(),
                ),
              ],
            );
          return Container();
        },
      ),
    );
  }
}
