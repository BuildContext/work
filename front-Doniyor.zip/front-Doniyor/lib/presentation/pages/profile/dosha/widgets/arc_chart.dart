import 'dart:math';

import 'package:charts_flutter/flutter.dart';
import 'package:flutter/material.dart';
import 'package:test_project/core/models/chart_models/ayulife_chart_data_model.dart';
import 'package:test_project/core/models/chart_models/dosha_balance_chart_data_model.dart';

class ArcChart<T extends AyulifeChartDataModel> extends StatelessWidget {
  final List<T> data;

  const ArcChart({
    Key? key,
    required this.data,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return PieChart<String>(
      <Series<T, String>>[
        Series<T, String>(
          id: 'id',
          data: data,
          colorFn: (seg, _) => seg.color,
          domainFn: (seg, _) => seg.title,
          measureFn: (seg, _) => seg.value,
        ),
      ],
      defaultRenderer: ArcRendererConfig<String>(
        arcWidth: 16,
        startAngle: pi,
        arcLength: pi,
        strokeWidthPx: 1,
      ),
      behaviors: [
        DatumLegend(
          position: BehaviorPosition.bottom,
        ),
      ],
      selectionModels: [
        SelectionModelConfig<String>(
          type: SelectionModelType.info,
          changedListener: (model) {
            final selectedDatum = model.selectedDatum.first.datum;
            if (selectedDatum is DoshaBalanceData) print(selectedDatum.title);
          },
        ),
      ],
      layoutConfig: LayoutConfig(
        leftMarginSpec: MarginSpec.fixedPixel(0),
        bottomMarginSpec: MarginSpec.fixedPixel(0),
        topMarginSpec: MarginSpec.fixedPixel(0),
        rightMarginSpec: MarginSpec.fixedPixel(0),
      ),
      animate: true,
      defaultInteractions: true,
    );
  }
}
