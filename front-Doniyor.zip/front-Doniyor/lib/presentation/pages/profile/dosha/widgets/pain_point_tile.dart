import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/core/models/pain_point_model.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class PainPointTile extends StatelessWidget {
  final PainPointModel point;
  final bool isSelected;
  final VoidCallback onTap;

  const PainPointTile({
    Key? key,
    required this.point,
    required this.onTap,
    required this.isSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      color: isSelected ? AppColors.oliveLight : Colors.white,
      child: InkWell(
        onTap: onTap,
        child: Ink(
          padding: EdgeInsets.symmetric(vertical: 14),
          height: 120,
          decoration: BoxDecoration(
            color: isSelected ? AppColors.oliveLight : Colors.white,
            border: Border.symmetric(
              horizontal: BorderSide(color: AppColors.greyLight, width: 0.5),
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(point.title, style: TypographyNeueHaasUnicaW1G.basic2.copyWith(fontWeight: FontWeight.bold)),
                  Icon(Icons.more_vert),
                ],
              ),
              AppSpacing.verticalSpace10,
              AppSpacing.verticalSpace8,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    'Level of discomfort',
                    style: TypographyNeueHaasUnicaW1G.basic3,
                  ),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      for (int i = 0; i < point.levelOfDiscomfort; i++)
                        Container(
                          margin: EdgeInsets.only(right: 3),
                          height: 8,
                          width: 8,
                          decoration: BoxDecoration(
                            color: AppColors.oliveDark,
                            shape: BoxShape.circle,
                          ),
                        )
                    ],
                  ),
                  Text(
                    '${point.levelOfDiscomfort}',
                    style: TypographyNeueHaasUnicaW1G.basic3,
                  ),
                ],
              ),
              AppSpacing.verticalSpace12,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    'Number of cases',
                    style: TypographyNeueHaasUnicaW1G.basic3,
                  ),
                  Text(
                    point.frequency.toString(),
                    style: TypographyNeueHaasUnicaW1G.basic3,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SimplePainPointTile extends StatelessWidget {
  final PainPointModel point;

  const SimplePainPointTile({Key? key, required this.point}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: AppInsets.verticalInsets8,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(point.title, style: TypographyNeueHaasUnicaW1G.basic2.copyWith(fontWeight: FontWeight.bold)),
          AppSpacing.verticalSpace8,
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (int i = 0; i < point.levelOfDiscomfort; i++)
                Container(
                  margin: EdgeInsets.only(right: 3),
                  height: 8,
                  width: 8,
                  decoration: BoxDecoration(
                    color: AppColors.oliveDark,
                    shape: BoxShape.circle,
                  ),
                )
            ],
          ),
          AppSpacing.verticalSpace8,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            mainAxisSize: MainAxisSize.max,
            children: [
              Text(
                '${point.levelOfDiscomfort} ${'level'.tr()}',
                style: TypographyNeueHaasUnicaW1G.basic3,
              ),
              Text(
                '${point.frequency} ${'cases'.tr()}',
                style: TypographyNeueHaasUnicaW1G.basic3,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
