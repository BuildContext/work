import 'dart:math';

import 'package:charts_flutter/flutter.dart';
import 'package:flutter/material.dart';
import 'package:test_project/core/models/chart_models/ayulife_chart_data_model.dart';
import 'package:test_project/presentation/custom_widgets/ayulife_chart_legend_item.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class DoshaPieChart<T extends AyulifeChartDataModel> extends StatelessWidget {
  final List<T> data;
  final String chartTitle;
  final String chartSubtitle;
  final String chartHeading;

  const DoshaPieChart({
    Key? key,
    required this.data,
    required this.chartTitle,
    required this.chartSubtitle,
    required this.chartHeading,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          chartHeading,
          style: TypographyTwCenW01Medium.subtitle2,
        ),
        AppSpacing.verticalSpace24,
        SizedBox(
          height: 150,
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: data
                      .map((e) => AyulifeChartLegendItem(
                            isSelected: e.title == 'Pitta',
                            color: e.dartColor,
                            title: e.title,
                            dataText: '${e.value} %\n',
                          ))
                      .toList(),
                ),
              ),
              SizedBox(
                height: 150,
                width: 150,
                child: Stack(
                  children: [
                    SizedBox(
                      width: 150,
                      height: 150,
                      child: PieChart<String>(
                        <Series<T, String>>[
                          Series<T, String>(
                            id: 'main',
                            data: data,
                            colorFn: (seg, _) => seg.color,
                            domainFn: (seg, _) => seg.title,
                            measureFn: (seg, _) => seg.value,
                          ),
                        ],
                        defaultRenderer: ArcRendererConfig<String>(
                          arcWidth: 8,
                          startAngle: pi,
                          arcLength: pi + pi,
                          strokeWidthPx: 1,
                        ),
                        behaviors: [],
                        selectionModels: [
                          SelectionModelConfig<String>(
                            type: SelectionModelType.info,
                            changedListener: (model) {
                              final selectedDatum = model.selectedDatum.first.datum;
                            },
                          ),
                        ],
                        animate: true,
                        defaultInteractions: true,
                      ),
                    ),
                    Center(
                      child: Padding(
                        padding: AppInsets.horizontalInsets36,
                        child: RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(text: chartTitle, style: TypographyNeueHaasUnicaW1G.basic2),
                              TextSpan(
                                text: chartSubtitle,
                                style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.dark.withOpacity(0.5)),
                              ),
                            ],
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
