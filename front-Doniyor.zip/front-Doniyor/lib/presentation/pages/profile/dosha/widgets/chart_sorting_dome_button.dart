import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class ChartSortingModeButton extends StatelessWidget {
  final String modeName;
  final VoidCallback onTap;
  final bool isSelected;

  const ChartSortingModeButton({
    Key? key,
    required this.modeName,
    required this.onTap,
    required this.isSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: AppBorderRadius.borderRadiusAll8,
      color: isSelected ? AppColors.oliveLight : Colors.white,
      child: InkWell(
        onTap: onTap,
        borderRadius: AppBorderRadius.borderRadiusAll8,
        child: Ink(
          padding: AppInsets.insetsAll16,
          decoration: BoxDecoration(
            color: isSelected ? AppColors.oliveLight : Colors.white,
            borderRadius: AppBorderRadius.borderRadiusAll8,
            border: Border.all(
              color: AppColors.oliveDark,
            ),
          ),
          child: Text(
            modeName,
            style: TypographyNeueHaasUnicaW1G.menu3,
          ),
        ),
      ),
    );
  }
}
