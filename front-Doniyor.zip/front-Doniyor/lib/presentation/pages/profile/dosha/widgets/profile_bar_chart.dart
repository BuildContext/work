import 'package:charts_flutter/flutter.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/core/models/chart_models/ayulife_chart_data_model.dart';
import 'package:test_project/presentation/pages/profile/dosha/widgets/chart_sorting_dome_button.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class ProfileBarChart<T extends AyulifeChartDataModel> extends StatefulWidget {
  final String title;
  final List<Series<T, String>> data;
  final bool abstractMeasurement;
  final List<Widget> legendItems;

  const ProfileBarChart({
    Key? key,
    required this.title,
    required this.legendItems,
    required this.abstractMeasurement,
    required this.data,
  }) : super(key: key);

  @override
  State<ProfileBarChart> createState() => _ProfileBarChartState();
}

class _ProfileBarChartState extends State<ProfileBarChart> {
  String _selectedSortMode = '1Y';
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          widget.title.toUpperCase(),
          style: TypographyTwCenW01Medium.subtitle2,
        ),
        AppSpacing.verticalSpace24,
        SizedBox(
          height: 200,
          width: MediaQuery.of(context).size.width,
          child: BarChart(
            widget.data,
            barGroupingType: BarGroupingType.stacked,
            behaviors: [
              // PercentInjector<String>(totalType: PercentInjectorTotalType.domain),
              // PercentInjector<String>(
              //   totalType: PercentInjectorTotalType.domainBySeriesCategory,
              // ),
            ],
            primaryMeasureAxis: NumericAxisSpec(
              renderSpec: SmallTickRendererSpec(
                labelStyle: TextStyleSpec(fontSize: 6),
                lineStyle: LineStyleSpec(
                  color: MaterialPalette.transparent,
                ),
              ),
              tickProviderSpec: BasicNumericTickProviderSpec(
                desiredMinTickCount: 8,
                desiredMaxTickCount: 8,
                desiredTickCount: 8,
              ),
              tickFormatterSpec: BasicNumericTickFormatterSpec((value) {
                if (widget.abstractMeasurement) {
                  if (value is num) {
                    print(value);
                    if (value >= 0 && value < 1) {
                      return 'DEP';
                    } else if (value >= 1 && value < 2) {
                      return 'SAD';
                    } else if (value >= 2 && value < 3) {
                      return 'APR';
                    } else if (value >= 3 && value < 4) {
                      return 'AGR';
                    } else if (value >= 4 && value < 5) {
                      return 'EXC';
                    } else if (value >= 5 && value < 6) {
                      return 'HAP';
                    } else if (value >= 6 && value < 7) {
                      return 'CAL';
                    } else {
                      return 'CAL';
                    }
                  }
                } else {
                  return '$value K';
                }
                return '';
              }),
            ),
          ),
        ),
        AppSpacing.verticalSpace16,
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            ChartSortingModeButton(
              modeName: '1D',
              onTap: () => setState(() => _selectedSortMode = '1D'),
              isSelected: _selectedSortMode == '1D',
            ),
            ChartSortingModeButton(
              modeName: '1W',
              onTap: () => setState(() => _selectedSortMode = '1W'),
              isSelected: _selectedSortMode == '1W',
            ),
            ChartSortingModeButton(
              modeName: '1M',
              onTap: () => setState(() => _selectedSortMode = '1M'),
              isSelected: _selectedSortMode == '1M',
            ),
            ChartSortingModeButton(
              modeName: '1Y',
              onTap: () => setState(() => _selectedSortMode = '1Y'),
              isSelected: _selectedSortMode == '1Y',
            ),
            ChartSortingModeButton(
              modeName: 'All',
              onTap: () => setState(() => _selectedSortMode = 'All'),
              isSelected: _selectedSortMode == 'All',
            ),
          ],
        ),
        AppSpacing.verticalSpace16,
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: widget.legendItems,
        ),
        AppSpacing.verticalSpace24,
        Text(
          'quiz'.tr(),
          style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
