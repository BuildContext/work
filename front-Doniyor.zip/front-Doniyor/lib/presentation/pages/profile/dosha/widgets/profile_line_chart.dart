import 'package:charts_flutter/flutter.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/core/models/chart_models/ayulife_chart_data_model.dart';
import 'package:test_project/presentation/custom_widgets/ayulife_chart_legend_item.dart';
import 'package:test_project/presentation/pages/profile/dosha/widgets/chart_sorting_dome_button.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class ProfileTimeLineChart<T extends AyulifeChartDataModel> extends StatefulWidget {
  final String title;
  final List<Series<T, DateTime>> data;

  const ProfileTimeLineChart({
    Key? key,
    required this.data,
    required this.title,
  }) : super(key: key);

  @override
  State<ProfileTimeLineChart<T>> createState() => _ProfileTimeLineChartState<T>();
}

class _ProfileTimeLineChartState<T extends AyulifeChartDataModel> extends State<ProfileTimeLineChart<T>> {
  List<int> _percentageMeasurementLabels = List.generate(11, (index) => 100 - (index * 10));
  String _selectedSortMode = '1Y';
  @override
  void initState() {
    super.initState();
    print(_percentageMeasurementLabels);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          widget.title.toUpperCase(),
          style: TypographyTwCenW01Medium.subtitle2,
        ),
        AppSpacing.verticalSpace24,
        SizedBox(
          height: 200,
          width: MediaQuery.of(context).size.width,
          child: TimeSeriesChart(
            widget.data,
            domainAxis: DateTimeAxisSpec(
              renderSpec: SmallTickRendererSpec(
                labelStyle: TextStyleSpec(fontSize: 6),
                lineStyle: LineStyleSpec(color: MaterialPalette.transparent),
              ),
              showAxisLine: false,
              tickFormatterSpec: AutoDateTimeTickFormatterSpec(
                month: TimeFormatterSpec(format: 'MMM', transitionFormat: 'MMM'),
                year: TimeFormatterSpec(format: 'yyyy', transitionFormat: 'yyyy'),
              ),
            ),
            primaryMeasureAxis: NumericAxisSpec(
              renderSpec: SmallTickRendererSpec(
                labelStyle: TextStyleSpec(fontSize: 6),
                lineStyle: LineStyleSpec(
                  color: MaterialPalette.transparent,
                ),
              ),
              tickProviderSpec: BasicNumericTickProviderSpec(
                desiredMaxTickCount: 10,
                desiredMinTickCount: 6,
                desiredTickCount: 10,
              ),
              tickFormatterSpec: BasicNumericTickFormatterSpec((value) => '${value?.toInt()} %'),
            ),
            behaviors: [
              LinePointHighlighter(
                showHorizontalFollowLine: LinePointHighlighterFollowLineType.none,
                showVerticalFollowLine: LinePointHighlighterFollowLineType.nearest,
              ),
              SelectNearest(eventTrigger: SelectionTrigger.tapAndDrag),
            ],
          ),
        ),
        AppSpacing.verticalSpace16,
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            ChartSortingModeButton(
              modeName: '1D',
              onTap: () => setState(() => _selectedSortMode = '1D'),
              isSelected: _selectedSortMode == '1D',
            ),
            ChartSortingModeButton(
              modeName: '1W',
              onTap: () => setState(() => _selectedSortMode = '1W'),
              isSelected: _selectedSortMode == '1W',
            ),
            ChartSortingModeButton(
              modeName: '1M',
              onTap: () => setState(() => _selectedSortMode = '1M'),
              isSelected: _selectedSortMode == '1M',
            ),
            ChartSortingModeButton(
              modeName: '1Y',
              onTap: () => setState(() => _selectedSortMode = '1Y'),
              isSelected: _selectedSortMode == '1Y',
            ),
            ChartSortingModeButton(
              modeName: 'All',
              onTap: () => setState(() => _selectedSortMode = 'All'),
              isSelected: _selectedSortMode == 'All',
            ),
          ],
        ),
        AppSpacing.verticalSpace16,
        Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.max,
                children: [
                  AyulifeChartLegendItem(
                    isSelected: true,
                    dataText: 'My physics',
                    title: '',
                    color: AppColors.oliveDark,
                  ),
                ],
              ),
            ),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AyulifeChartLegendItem(
                    isSelected: true,
                    dataText: 'Vata',
                    title: '',
                    color: AppColors.lavender,
                  ),
                  AyulifeChartLegendItem(
                    isSelected: true,
                    dataText: 'Kapha',
                    title: '',
                    color: AppColors.ice,
                  ),
                  AyulifeChartLegendItem(
                    isSelected: true,
                    dataText: 'Pitta',
                    title: '',
                    color: AppColors.orangeLight,
                  ),
                ],
              ),
            ),
          ],
        ),
        AppSpacing.verticalSpace24,
        Text(
          'quiz'.tr(),
          style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
