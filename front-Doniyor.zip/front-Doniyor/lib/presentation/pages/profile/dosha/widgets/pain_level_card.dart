import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class MeasurementCard extends StatelessWidget {
  final double value;
  final String headerText, footerText;

  const MeasurementCard({
    Key? key,
    required this.value,
    required this.headerText,
    required this.footerText,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 97,
      padding: AppInsets.insetsAll8,
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.oliveDark, width: 0.5),
        borderRadius: AppBorderRadius.borderRadiusAll8,
        color: AppColors.oliveLight,
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          Center(child: SvgPicture.asset('assets/svgs/line_chart_icon.svg')),
          Text(headerText, style: TypographyTwCenW01Medium.subtitle2),
          Positioned(
            bottom: 0,
            right: 0,
            child: Text(footerText, style: TypographyNeueHaasUnicaW1G.menu3),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            child: Text(
              value.toStringAsFixed(1),
              style: TypographyTwCenW01Medium.header2,
            ),
          ),
        ],
      ),
    );
  }
}
