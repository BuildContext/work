import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/post.dart';
import 'package:test_project/core/models/user_dosha.dart';

class DoshaPageState {}

class DoshaPageInitial extends DoshaPageState {}

class DoshaPageLoading extends DoshaPageState {}

class DoshaPageSuccess extends DoshaPageState {
  final UserDosha dosha;
  final ContentCategory readContent;
  final List<PostInstruction> instructions;
  final List<RecommendedReading> readings;
  final List<ContentCategoryTag> goodFor, badFor;

  DoshaPageSuccess({
    required this.dosha,
    required this.readContent,
    required this.instructions,
    required this.readings,
    required this.goodFor,
    required this.badFor,
  });
}

class DoshaPageError extends DoshaPageState {
  final String error;

  DoshaPageError({required this.error});
}
