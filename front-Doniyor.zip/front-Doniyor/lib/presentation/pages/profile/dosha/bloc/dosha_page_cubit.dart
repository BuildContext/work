import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/category_models.dart';
import 'package:test_project/core/models/post.dart';
import 'package:test_project/core/models/user_dosha.dart';
import 'package:test_project/presentation/pages/profile/dosha/bloc/dosha_page_state.dart';

class DoshaPageCubit extends Cubit<DoshaPageState> {
  DoshaPageCubit() : super(DoshaPageInitial()) {
    loadData();
  }

  Future<void> loadData() async {
    emit(DoshaPageLoading());
    await Future.delayed(Duration(seconds: 2));
    emit(
      DoshaPageSuccess(
        dosha: UserDosha(vataPercentage: 50, pittaPercentage: 33),
        readContent: PostCategory(
          name: 'Else',
          items: List.generate(
            5,
            (index) => PostCategoryItem(
              categoryName: 'Popular',
              id: (index * 123).toString(),
              author: PostAuthor(
                avatar: '',
                name: 'Name Surname',
                position: 'Position',
                description: 'avsdbfsffsdfgdfbgdvs vsds vsd sd vsd gdfgdsfgsdfvgdsvgf vsd gvsdfvg svdfg vsdfgvsdfvg',
              ),
              instructions: [],
              isLiked: false,
              imageLink: 'Popular',
              title: 'Generated title ${++index} loooooooong',
              description: 'asvsdjkdnfvjkdfnbkjdnfbkjdnfbjkndkjfbdfbfdbdfbdf\ndsvklndsbjlnfjlbnsdklnsdlvkm',
              time: Duration(minutes: index * (10 % ++index)),
              goodFor: List.generate(
                index * 2,
                (index) => ContentCategoryTag(title: 'title $index', iconLink: index % 2 == 0 ? 'assets/svgs/leaf.svg' : null),
              ),
              icons: [
                ContentCategoryIcon(iconPath: 'ether', isLocal: true),
                ContentCategoryIcon(iconPath: 'morning', isLocal: true),
                ContentCategoryIcon(iconPath: 'winter', isLocal: true),
              ],
            ),
          ),
          subCategories: [],
        ),
        readings: List.generate(
          5,
          (index) => RecommendedReading(
            heading: 'Sscasdvfd',
            description:
                'asldsln aklmdamslk mdgk lsmgklsmkldasnjakgngjkasndjkg nasgjk nas jkgans jdgk nas jdgn asjgn skadng kjads ngaskd g sajdgn asjdg nasdk jgnsaj',
            icons: [
              ContentCategoryIcon(iconPath: 'ether', isLocal: true),
              ContentCategoryIcon(iconPath: 'morning', isLocal: true),
              ContentCategoryIcon(iconPath: 'winter', isLocal: true),
            ],
            isLiked: false,
            hexColor: '#F7E9CD',
          ),
        ),
        instructions: List.generate(
          5,
          (index) => PostInstruction(
            time: Duration(minutes: ++index * 2),
            icons: [
              ContentCategoryIcon(iconPath: 'ether', isLocal: true),
              ContentCategoryIcon(iconPath: 'morning', isLocal: true),
              ContentCategoryIcon(iconPath: 'winter', isLocal: true),
            ],
            title: 'njklnkjvsnds nkjknjlnkljnjkl',
            imageLink: 'asvbfdngfhmg',
          ),
        ),
        goodFor: [
          ContentCategoryTag(title: 'avsdfd', iconLink: 'assets/svgs/leaf.svg'),
          ContentCategoryTag(title: 'ascdvfbghg', iconLink: 'assets/svgs/leaf.svg'),
          ContentCategoryTag(title: 'avsdafvdfsvdfdfd', iconLink: 'assets/svgs/leaf.svg'),
          ContentCategoryTag(title: 'sfd', iconLink: 'assets/svgs/leaf.svg'),
          ContentCategoryTag(title: 'vsdfvfff', iconLink: 'assets/svgs/leaf.svg'),
          ContentCategoryTag(title: 'weret', iconLink: null),
          ContentCategoryTag(title: 'dfvgbb', iconLink: 'assets/svgs/leaf.svg'),
          ContentCategoryTag(title: 'adfsghas', iconLink: 'assets/svgs/leaf.svg'),
          ContentCategoryTag(title: 'dafvdghnik', iconLink: null),
          ContentCategoryTag(title: 'sdvvsdvf', iconLink: 'assets/svgs/leaf.svg'),
        ],
        badFor: [
          ContentCategoryTag(title: 'avsdfd', iconLink: 'assets/svgs/leaf.svg'),
          ContentCategoryTag(title: 'sfd', iconLink: 'assets/svgs/leaf.svg'),
          ContentCategoryTag(title: 'vsdfvfff', iconLink: 'assets/svgs/leaf.svg'),
          ContentCategoryTag(title: 'weret', iconLink: null),
          ContentCategoryTag(title: 'dfvgbb', iconLink: 'assets/svgs/leaf.svg'),
          ContentCategoryTag(title: 'dafvdghnik', iconLink: null),
          ContentCategoryTag(title: 'sdvvsdvf', iconLink: 'assets/svgs/leaf.svg'),
        ],
      ),
    );
  }
}
