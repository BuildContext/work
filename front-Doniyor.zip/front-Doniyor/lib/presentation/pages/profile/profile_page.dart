import 'dart:math';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/chart_models/custom_pie_chart_data.dart';
import 'package:test_project/core/models/chart_models/profile_line_chart_data.dart';
import 'package:test_project/core/models/pain_point_model.dart';
import 'package:test_project/core/models/quiz.dart';
import 'package:test_project/presentation/custom_widgets/custom_arc_chart/custom_arc_chart.dart';
import 'package:test_project/presentation/custom_widgets/custom_arc_chart/data_models/custom_arc_chart_data_model.dart';
import 'package:test_project/presentation/custom_widgets/custom_linear_progress_indicator.dart';
import 'package:test_project/presentation/custom_widgets/quiz_card.dart';
import 'package:test_project/presentation/pages/profile/dosha/bloc/dosha_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/dosha/dosha_page.dart';
import 'package:test_project/presentation/pages/profile/dosha/widgets/chart_sorting_dome_button.dart';
import 'package:test_project/presentation/pages/profile/dosha/widgets/pain_level_card.dart';
import 'package:test_project/presentation/pages/profile/dosha/widgets/pain_point_tile.dart';
import 'package:test_project/presentation/pages/profile/settings/settings_sheet.dart';
import 'package:test_project/presentation/pages/profile/widgets/coupled_pie_chart.dart';
import 'package:test_project/presentation/pages/profile/widgets/custom_pie_chart.dart';
import 'package:test_project/presentation/pages/profile/widgets/custom_profile_line_chart.dart';
import 'package:test_project/presentation/pages/profile/widgets/custom_stacked_chart_data.dart';
import 'package:test_project/presentation/pages/profile/widgets/pain_point_sheet.dart';
import 'package:test_project/presentation/pages/profile/widgets/profile_stats_row.dart';
import 'package:test_project/presentation/pages/quiz_pages/quiz_page_selector.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

import 'widgets/emtion_pie_chart.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile', style: TypographyCyrence.header2),
        actions: [
          TextButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => BlocProvider(
                  create: (context) => DoshaPageCubit(),
                  child: DoshaPage(),
                ),
              ),
            ),
            child: Text('dosha'.tr(), style: TypographyTwCenW01Medium.subtitle1),
          ),
          TextButton(
            onPressed: () {},
            child: Text('selected'.tr(), style: TypographyTwCenW01Medium.subtitle1),
          ),
          TextButton(
            onPressed: () => AppInteractionsHelper.showBottomSheet(
              context: context,
              child: SettingsSheet(),
              color: Colors.white,
              barrierColor: AppColors.oliveDark,
            ),
            child: Text('settings'.tr(), style: TypographyTwCenW01Medium.subtitle1),
          ),
        ],
      ),
      body: ListView(
        padding: AppInsets.horizontalInsets28,
        children: [
          AppSpacing.verticalSpace14,
          ProfileStatsModeRow(),
          AppSpacing.verticalSpace30,
          Text(
            'AYURTIME',
            style: TypographyTwCenW01Medium.subtitle2,
          ),
          AppSpacing.verticalSpace24,
          CustomProfileTimeLineChart(
            onDataItemSelected: (value) {},
            series: [
              CustomProfileChartDataSeries(
                title: 'Kapha',
                highlightColor: AppColors.ice,
                items: List.generate(
                  12,
                  (index) => CustomProfileChartDataItem(
                    color: AppColors.ice,
                    value: Random().nextInt(100),
                    date: DateTime.now().subtract(Duration(days: 30 * (index + 1))),
                  ),
                ),
              ),
              CustomProfileChartDataSeries(
                title: 'Pitta',
                highlightColor: AppColors.orangeLight,
                items: List.generate(
                  12,
                  (index) => CustomProfileChartDataItem(
                    color: AppColors.orangeLight,
                    value: Random().nextInt(100),
                    date: DateTime.now().subtract(Duration(days: 30 * (index + 1))),
                  ),
                ),
              ),
              CustomProfileChartDataSeries(
                highlightColor: AppColors.lavender,
                title: 'Vata',
                items: List.generate(
                  12,
                  (index) => CustomProfileChartDataItem(
                    color: AppColors.lavender,
                    value: Random().nextInt(100),
                    date: DateTime.now().subtract(Duration(days: 30 * (index + 1))),
                  ),
                ),
              ),
            ],
          ),
          AppSpacing.verticalSpace24,
          Text(
            'Guidline Dinamicheskiy',
            style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
            textAlign: TextAlign.center,
          ),
          AppSpacing.verticalSpace24,
          AppSpacing.verticalSpace12,
          Text(
            'GUNE CHART',
            style: TypographyTwCenW01Medium.subtitle2,
          ),
          AppSpacing.verticalSpace24,
          CustomStackedChart(
            series: [
              CustomProfileChartDataSeries(
                title: 'Thamasik',
                highlightColor: AppColors.ice,
                items: List.generate(
                  36,
                  (index) => CustomProfileChartDataItem(
                    color: AppColors.ice,
                    value: Random().nextInt(10),
                    date: DateTime.now().subtract(Duration(days: 30 * (index + 1))),
                  ),
                ),
              ),
              CustomProfileChartDataSeries(
                title: 'Swatwick',
                highlightColor: AppColors.orangeLight,
                items: List.generate(
                  36,
                  (index) => CustomProfileChartDataItem(
                    color: AppColors.orangeLight,
                    value: Random().nextInt(10),
                    date: DateTime.now().subtract(Duration(days: 30 * (index + 1))),
                  ),
                ),
              ),
              CustomProfileChartDataSeries(
                highlightColor: AppColors.lavender,
                title: 'Rajasik',
                items: List.generate(
                  36,
                  (index) => CustomProfileChartDataItem(
                    color: AppColors.lavender,
                    value: Random().nextInt(10),
                    date: DateTime.now().subtract(Duration(days: 30 * (index + 1))),
                  ),
                ),
              ),
            ],
            onDataItemSelected: (item) {},
          ),
          AppSpacing.verticalSpace20,
          Text(
            'quiz'.tr(),
            style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
            textAlign: TextAlign.center,
          ),
          AppSpacing.verticalSpace12,
          AppSpacing.verticalSpace24,
          Text('GUNE BALANCE'.toUpperCase(), style: TypographyTwCenW01Medium.subtitle2),
          CustomPieChart(
            series: [
              CustomPieChartDataItem(
                title: 'Thamasik',
                color: AppColors.ice,
                value: 10,
              ),
              CustomPieChartDataItem(
                title: 'Swatwick',
                color: AppColors.orangeLight,
                value: 35,
              ),
              CustomPieChartDataItem(
                title: 'Rajasik',
                color: AppColors.lavender,
                value: 55,
              ),
            ],
            onDataItemSelected: (item) {},
          ),
          AppSpacing.verticalSpace20,
          Text(
            'quiz'.tr(),
            style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
            textAlign: TextAlign.center,
          ),
          AppSpacing.verticalSpace24,
          AppSpacing.verticalSpace12,
          Text('CURRENT YOU', style: TypographyTwCenW01Medium.subtitle2),
          AppSpacing.verticalSpace16,
          CoupledPieChart(
            firstChartItems: [
              CustomPieChartDataItem(
                title: 'Passive',
                color: AppColors.lavender,
                value: 25,
              ),
              CustomPieChartDataItem(
                title: 'Positive',
                color: AppColors.lavender.withOpacity(0.25),
                value: 75,
              ),
            ],
            secondChartItems: [
              CustomPieChartDataItem(
                title: 'Negative',
                color: AppColors.orangeLight.withOpacity(0.25),
                value: 25,
              ),
              CustomPieChartDataItem(
                title: 'Positive',
                color: AppColors.orangeLight,
                value: 75,
              ),
            ],
          ),
          AppSpacing.verticalSpace24,
          Text(
            'quiz'.tr(),
            style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
            textAlign: TextAlign.center,
          ),
          AppSpacing.verticalSpace24,
          EmotionPieChart(
            series: [
              CustomPieChartDataItem(value: 35, color: AppColors.orangeLight, title: 'Happy'),
              CustomPieChartDataItem(value: 10, color: AppColors.orangeInvisible, title: 'Excited'),
              CustomPieChartDataItem(value: 3, color: AppColors.ice, title: 'Sad'),
              CustomPieChartDataItem(value: 14, color: AppColors.iceInvisible, title: 'Depressed'),
              CustomPieChartDataItem(value: 8, color: AppColors.lavender, title: 'Angry'),
              CustomPieChartDataItem(value: 17, color: AppColors.lavenderInvisible, title: 'Afraid'),
              CustomPieChartDataItem(value: 10, color: AppColors.greenLight, title: 'Calm'),
              CustomPieChartDataItem(value: 3, color: AppColors.greenLightInvisible, title: 'Content'),
            ],
          ),
          AppSpacing.verticalSpace20,
          Text(
            'quiz'.tr(),
            style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
            textAlign: TextAlign.center,
          ),
          AppSpacing.verticalSpace20,
          AppSpacing.verticalSpace16,
          Text(
            'NUTRITION CHART',
            style: TypographyTwCenW01Medium.subtitle2,
          ),
          AppSpacing.verticalSpace24,
          CustomStackedChart(
            series: [
              CustomProfileChartDataSeries(
                title: 'Fats',
                highlightColor: AppColors.ice,
                items: List.generate(
                  36,
                  (index) => CustomProfileChartDataItem(
                    color: AppColors.ice,
                    value: Random().nextInt(10),
                    date: DateTime.now().subtract(Duration(days: 30 * (index + 1))),
                  ),
                ),
              ),
              CustomProfileChartDataSeries(
                title: 'Carbs',
                highlightColor: AppColors.orangeLight,
                items: List.generate(
                  36,
                  (index) => CustomProfileChartDataItem(
                    color: AppColors.orangeLight,
                    value: Random().nextInt(10),
                    date: DateTime.now().subtract(Duration(days: 30 * (index + 1))),
                  ),
                ),
              ),
              CustomProfileChartDataSeries(
                highlightColor: AppColors.lavender,
                title: 'Protein',
                items: List.generate(
                  36,
                  (index) => CustomProfileChartDataItem(
                    color: AppColors.lavender,
                    value: Random().nextInt(10),
                    date: DateTime.now().subtract(Duration(days: 30 * (index + 1))),
                  ),
                ),
              ),
            ],
            onDataItemSelected: (item) {},
          ),
          AppSpacing.verticalSpace20,
          Text(
            'quiz'.tr(),
            style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
            textAlign: TextAlign.center,
          ),
          AppSpacing.verticalSpace16,
          AppSpacing.verticalSpace20,
          CustomArcChart(
            data: List<CustomArcChartData>.generate(
              3,
              (index) => CustomArcChartData(
                title: ['Protein', 'Carbs', 'Fats'].elementAt(index),
                color: [
                  AppColors.lavender,
                  AppColors.orangeLight,
                  AppColors.ice,
                ].elementAt(index),
                percentage: 100 / 3,
              ),
            ),
          ),
          AppSpacing.verticalSpace20,
          Text(
            'quiz'.tr(),
            style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
            textAlign: TextAlign.center,
          ),
          AppSpacing.verticalSpace20,
          AppSpacing.verticalSpace16,
          Text('CURRENT YOU', style: TypographyTwCenW01Medium.subtitle2),
          AppSpacing.verticalSpace24,
          CustomArcChart(
            data: [
              CustomArcChartData(
                title: 'Respond',
                color: AppColors.oliveDark,
                percentage: 75,
              ),
              CustomArcChartData(
                title: 'Foul',
                color: AppColors.oliveLight,
                percentage: 25,
              ),
            ],
          ),
          AppSpacing.verticalSpace20,
          Text(
            'quiz'.tr(),
            style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
            textAlign: TextAlign.center,
          ),
          AppSpacing.verticalSpace20,
          AppSpacing.verticalSpace16,
          Text('Food category'.toUpperCase(), style: TypographyTwCenW01Medium.subtitle2),
          AppSpacing.verticalSpace24,
          Divider(),
          AppSpacing.verticalSpace24,
          NutrientProgressIndicator(
            value: Random().nextInt(100).toDouble(),
            title: 'Vegetables',
            measurementQuantity: '%',
          ),
          AppSpacing.verticalSpace24,
          Divider(),
          AppSpacing.verticalSpace24,
          NutrientProgressIndicator(
            value: Random().nextInt(100).toDouble(),
            title: 'Cereal',
            measurementQuantity: '%',
          ),
          AppSpacing.verticalSpace24,
          Divider(),
          AppSpacing.verticalSpace24,
          NutrientProgressIndicator(
            value: Random().nextInt(100).toDouble(),
            title: 'Meat',
            measurementQuantity: '%',
          ),
          AppSpacing.verticalSpace24,
          Divider(),
          AppSpacing.verticalSpace24,
          NutrientProgressIndicator(
            value: Random().nextInt(100).toDouble(),
            title: 'Fish',
            measurementQuantity: '%',
          ),
          AppSpacing.verticalSpace24,
          Divider(),
          AppSpacing.verticalSpace24,
          NutrientProgressIndicator(
            value: Random().nextInt(100).toDouble(),
            title: 'Flour',
            measurementQuantity: '%',
          ),
          AppSpacing.verticalSpace24,
          Divider(),
          AppSpacing.verticalSpace24,
          NutrientProgressIndicator(
            value: Random().nextInt(100).toDouble(),
            title: 'Nuts',
            measurementQuantity: '%',
          ),
          AppSpacing.verticalSpace24,
          Divider(),
          AppSpacing.verticalSpace24,
          NutrientProgressIndicator(
            value: Random().nextInt(100).toDouble(),
            title: 'Berries',
            measurementQuantity: '%',
          ),
          AppSpacing.verticalSpace24,
          Divider(),
          AppSpacing.verticalSpace24,
          NutrientProgressIndicator(
            value: Random().nextInt(100).toDouble(),
            title: 'Fruit',
            measurementQuantity: '%',
          ),
          AppSpacing.verticalSpace24,
          Divider(),
          AppSpacing.verticalSpace24,
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ChartSortingModeButton(
                modeName: '1D',
                onTap: () {},
                isSelected: false,
              ),
              ChartSortingModeButton(
                modeName: '1W',
                onTap: () {},
                isSelected: false,
              ),
              ChartSortingModeButton(
                modeName: '1M',
                onTap: () {},
                isSelected: true,
              ),
              ChartSortingModeButton(
                modeName: '1Y',
                onTap: () {},
                isSelected: false,
              ),
              ChartSortingModeButton(
                modeName: 'All',
                onTap: () {},
                isSelected: false,
              ),
            ],
          ),
          AppSpacing.verticalSpace20,
          Text(
            'quiz'.tr(),
            style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
            textAlign: TextAlign.center,
          ),
          AppSpacing.verticalSpace20,
          AppSpacing.verticalSpace16,
          Text('Homeostasis'.toUpperCase(), style: TypographyTwCenW01Medium.subtitle2),
          AppSpacing.verticalSpace24,
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Expanded(
                child: MeasurementCard(
                  value: 8.2,
                  headerText: 'discanfort'.toUpperCase(),
                  footerText: 'Level',
                ),
              ),
              AppSpacing.horizontalSpace16,
              Expanded(
                child: MeasurementCard(
                  value: 32,
                  headerText: 'Incident'.toUpperCase(),
                  footerText: 'Cases',
                ),
              ),
            ],
          ),
          AppSpacing.verticalSpace24,
          SizedBox(
            height: 305,
            width: MediaQuery.of(context).size.width,
            child: Stack(
              children: [
                Center(child: Image.asset('assets/pngs/full_height_man.png', height: 305, width: 105)),
                Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Expanded(
                      child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: List.generate(
                            2,
                            (index) => PainPointModel(
                              title: 'Migrane',
                              frequency: Random().nextInt(100),
                              levelOfDiscomfort: Random().nextInt(10),
                            ),
                          ).map((e) => SimplePainPointTile(point: e)).toList()),
                    ),
                    AppSpacing.horizontalSpace20,
                    AppSpacing.horizontalSpace20,
                    AppSpacing.horizontalSpace20,
                    AppSpacing.horizontalSpace20,
                    AppSpacing.horizontalSpace20,
                    AppSpacing.horizontalSpace16,
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: List.generate(
                          2,
                          (index) => PainPointModel(
                            title: 'Migrane',
                            frequency: Random().nextInt(100),
                            levelOfDiscomfort: Random().nextInt(10),
                          ),
                        ).map((e) => SimplePainPointTile(point: e)).toList(),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          AppSpacing.verticalSpace24,
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ChartSortingModeButton(
                modeName: '1D',
                onTap: () {},
                isSelected: false,
              ),
              ChartSortingModeButton(
                modeName: '1W',
                onTap: () {},
                isSelected: false,
              ),
              ChartSortingModeButton(
                modeName: '1M',
                onTap: () {},
                isSelected: true,
              ),
              ChartSortingModeButton(
                modeName: '1Y',
                onTap: () {},
                isSelected: false,
              ),
              ChartSortingModeButton(
                modeName: 'All',
                onTap: () {},
                isSelected: false,
              ),
            ],
          ),
          AppSpacing.verticalSpace20,
          TextButton(
            onPressed: () {},
            child: Text(
              'Evaluate the current state',
              style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
            ),
          ),
          AppSpacing.verticalSpace24,
          Column(
            mainAxisSize: MainAxisSize.min,
            children: List.generate(
              5,
              (index) => PainPointModel(
                title: 'Migrane',
                frequency: Random().nextInt(100),
                levelOfDiscomfort: Random().nextInt(10),
              ),
            )
                .map(
                  (e) => PainPointTile(
                    point: e,
                    isSelected: false,
                    onTap: () => AppInteractionsHelper.showBottomSheet(
                      context: context,
                      title: 'actions'.tr(),
                      child: PainPointSheet(),
                      color: Colors.white,
                      barrierColor: AppColors.oliveDark,
                    ),
                  ),
                )
                .toList(),
          ),
          AppSpacing.verticalSpace24,
          QuizCard(
            quiz: Quiz(
              title: 'Quiz',
              description:
                  'nvlsabdsfbdbsbadfbdsgbsfgnabj nk kjsjdkfs jhbf hjs db ghdbf ghjdb gjhsdbf gjh sdb gjhsdfb gjhdb aknsdj nlaks ndgkjdfsngjk dnfg kjasnd gkjsndgjkdfngkjdsngjkdsngkdjfsg jkdsfngjkdfngkjdsnfgk jdsnf gkj ndsfjk gndfjgk dnf gkjds nfgkj sndfk',
              icons: [
                ContentCategoryIcon(iconPath: 'sunset', isLocal: true),
                ContentCategoryIcon(iconPath: 'wind', isLocal: true),
              ],
              colorHex: '#F2E3E8',
              time: Duration(minutes: 50),
              options: [],
              type: QuizTypes.getByIndex(0),
            ),
          ),
          AppSpacing.verticalSpace30,
        ],
      ),
    );
  }
}
