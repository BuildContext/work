import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/custom_widgets/question_bottom_sheet.dart';
import 'package:test_project/presentation/pages/profile/settings/about_app_page/about_app_page.dart';
import 'package:test_project/presentation/pages/profile/settings/agreement_page/agreement_page.dart';
import 'package:test_project/presentation/pages/profile/settings/change_password_page/bloc/change_password_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/change_password_page/change_password_page.dart';
import 'package:test_project/presentation/pages/profile/settings/customize_look_and_feel_page/customize_look_and_feel_page.dart';
import 'package:test_project/presentation/pages/profile/settings/profile_settings_page/bloc/profile_page_settings_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/profile_settings_page/profile_settings_page.dart';
import 'package:test_project/presentation/pages/profile/settings/user_access_permissions/bloc/user_access_permissions_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/user_access_permissions/user_permission_accesses_page.dart';
import 'package:test_project/presentation/pages/profile/settings/user_feedback_page/bloc/user_feeback_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/user_feedback_page/user_feedback_page.dart';
import 'package:test_project/presentation/pages/profile/settings/user_notifications_page/bloc/user_notifications_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/user_notifications_page/user_notifications_page.dart';
import 'package:test_project/presentation/pages/profile/settings/user_preferences_page/bloc/user_preferences_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/user_preferences_page/user_preferences_page.dart';
import 'package:test_project/presentation/pages/profile/settings/user_subscription_page/bloc/user_subscription_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/user_subscription_page/user_subscription_page.dart';
import 'package:test_project/presentation/pages/profile/settings/widgets/reminders_sheet.dart';
import 'package:test_project/presentation/pages/profile/settings/widgets/settings_action_tile.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

class SettingsSheet extends StatelessWidget {
  const SettingsSheet({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.7,
      width: MediaQuery.of(context).size.width,
      child: ListView(
        children: [
          Text(
            'settings'.tr(),
            style: TypographyTwCenW01Medium.title1,
          ),
          AppSpacing.verticalSpace20,
          Divider(),
          SettingsActionTile(
            title: 'profile'.tr(),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => BlocProvider(
                  create: (context) => ProfileSettingsPageCubit(),
                  child: ProfileSettingsPage(),
                ),
              ),
            ),
          ),
          Divider(),
          SettingsActionTile(
            title: 'password'.tr(),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => BlocProvider(
                  create: (context) => ChangePasswordPageCubit(),
                  child: ChangePasswordPage(),
                ),
              ),
            ),
          ),
          Divider(),
          SettingsActionTile(
            title: 'my_preferences'.tr(),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => BlocProvider(
                  create: (context) => UserPreferencesPageCubit(),
                  child: UserPreferencesPage(),
                ),
              ),
            ),
          ),
          Divider(),
          SettingsActionTile(
            title: 'subscription'.tr(),
            onTap: () {
              Navigator.pop(context);
              AppInteractionsHelper.showBottomSheet(
                context: context,
                barrierColor: AppColors.oliveDark,
                child: BlocProvider(
                  create: (context) => UserSubscriptionPageCubit(),
                  child: UserSubscriptionSheet(),
                ),
              );
            },
          ),
          Divider(),
          SettingsActionTile(
            title: 'reminders'.tr(),
            onTap: () {
              Navigator.pop(context);
              AppInteractionsHelper.showBottomSheet(
                context: context,
                barrierColor: AppColors.oliveDark,
                child: QuestionBottomSheet(
                  question: 'Set regular reminders?',
                  description: 'This will help you to be more consistent and follow nutrition practicess to improve Vikriti and guna.',
                  secondChild: ConfigureReminderSheet(),
                ),
              );
            },
          ),
          Divider(),
          SettingsActionTile(
            title: 'notifications'.tr(),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => BlocProvider(
                  create: (context) => UserNotificationsPageCubit(),
                  child: UserNotificationsPage(),
                ),
              ),
            ),
          ),
          Divider(),
          SettingsActionTile(
            title: 'access_permissions'.tr(),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => BlocProvider(
                  create: (context) => UserAccessPermissionsPageCubit(),
                  child: UserAccessPermissionsPage(),
                ),
              ),
            ),
          ),
          Divider(),
          SettingsActionTile(
            title: 'customize_look_and_feel'.tr(),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => CustomizeLookAndFeelPage(),
              ),
            ),
          ),
          Divider(),
          SettingsActionTile(
            title: 'feedback'.tr(),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => BlocProvider(
                  create: (context) => UserFeedbackPageCubit(),
                  child: UserFeedbackPage(),
                ),
              ),
            ),
          ),
          Divider(),
          SettingsActionTile(
            title: 'agreement'.tr(),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AgreementPage(),
              ),
            ),
          ),
          Divider(),
          SettingsActionTile(
            title: 'about_app'.tr(),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AboutAppPage(),
              ),
            ),
          ),
          Divider(),
          AppSpacing.verticalSpace20,
          AppSpacing.verticalSpace20,
          CustomButton(onTap: () {}, text: 'quit'.tr()),
          AppSpacing.verticalSpace24,
          TextButton(
            onPressed: () {},
            child: Text(
              'delete_account'.tr(),
              style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
            ),
          ),
        ],
      ),
    );
  }
}
