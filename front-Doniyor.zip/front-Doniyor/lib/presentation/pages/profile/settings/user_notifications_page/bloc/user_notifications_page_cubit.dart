import 'package:bloc/bloc.dart';
import 'package:test_project/core/models/user_notification_type.dart';
import 'package:test_project/presentation/pages/profile/settings/user_notifications_page/bloc/user_notifications_page_state.dart';

class UserNotificationsPageCubit extends Cubit<UserNotificationsPageState> {
  UserNotificationsPageCubit() : super(UserNotificationsInitial()) {
    loadUserNotificationData();
  }

  Future<void> loadUserNotificationData() async {
    emit(UserNotificationsLoading());
    await Future.delayed(Duration(seconds: 2));
    emit(
      UserNotificationsSuccess(
        notificationsType: [
          NotificationType(title: 'Push', isEnabled: true),
          NotificationType(title: 'Email', isEnabled: true),
          NotificationType(title: 'SMS', isEnabled: true),
          NotificationType(title: 'Phone', isEnabled: true),
        ],
      ),
    );
  }
}
