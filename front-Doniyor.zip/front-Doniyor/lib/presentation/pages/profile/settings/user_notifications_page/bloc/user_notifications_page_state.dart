import 'package:test_project/core/models/user_notification_type.dart';

abstract class UserNotificationsPageState {}

class UserNotificationsInitial extends UserNotificationsPageState {}

class UserNotificationsLoading extends UserNotificationsPageState {}

class UserNotificationsSuccess extends UserNotificationsPageState {
  final List<NotificationType> notificationsType;

  UserNotificationsSuccess({required this.notificationsType});
}

class UserNotificationsError extends UserNotificationsPageState {
  final String error;

  UserNotificationsError({required this.error});
}
