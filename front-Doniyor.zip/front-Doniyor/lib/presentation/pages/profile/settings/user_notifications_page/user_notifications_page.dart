import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/custom_widgets/switchable_tile.dart';
import 'package:test_project/presentation/pages/profile/settings/user_notifications_page/bloc/user_notifications_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/user_notifications_page/bloc/user_notifications_page_state.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/typography.dart';

class UserNotificationsPage extends StatelessWidget {
  const UserNotificationsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<UserNotificationsPageCubit>();
    return Scaffold(
      appBar: AppBar(
        title: Text('notifications'.tr(), style: TypographyTwCenW01Medium.title2),
      ),
      body: BlocConsumer<UserNotificationsPageCubit, UserNotificationsPageState>(
        bloc: cubit,
        listener: (context, state) {},
        builder: (context, state) {
          if (state is UserNotificationsLoading) return Loader();
          if (state is UserNotificationsSuccess)
            return ListView.separated(
              padding: AppInsets.horizontalInsets28.copyWith(top: 24),
              itemBuilder: (context, index) {
                final notification = state.notificationsType.elementAt(index);
                return SwitchableTile(title: notification.title, isEnabled: notification.isEnabled);
              },
              separatorBuilder: (context, index) => const Divider(
                thickness: 0.5,
              ),
              itemCount: state.notificationsType.length,
            );
          return Container();
        },
      ),
    );
  }
}
