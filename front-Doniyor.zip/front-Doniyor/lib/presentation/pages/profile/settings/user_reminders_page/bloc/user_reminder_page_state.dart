import 'package:test_project/core/models/user_reminder.dart';

abstract class UserRemindersPageState {}

class UserRemindersInitial extends UserRemindersPageState {}

class UserRemindersLoading extends UserRemindersPageState {}

class UserRemindersSuccess extends UserRemindersPageState {
  final List<UserReminder> reminders;

  UserRemindersSuccess({required this.reminders});
}

class UserRemindersError extends UserRemindersPageState {
  final String error;

  UserRemindersError({required this.error});
}
