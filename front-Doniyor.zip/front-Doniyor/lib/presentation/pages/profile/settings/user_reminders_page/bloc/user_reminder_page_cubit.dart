import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:test_project/core/models/user_reminder.dart';
import 'package:test_project/presentation/pages/profile/settings/user_reminders_page/bloc/user_reminder_page_state.dart';

class UserRemindersPageCubit extends Cubit<UserRemindersPageState> {
  UserRemindersPageCubit() : super(UserRemindersInitial()) {
    loadRemindersData();
  }

  Future<void> loadRemindersData() async {
    emit(UserRemindersLoading());
    await Future.delayed(Duration(seconds: 2));
    emit(
      UserRemindersSuccess(
        reminders: List.generate(
          3,
          (index) => UserReminder(
            type: 'Signal',
            title: 'Gana',
            time: TimeOfDay(hour: 01, minute: 00),
            isEnabled: index == 1,
            enabledWeekDays: [],
          ),
        ),
      ),
    );
  }
}
