import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/user_reminder.dart';
import 'package:test_project/presentation/custom_widgets/app_switch_button.dart';
import 'package:test_project/presentation/pages/profile/settings/user_reminders_page/widgets/weekday_switcher.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class ReminderWidget extends StatelessWidget {
  final UserReminder reminder;
  final bool enableEditing;
  final VoidCallback onDeleted;

  const ReminderWidget({
    Key? key,
    required this.reminder,
    required this.enableEditing,
    required this.onDeleted,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final List<String> weekdays = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    return Container(
      padding: AppInsets.horizontalInsets8,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(color: Theme.of(context).dividerColor, width: 0.5),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          AppSpacing.verticalSpace14,
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: reminder.title + ' ',
                        style: TypographyNeueHaasUnicaW1G.basic2.copyWith(color: AppColors.dark.withOpacity(0.5)),
                      ),
                      TextSpan(
                        text: reminder.type,
                        style: TypographyNeueHaasUnicaW1G.basic2.copyWith(color: AppColors.dark.withOpacity(0.5)),
                      ),
                      TextSpan(
                        text: ' ${reminder.time.hour.toString().padLeft(2, '0')}:${reminder.time.minute.toString().padLeft(2, '0')}',
                        style: TypographyNeueHaasUnicaW1G.basic2.copyWith(color: AppColors.dark.withOpacity(0.5)),
                      ),
                    ],
                  ),
                ),
              ),
              if (!enableEditing) AppSwitchButton(onSwitched: (value) {}, isEnabled: reminder.isEnabled),
              if (enableEditing) IconButton(onPressed: onDeleted, icon: SvgPicture.asset('assets/svgs/delete.svg'))
            ],
          ),
          AppSpacing.verticalSpace12,
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              for (int i = 0; i < 7; i++)
                WeekdaySwitchButton(
                  onSwitched: (value) {},
                  isEnabled: DateTime.now().second == i * 4,
                  title: weekdays[i],
                ),
            ],
          ),
          AppSpacing.verticalSpace12,
          AppSpacing.verticalSpace24,
        ],
      ),
    );
  }
}
