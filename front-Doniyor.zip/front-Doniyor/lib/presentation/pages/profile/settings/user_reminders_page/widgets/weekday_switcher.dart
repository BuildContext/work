import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class WeekdaySwitchButton extends StatefulWidget {
  final ValueChanged<bool> onSwitched;
  final bool? isEnabled;
  final String title;

  const WeekdaySwitchButton({Key? key, required this.onSwitched, this.isEnabled, required this.title}) : super(key: key);

  @override
  State<WeekdaySwitchButton> createState() => _WeekdaySwitchButtonState();
}

class _WeekdaySwitchButtonState extends State<WeekdaySwitchButton> {
  late bool _isEnabled = widget.isEnabled ?? false;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _isEnabled ? AppColors.oliveDark : AppColors.oliveLight,
      borderRadius: BorderRadius.circular(20),
      elevation: 0,
      child: InkWell(
        onTap: () {
          setState(() => _isEnabled = !_isEnabled);
          widget.onSwitched(_isEnabled);
        },
        borderRadius: BorderRadius.circular(20),
        child: AnimatedContainer(
          duration: Duration(milliseconds: 125),
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _isEnabled ? AppColors.oliveDark : AppColors.oliveLight,
          ),
          child: Center(
            child: Text(
              widget.title,
              style: TypographyNeueHaasUnicaW1G.menu1,
            ),
          ),
        ),
      ),
    );
  }
}
