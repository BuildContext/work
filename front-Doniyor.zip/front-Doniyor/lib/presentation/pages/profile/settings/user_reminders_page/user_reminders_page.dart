import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/user_reminder.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/pages/profile/settings/user_reminders_page/bloc/user_reminder_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/user_reminders_page/bloc/user_reminder_page_state.dart';
import 'package:test_project/presentation/pages/profile/settings/user_reminders_page/widgets/reminder_widget.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class UserRemindersSheet extends StatefulWidget {
  const UserRemindersSheet({Key? key}) : super(key: key);

  @override
  State<UserRemindersSheet> createState() => _UserRemindersSheetState();
}

class _UserRemindersSheetState extends State<UserRemindersSheet> {
  List<UserReminder> deletedReminders = [];
  bool inEditingMode = false;
  @override
  Widget build(BuildContext context) {
    final cubit = context.read<UserRemindersPageCubit>();
    return BlocConsumer<UserRemindersPageCubit, UserRemindersPageState>(
      bloc: cubit,
      listener: (context, state) {},
      builder: (context, state) {
        if (state is UserRemindersLoading) return SizedBox(height: MediaQuery.of(context).size.height * 0.7, child: Loader());
        if (state is UserRemindersSuccess)
          return SizedBox(
            height: MediaQuery.of(context).size.height * 0.7,
            width: MediaQuery.of(context).size.width,
            child: ListView(
              children: [
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'reminders'.tr(),
                      style: TypographyTwCenW01Medium.title1,
                    ),
                    IconButton(
                      onPressed: () => setState(() => inEditingMode = !inEditingMode),
                      icon: SvgPicture.asset('assets/svgs/edit.svg'),
                    ),
                  ],
                ),
                AppSpacing.verticalSpace16,
                AppSpacing.verticalSpace16,
                for (final e in state.reminders)
                  ReminderWidget(
                    reminder: e,
                    enableEditing: inEditingMode,
                    onDeleted: () => setState(() => deletedReminders.add(e)),
                  ),
                if (!inEditingMode)
                  CustomButton(
                    width: MediaQuery.of(context).size.width,
                    onTap: () {},
                    color: deletedReminders.isEmpty ? Colors.transparent : AppColors.oliveColor,
                    text: 'add'.tr(),
                  ),
                AppSpacing.verticalSpace16,
                CustomButton(
                  width: MediaQuery.of(context).size.width,
                  onTap: () {},
                  text: 'approve'.tr(),
                ),
                AppSpacing.verticalSpace16,
                CustomButton(
                  width: MediaQuery.of(context).size.width,
                  onTap: () {},
                  color: Colors.transparent,
                  showBorder: false,
                  text: 'skip'.tr(),
                  textStyle: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
                ),
                AppSpacing.verticalSpace16,
              ],
            ),
          );
        return Container();
      },
    );
  }
}
