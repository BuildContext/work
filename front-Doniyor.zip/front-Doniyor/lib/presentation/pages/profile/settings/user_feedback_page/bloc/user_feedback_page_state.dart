abstract class UserFeedbackPageState {}

class UserFeedbackInitial extends UserFeedbackPageState {}

class UserFeedbackLoading extends UserFeedbackPageState {}

class UserFeedbackSuccess extends UserFeedbackPageState {}

class UserFeedbackError extends UserFeedbackPageState {
  final String error;

  UserFeedbackError({required this.error});
}
