import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/custom_widgets/custom_text_field.dart';
import 'package:test_project/presentation/pages/profile/settings/user_feedback_page/bloc/user_feeback_page_cubit.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';

class UserFeedbackPage extends StatelessWidget {
  const UserFeedbackPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<UserFeedbackPageCubit>();
    return Scaffold(
      appBar: AppBar(
        title: Text('feedback'.tr(), style: TypographyTwCenW01Medium.title2),
      ),
      body: Padding(
        padding: AppInsets.horizontalInsets28,
        child: Column(
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            AppSpacing.verticalSpace24,
            Text(
              'Отправьте нам ваш комментарий и описание проблемы, наши служба поддержки обязательно ответят вам в течении суток.',
              style: TypographyNeueHaasUnicaW1G.basic2,
            ),
            AppSpacing.verticalSpace30,
            CustomTextField(
              minLines: 1,
              maxLines: 10,
              controller: cubit.feedbackController,
              helperText: 'description'.tr().toUpperCase(),
              hintText: 'description'.tr(),
            ),
            Expanded(child: SizedBox()),
            CustomButton(
              onTap: () {},
              text: 'send_message'.tr(),
            ),
            AppSpacing.verticalSpace30,
          ],
        ),
      ),
    );
  }
}
