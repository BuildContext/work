import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:test_project/presentation/pages/profile/settings/user_feedback_page/bloc/user_feedback_page_state.dart';

class UserFeedbackPageCubit extends Cubit<UserFeedbackPageState> {
  UserFeedbackPageCubit() : super(UserFeedbackInitial());

  TextEditingController feedbackController = TextEditingController();

  @override
  Future<void> close() {
    feedbackController.dispose();
    return super.close();
  }
}
