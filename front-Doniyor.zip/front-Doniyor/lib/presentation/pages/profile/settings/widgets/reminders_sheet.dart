import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/custom_widgets/tag_tile.dart';
import 'package:test_project/presentation/pages/profile/settings/user_reminders_page/bloc/user_reminder_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/user_reminders_page/user_reminders_page.dart';
import 'package:test_project/presentation/pages/profile/settings/user_reminders_page/widgets/weekday_switcher.dart';
import 'package:test_project/presentation/pages/profile/settings/widgets/custom_time_picker.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

class ConfigureReminderSheet extends StatefulWidget {
  const ConfigureReminderSheet({Key? key}) : super(key: key);

  @override
  State<ConfigureReminderSheet> createState() => _ConfigureReminderSheetState();
}

class _ConfigureReminderSheetState extends State<ConfigureReminderSheet> with SingleTickerProviderStateMixin {
  late TabController tabController = TabController(length: 2, vsync: this);
  final List<String> weekdays = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  TimeOfDay _chosenTime = TimeOfDay.now();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.7,
      child: ListView(
        children: [
          Text('Choose a time', style: TypographyTwCenW01Medium.title1),
          AppSpacing.verticalSpace24,
          Text('tags'.tr().toUpperCase(), style: TypographyTwCenW01Medium.subtitle2),
          AppSpacing.verticalSpace24,
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              TagTile(tag: ContentCategoryTag(title: 'Seasonal'), onTap: () {}),
              TagTile(tag: ContentCategoryTag(title: 'Spring'), onTap: () {}),
              TagTile(tag: ContentCategoryTag(title: 'Summer'), onTap: () {}),
              TagTile(tag: ContentCategoryTag(title: 'Christmas'), onTap: () {}),
              TagTile(tag: ContentCategoryTag(title: 'Christmas'), onTap: () {}),
              TagTile(tag: ContentCategoryTag(title: 'Christmas'), onTap: () {}),
            ],
          ),
          AppSpacing.verticalSpace16,
          PreferredSize(
            preferredSize: Size(MediaQuery.of(context).size.width, 18),
            child: TabBar(
              controller: tabController,
              indicatorColor: AppColors.darkLight,
              labelStyle: TypographyTwCenW01Medium.caption2,
              unselectedLabelStyle: TypographyTwCenW01Medium.caption2.copyWith(color: AppColors.greyLight),
              labelColor: AppColors.dark,
              unselectedLabelColor: AppColors.darkLight.withOpacity(0.5),
              indicatorWeight: 1.5,
              tabs: [
                Tab(text: 'PUSH', iconMargin: EdgeInsets.zero),
                Tab(text: 'SIGNAL', iconMargin: EdgeInsets.zero),
              ],
            ),
          ),
          AppSpacing.verticalSpace16,
          SizedBox(
            height: 242,
            child: TabBarView(
              controller: tabController,
              children: [
                CustomTimePicker(
                  onTimeChanged: (time) {},
                  initialTime: _chosenTime,
                ),
                Container(),
              ],
            ),
          ),
          AppSpacing.verticalSpace16,
          AppSpacing.verticalSpace16,
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              for (int i = 0; i < 7; i++)
                WeekdaySwitchButton(
                  onSwitched: (value) {},
                  isEnabled: DateTime.now().second == i * 4,
                  title: weekdays[i],
                ),
            ],
          ),
          AppSpacing.verticalSpace20,
          CustomButton(
            onTap: () {
              Navigator.pop(context);
              AppInteractionsHelper.showBottomSheet(
                context: context,
                barrierColor: AppColors.oliveDark,
                child: BlocProvider(
                  create: (context) => UserRemindersPageCubit(),
                  child: UserRemindersSheet(),
                ),
              );
            },
            text: 'approve'.tr(),
            textStyle: TypographyNeueHaasUnicaW1G.buttonBold,
          ),
          AppSpacing.verticalSpace20,
          CustomButton(
            onTap: () => Navigator.pop(context),
            color: Colors.white,
            text: 'skip'.tr(),
            showBorder: false,
            textStyle: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
          ),
        ],
      ),
    );
  }
}
