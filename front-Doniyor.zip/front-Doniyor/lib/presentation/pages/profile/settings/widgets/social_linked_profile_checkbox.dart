import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class SocialLinkedCheckbox extends StatefulWidget {
  final String title;

  const SocialLinkedCheckbox({Key? key, required this.title}) : super(key: key);

  @override
  State<SocialLinkedCheckbox> createState() => _SocialLinkedCheckboxState();
}

class _SocialLinkedCheckboxState extends State<SocialLinkedCheckbox> {
  bool _isChecked = false;
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      children: [
        AnimatedContainer(
          duration: Duration(milliseconds: 250),
          height: 21,
          width: 21,
          decoration: BoxDecoration(
            border: Border.all(color: _isChecked ? AppColors.darkLight : AppColors.dark),
          ),
          child: Checkbox(
            checkColor: AppColors.darkLight,
            activeColor: Colors.transparent,
            fillColor: MaterialStateProperty.resolveWith((states) => Colors.transparent),
            value: _isChecked,
            splashRadius: 0,
            onChanged: (val) => setState(() => _isChecked = val ?? !_isChecked),
          ),
        ),
        AppSpacing.horizontalSpace16,
        Expanded(child: Text(widget.title, style: TypographyNeueHaasUnicaW1G.basic2)),
      ],
    );
  }
}
