import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class CustomTimePicker extends StatefulWidget {
  final TimeOfDay initialTime;
  final ValueChanged<TimeOfDay> onTimeChanged;

  const CustomTimePicker({
    Key? key,
    required this.onTimeChanged,
    required this.initialTime,
  }) : super(key: key);

  @override
  State<CustomTimePicker> createState() => _CustomTimePickerState();
}

class _CustomTimePickerState extends State<CustomTimePicker> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 163,
      height: 242,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ScrollableNumericValuePicker<int>(
            values: List<int>.generate(23, (index) => index + 1),
            onValueChanged: (value) {},
            measurementType: 'H',
          ),
          AppSpacing.horizontalSpace10,
          ScrollableNumericValuePicker<int>(
            values: List<int>.generate(59, (index) => index + 1),
            onValueChanged: (value) {},
            measurementType: 'M',
          ),
        ],
      ),
    );
  }
}

class ScrollableNumericValuePicker<T extends num> extends StatefulWidget {
  final List<T> values;
  final ValueChanged<T> onValueChanged;
  final String measurementType;

  const ScrollableNumericValuePicker({
    Key? key,
    required this.values,
    required this.onValueChanged,
    required this.measurementType,
  }) : super(key: key);

  @override
  State<ScrollableNumericValuePicker> createState() => _ScrollableNumericValuePickerState();
}

class _ScrollableNumericValuePickerState extends State<ScrollableNumericValuePicker> {
  late dynamic selectedValue = widget.values.first;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 242,
      width: 85,
      child: Stack(
        fit: StackFit.loose,
        children: [
          Center(
            child: Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 67,
                  height: 55,
                  decoration: BoxDecoration(
                    color: AppColors.oliveLight.withOpacity(0.5),
                    borderRadius: AppBorderRadius.borderRadiusAll8,
                    border: Border.all(
                      color: AppColors.oliveDark,
                    ),
                  ),
                ),
                Text(
                  widget.measurementType,
                  style: TypographyNeueHaasUnicaW1G.basic3,
                ),
              ],
            ),
          ),
          SizedBox(
            width: 67,
            child: Center(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: List<Widget>.from(
                    widget.values.map(
                      (e) => SizedBox(
                        height: 56,
                        child: Center(child: Text(e.toString(), style: TypographyNeueHaasUnicaW1G.basic2)),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
