import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/typography.dart';

class SettingsActionTile extends StatelessWidget {
  final String title;
  final VoidCallback onTap;

  const SettingsActionTile({
    Key? key,
    required this.title,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      elevation: 0,
      child: InkWell(
        onTap: onTap,
        child: Ink(
          height: 64,
          child: Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Expanded(child: Text(title, style: TypographyNeueHaasUnicaW1G.basic2)),
              Icon(Icons.chevron_right, size: 35),
            ],
          ),
        ),
      ),
    );
  }
}
