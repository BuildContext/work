import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/pages/auth/registration/privacy_policy_page.dart';
import 'package:test_project/presentation/pages/profile/settings/user_subscription_page/bloc/user_subscription_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/user_subscription_page/bloc/user_subscription_page_state.dart';
import 'package:test_project/presentation/pages/profile/settings/user_subscription_page/widgets/register_to_buy_subscription.dart';
import 'package:test_project/presentation/pages/profile/settings/user_subscription_page/widgets/subscription_carousel.dart';
import 'package:test_project/presentation/pages/profile/settings/user_subscription_page/widgets/subscription_plan_button.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

class UserSubscriptionSheet extends StatelessWidget {
  const UserSubscriptionSheet({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<UserSubscriptionPageCubit>();
    return BlocConsumer<UserSubscriptionPageCubit, UserSubscriptionPageState>(
      bloc: cubit,
      listener: (context, state) {},
      builder: (context, state) {
        if (state is UserSubscriptionLoading) return SizedBox(height: MediaQuery.of(context).size.height * 0.7, child: Loader());
        if (state is UserSubscriptionSuccess)
          return SizedBox(
            height: MediaQuery.of(context).size.height * 0.7,
            width: MediaQuery.of(context).size.width,
            child: ListView(
              children: [
                AppSpacing.verticalSpace16,
                Image.asset(
                  'assets/pngs/Ayurveda.png',
                  fit: BoxFit.fitWidth,
                ),
                AppSpacing.verticalSpace8,
                Text(
                  'Start your journey today',
                  style: TypographyNeueHaasUnicaW1G.link3.copyWith(color: AppColors.greyLight),
                  textAlign: TextAlign.center,
                ),
                AppSpacing.verticalSpace16,
                SubscriptionCarousel(
                  height: 247,
                  onIndexChanged: (index) {},
                  items: [
                    for (int i = 0; i < 3; i++)
                      Padding(
                        padding: AppInsets.horizontalInsets16,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'Start your journey to a better version of yourself',
                              style: TypographyTwCenW01Medium.title1,
                            ),
                            AppSpacing.verticalSpace14,
                            Text(
                              'The apps will help you develop new habits and track your progress.',
                              style: TypographyNeueHaasUnicaW1G.basic2,
                            ),
                            Spacer(),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                SvgPicture.asset('assets/svgs/checked_square.svg'),
                                AppSpacing.horizontalSpace8,
                                Expanded(
                                  child: Text(
                                    'Unlimited live and on-demand classes',
                                    style: TypographyNeueHaasUnicaW1G.basic3,
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                SvgPicture.asset('assets/svgs/checked_square.svg'),
                                AppSpacing.horizontalSpace8,
                                Expanded(
                                  child: Text(
                                    'Unlimited live and on-demand classes',
                                    style: TypographyNeueHaasUnicaW1G.basic3,
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                SvgPicture.asset('assets/svgs/checked_square.svg'),
                                AppSpacing.horizontalSpace8,
                                Expanded(
                                  child: Text(
                                    'Unlimited live and on-demand classes',
                                    style: TypographyNeueHaasUnicaW1G.basic3,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
                AppSpacing.verticalSpace30,
                Text(
                  'Enter promo code*'.toUpperCase(),
                  style: TypographyNeueHaasUnicaW1G.caption3,
                ),
                AppSpacing.verticalSpace8,
                Divider(),
                AppSpacing.verticalSpace20,
                Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            'BEST VALUE',
                            style: TypographyTwCenW01Medium.caption2,
                            textAlign: TextAlign.center,
                          ),
                          AppSpacing.verticalSpace8,
                          SubscriptionPlanButton(
                            isSelected: true,
                            onTap: () {},
                            title: 'Annual plan',
                            planPrice: 609,
                            period: 'yr',
                          ),
                        ],
                      ),
                    ),
                    AppSpacing.horizontalSpace16,
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            'BEST VALUE',
                            style: TypographyTwCenW01Medium.caption2,
                            textAlign: TextAlign.center,
                          ),
                          AppSpacing.verticalSpace8,
                          SubscriptionPlanButton(
                            isSelected: false,
                            onTap: () {},
                            title: 'Monthly plan',
                            planPrice: 59,
                            period: 'mo',
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                AppSpacing.verticalSpace16,
                RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: 'First 14 days free. ',
                        style: TypographyNeueHaasUnicaW1G.menu3,
                      ),
                      TextSpan(
                        text: ' Restore Purchases',
                        style: TypographyNeueHaasUnicaW1G.menu3.copyWith(color: AppColors.greyLight),
                      ),
                      TextSpan(
                        text: ' – ',
                        style: TypographyNeueHaasUnicaW1G.menu3,
                      ),
                      TextSpan(
                        text: 'Legal Privacy',
                        style: TypographyNeueHaasUnicaW1G.menu3.copyWith(color: AppColors.greyLight),
                      ),
                    ],
                  ),
                ),
                AppSpacing.verticalSpace16,
                CustomButton(
                  onTap: () async {
                    final policyAccepted = await Navigator.push(context, MaterialPageRoute(builder: (context) => PrivacyPolicyPage()));
                    if (policyAccepted) {
                      Navigator.pop(context);
                      AppInteractionsHelper.showBottomSheet(
                        context: context,
                        child: RegisterToSubscribeSheet(),
                        barrierColor: AppColors.oliveDark,
                      );
                    }
                  },
                  text: 'start'.tr(),
                ),
              ],
            ),
          );
        return Container();
      },
    );
  }

  String getMonthNameByIndex(int index) {
    switch (index) {
      case 1:
        return 'jan'.tr();
      case 2:
        return 'feb'.tr();
      case 3:
        return 'mar'.tr();
      case 4:
        return 'apr'.tr();
      case 5:
        return 'may'.tr();
      case 6:
        return 'jun'.tr();
      case 7:
        return 'jul'.tr();
      case 8:
        return 'aug'.tr();
      case 9:
        return 'sep'.tr();
      case 10:
        return 'oct'.tr();
      case 11:
        return 'nov'.tr();
      case 12:
        return 'dec'.tr();
      default:
        return '';
    }
  }
}
