import 'package:test_project/core/models/user_subscription_data.dart';

abstract class UserSubscriptionPageState {}

class UserSubscriptionInitial extends UserSubscriptionPageState {}

class UserSubscriptionLoading extends UserSubscriptionPageState {}

class UserSubscriptionSuccess extends UserSubscriptionPageState {
  final UserSubscriptionData subscriptionData;

  UserSubscriptionSuccess({required this.subscriptionData});
}

class UserSubscriptionError extends UserSubscriptionPageState {
  final String error;

  UserSubscriptionError({required this.error});
}
