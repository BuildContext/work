import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/pages/profile/settings/user_subscription_page/widgets/login_to_buy_subscription_sheet.dart';
import 'package:test_project/presentation/pages/profile/settings/user_subscription_page/widgets/subscription_carousel.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

class RegisterToSubscribeSheet extends StatelessWidget {
  const RegisterToSubscribeSheet({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.7,
      width: MediaQuery.of(context).size.width,
      child: ListView(
        children: [
          AppSpacing.verticalSpace16,
          Image.asset(
            'assets/pngs/Ayurveda.png',
            fit: BoxFit.fitWidth,
          ),
          AppSpacing.verticalSpace8,
          Text(
            'Start your journey today',
            style: TypographyNeueHaasUnicaW1G.link3.copyWith(color: AppColors.greyLight),
            textAlign: TextAlign.center,
          ),
          AppSpacing.verticalSpace16,
          SubscriptionCarousel(
            height: 247,
            onIndexChanged: (index) {},
            items: [
              for (int i = 0; i < 3; i++)
                Padding(
                  padding: AppInsets.horizontalInsets16,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Start your journey to a better version of yourself',
                        style: TypographyTwCenW01Medium.title1,
                      ),
                      AppSpacing.verticalSpace14,
                      Text(
                        'The apps will help you develop new habits and track your progress.',
                        style: TypographyNeueHaasUnicaW1G.basic2,
                      ),
                      Spacer(),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          SvgPicture.asset('assets/svgs/checked_square.svg'),
                          AppSpacing.horizontalSpace8,
                          Expanded(
                            child: Text(
                              'Unlimited live and on-demand classes',
                              style: TypographyNeueHaasUnicaW1G.basic3,
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          SvgPicture.asset('assets/svgs/checked_square.svg'),
                          AppSpacing.horizontalSpace8,
                          Expanded(
                            child: Text(
                              'Unlimited live and on-demand classes',
                              style: TypographyNeueHaasUnicaW1G.basic3,
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          SvgPicture.asset('assets/svgs/checked_square.svg'),
                          AppSpacing.horizontalSpace8,
                          Expanded(
                            child: Text(
                              'Unlimited live and on-demand classes',
                              style: TypographyNeueHaasUnicaW1G.basic3,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
            ],
          ),
          AppSpacing.verticalSpace30,
          CustomButton(
            onTap: () {
              Navigator.pop(context);
              AppInteractionsHelper.showBottomSheet(
                context: context,
                title: 'To continue you need to login',
                child: LoginToBuySubscriptionSheet(),
                barrierColor: AppColors.oliveDark,
              );
            },
            text: 'register'.tr(),
            showBorder: true,
          ),
          AppSpacing.verticalSpace16,
          CustomButton(
            onTap: () => Navigator.pop(context),
            color: Colors.white,
            text: 'skip'.tr(),
            showBorder: false,
            textStyle: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
          ),
        ],
      ),
    );
  }
}
