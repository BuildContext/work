import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_theme.dart';

class CarouselSliderDotIndicator extends StatelessWidget {
  final bool isSelected;
  final VoidCallback onTap;

  const CarouselSliderDotIndicator({
    Key? key,
    required this.isSelected,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 12,
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: Duration(milliseconds: 250),
          height: isSelected ? 12 : 8,
          width: isSelected ? 12 : 8,
          margin: AppInsets.horizontalInsets4,
          padding: EdgeInsets.all(isSelected ? 2 : 0),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white,
            border: Border.all(color: AppColors.oliveDark, width: 0.5),
          ),
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isSelected ? AppColors.oliveDark : AppColors.oliveLight,
            ),
            height: 8,
            width: 8,
          ),
        ),
      ),
    );
  }
}
