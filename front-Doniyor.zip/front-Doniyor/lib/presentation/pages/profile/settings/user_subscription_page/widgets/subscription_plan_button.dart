import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class SubscriptionPlanButton extends StatelessWidget {
  final VoidCallback onTap;
  final bool isSelected;
  final String title;
  final String period;
  final double planPrice;

  const SubscriptionPlanButton({
    Key? key,
    required this.onTap,
    required this.isSelected,
    required this.title,
    required this.planPrice,
    required this.period,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: AppBorderRadius.borderRadiusAll8,
        side: BorderSide(
          width: isSelected ? 1.5 : 0.5,
          color: isSelected ? AppColors.darkLight : AppColors.greyLight,
        ),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: AppBorderRadius.borderRadiusAll8,
        child: Ink(
          padding: AppInsets.verticalInsets16,
          decoration: BoxDecoration(
            borderRadius: AppBorderRadius.borderRadiusAll8,
            color: Colors.white,
            border: Border.all(
              width: isSelected ? 1.5 : 0.5,
              color: isSelected ? AppColors.darkLight : AppColors.greyLight,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(title, style: TypographyNeueHaasUnicaW1G.basic3),
              Text('$planPrice \$ / $period', style: TypographyNeueHaasUnicaW1G.basic3),
            ],
          ),
        ),
      ),
    );
  }
}
