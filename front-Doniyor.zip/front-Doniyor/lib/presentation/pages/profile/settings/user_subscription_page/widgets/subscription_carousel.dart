import 'package:carousel_slider/carousel_controller.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:test_project/presentation/pages/profile/settings/user_subscription_page/widgets/subscription_carousel_dot_indicator.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';

class SubscriptionCarousel extends StatefulWidget {
  final List<Widget> items;
  final ValueChanged<int> onIndexChanged;
  final double height;

  const SubscriptionCarousel({
    Key? key,
    required this.items,
    required this.height,
    required this.onIndexChanged,
  }) : super(key: key);

  @override
  State<SubscriptionCarousel> createState() => _SubscriptionCarouselState();
}

class _SubscriptionCarouselState extends State<SubscriptionCarousel> {
  CarouselController controller = CarouselController();
  int chosenCarouselPageIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          height: widget.height,
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
            borderRadius: AppBorderRadius.borderRadiusAll8,
            border: Border.all(color: AppColors.oliveColor, width: 0.5),
          ),
          child: CarouselSlider(
            carouselController: controller,
            items: widget.items,
            options: CarouselOptions(
              viewportFraction: 1.0,
              onPageChanged: (index, reason) {
                if (reason == CarouselPageChangedReason.manual) setState(() => chosenCarouselPageIndex = index);
                widget.onIndexChanged(index);
              },
            ),
          ),
        ),
        AppSpacing.verticalSpace12,
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (int i = 0; i < widget.items.length; i++)
              CarouselSliderDotIndicator(
                onTap: () {
                  controller.animateToPage(i);
                  setState(() => chosenCarouselPageIndex = i);
                  widget.onIndexChanged(i);
                },
                isSelected: i == chosenCarouselPageIndex,
              ),
          ],
        ),
      ],
    );
  }
}
