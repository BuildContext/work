import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class LoginToBuySubscriptionSheet extends StatelessWidget {
  const LoginToBuySubscriptionSheet({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'The apps will help you develop new habits and track your progress.',
          style: TypographyNeueHaasUnicaW1G.basic2,
        ),
        AppSpacing.verticalSpace30,
        AppSpacing.verticalSpace30,
        CustomButton(
          onTap: () => Navigator.pop(context),
          text: 'login'.tr(),
        ),
        AppSpacing.verticalSpace16,
        CustomButton(
          onTap: () => Navigator.pop(context),
          color: Colors.white,
          text: 'skip'.tr(),
          showBorder: false,
          textStyle: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
        ),
      ],
    );
  }
}
