import 'package:bloc/bloc.dart';
import 'package:test_project/core/models/user_subscription_data.dart';
import 'package:test_project/presentation/pages/profile/settings/user_subscription_page/bloc/user_subscription_page_state.dart';

class UserSubscriptionPageCubit extends Cubit<UserSubscriptionPageState> {
  UserSubscriptionPageCubit() : super(UserSubscriptionInitial()) {
    loadUserSubscription();
  }

  Future<void> loadUserSubscription() async {
    emit(UserSubscriptionLoading());
    await Future.delayed(Duration(seconds: 2));
    emit(
      UserSubscriptionSuccess(
        subscriptionData: UserSubscriptionData(
          serviceName: 'Google Play',
          price: 50,
          nextPaymentDate: DateTime.now().add(Duration(days: 30)),
          lastPaidDate: DateTime.now().subtract(Duration(days: 15)),
        ),
      ),
    );
  }
}
