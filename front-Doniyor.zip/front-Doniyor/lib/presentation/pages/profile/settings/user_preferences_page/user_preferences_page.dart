import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/custom_widgets/user_preference_tile.dart';
import 'package:test_project/presentation/pages/profile/settings/user_preferences_page/bloc/user_preferences_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/user_preferences_page/bloc/user_preferences_page_state.dart';
import 'package:test_project/presentation/pages/profile/settings/user_preferences_page/widgets/rounded_add_button.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';

class UserPreferencesPage extends StatelessWidget {
  const UserPreferencesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<UserPreferencesPageCubit>();
    return Scaffold(
      appBar: AppBar(
        title: Text('my_preferences'.tr(), style: TypographyTwCenW01Medium.title2),
      ),
      body: BlocConsumer<UserPreferencesPageCubit, UserPreferencesPageState>(
        bloc: cubit,
        listener: (context, state) {},
        builder: (context, state) {
          if (state is UserPreferencesPageLoading) return Loader();
          if (state is UserPreferencesPageSuccess)
            return SingleChildScrollView(
              padding: AppInsets.horizontalInsets28,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisSize: MainAxisSize.max,
                children: [
                  AppSpacing.verticalSpace24,
                  Divider(),
                  AppSpacing.verticalSpace16,
                  Text(
                    'description'.tr().toUpperCase(),
                    style: TypographyTwCenW01Medium.subtitle2,
                  ),
                  AppSpacing.verticalSpace30,
                  Text(
                    'Товарищи! начало повседневной работы по формированию позиции требуют от нас анализа системы обучения кадров, соответствует насущным потребностям.',
                    style: TypographyNeueHaasUnicaW1G.basic2,
                  ),
                  AppSpacing.verticalSpace30,
                  Divider(),
                  AppSpacing.verticalSpace16,
                  Text(
                    'more'.tr().toUpperCase(),
                    style: TypographyTwCenW01Medium.subtitle2,
                  ),
                  AppSpacing.verticalSpace30,
                  Divider(),
                  AppSpacing.verticalSpace16,
                  Text(
                    'filter'.tr().toUpperCase(),
                    style: TypographyTwCenW01Medium.subtitle2,
                  ),
                  AppSpacing.verticalSpace24,
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: state.userPreferences
                        .map<Widget>((element) => FilterPreferenceChip(
                              preference: element,
                              onPreferenceDeleted: (preference) {},
                            ))
                        .toList()
                      ..add(RoundedAddButton(onTap: () {})),
                  ),
                  AppSpacing.verticalSpace30,
                  Divider(),
                  AppSpacing.verticalSpace16,
                  Text(
                    'filter'.tr().toUpperCase(),
                    style: TypographyTwCenW01Medium.subtitle2,
                  ),
                  AppSpacing.verticalSpace24,
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: state.userPreferences
                        .map<Widget>((element) => FilterPreferenceChip(
                              preference: element,
                              onPreferenceDeleted: (preference) {},
                            ))
                        .toList()
                      ..add(RoundedAddButton(onTap: () {})),
                  ),
                  AppSpacing.verticalSpace30,
                  Divider(),
                  AppSpacing.verticalSpace16,
                  Text(
                    'filter'.tr().toUpperCase(),
                    style: TypographyTwCenW01Medium.subtitle2,
                  ),
                  AppSpacing.verticalSpace24,
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: state.userPreferences
                        .map<Widget>((element) => FilterPreferenceChip(
                              preference: element,
                              onPreferenceDeleted: (preference) {},
                            ))
                        .toList()
                      ..add(RoundedAddButton(onTap: () {})),
                  ),
                  AppSpacing.verticalSpace16,
                ],
              ),
            );
          return Container();
        },
      ),
    );
  }
}
