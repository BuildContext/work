import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_theme.dart';

class RoundedAddButton extends StatelessWidget {
  final VoidCallback onTap;

  const RoundedAddButton({Key? key, required this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Ink(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: AppColors.greyLight, width: 0.5),
          ),
          child: Center(
            child: Icon(
              Icons.add,
              color: AppColors.dark,
            ),
          ),
        ),
      ),
    );
  }
}
