import 'package:test_project/core/models/user_preference_model.dart';

abstract class UserPreferencesPageState {}

class UserPreferencesPageInitial extends UserPreferencesPageState {}

class UserPreferencesPageLoading extends UserPreferencesPageState {}

class UserPreferencesPageSuccess extends UserPreferencesPageState {
  final List<UserPreference> userPreferences;

  UserPreferencesPageSuccess({required this.userPreferences});
}

class UserPreferencesPageError extends UserPreferencesPageState {
  final String error;

  UserPreferencesPageError({required this.error});
}
