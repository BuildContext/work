import 'package:bloc/bloc.dart';
import 'package:test_project/core/models/user_preference_model.dart';
import 'package:test_project/presentation/pages/profile/settings/user_preferences_page/bloc/user_preferences_page_state.dart';

class UserPreferencesPageCubit extends Cubit<UserPreferencesPageState> {
  UserPreferencesPageCubit() : super(UserPreferencesPageInitial()) {
    loadPreferences();
  }

  Future<void> loadPreferences() async {
    emit(UserPreferencesPageLoading());
    await Future.delayed(Duration(seconds: 2));
    emit(
      UserPreferencesPageSuccess(
        userPreferences: List.generate(
          3,
          (index) => UserPreference(title: index == 1 ? 'Something $index $index' : 'Some', iconPath: 'assets/svgs/cloud.svg'),
        ),
      ),
    );
  }
}
