import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/custom_widgets/switchable_tile.dart';
import 'package:test_project/presentation/pages/profile/settings/user_access_permissions/bloc/user_access_permissions_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/user_access_permissions/bloc/user_access_permissions_page_state.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/typography.dart';

class UserAccessPermissionsPage extends StatelessWidget {
  const UserAccessPermissionsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<UserAccessPermissionsPageCubit>();
    return Scaffold(
      appBar: AppBar(
        title: Text('access_permissions'.tr(), style: TypographyTwCenW01Medium.title2),
      ),
      body: BlocConsumer<UserAccessPermissionsPageCubit, UserAccessPermissionsPageState>(
        bloc: cubit,
        listener: (context, state) {},
        builder: (context, state) {
          if (state is UserAccessPermissionsLoading) return Loader();
          if (state is UserAccessPermissionsSuccess)
            return ListView.separated(
              padding: AppInsets.horizontalInsets28.copyWith(top: 24),
              itemBuilder: (context, index) {
                final access = state.userAccesses.elementAt(index);
                return SwitchableTile(title: access.title, isEnabled: access.isEnabled);
              },
              separatorBuilder: (context, index) => Divider(thickness: 0.5),
              itemCount: state.userAccesses.length,
            );
          return Container();
        },
      ),
    );
  }
}
