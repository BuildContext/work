import 'package:bloc/bloc.dart';
import 'package:test_project/core/models/user_accesses_type.dart';
import 'package:test_project/presentation/pages/profile/settings/user_access_permissions/bloc/user_access_permissions_page_state.dart';

class UserAccessPermissionsPageCubit extends Cubit<UserAccessPermissionsPageState> {
  UserAccessPermissionsPageCubit() : super(UserAccessPermissionsInitial()) {
    loadAccessPermissionsData();
  }

  Future<void> loadAccessPermissionsData() async {
    emit(UserAccessPermissionsLoading());
    await Future.delayed(Duration(seconds: 2));
    emit(
      UserAccessPermissionsSuccess(
        userAccesses: [
          UserAccessType(title: 'GEO', isEnabled: true),
          UserAccessType(title: 'Calendar', isEnabled: true),
          UserAccessType(title: 'Camera', isEnabled: true),
        ],
      ),
    );
  }
}
