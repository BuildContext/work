import 'package:test_project/core/models/user_accesses_type.dart';

abstract class UserAccessPermissionsPageState {}

class UserAccessPermissionsInitial extends UserAccessPermissionsPageState {}

class UserAccessPermissionsLoading extends UserAccessPermissionsPageState {}

class UserAccessPermissionsSuccess extends UserAccessPermissionsPageState {
  final List<UserAccessType> userAccesses;

  UserAccessPermissionsSuccess({required this.userAccesses});
}

class UserAccessPermissionsError extends UserAccessPermissionsPageState {
  final String error;

  UserAccessPermissionsError({required this.error});
}
