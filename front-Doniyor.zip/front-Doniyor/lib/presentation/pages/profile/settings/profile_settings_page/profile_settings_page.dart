import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/custom_widgets/custom_text_field.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/pages/profile/settings/profile_settings_page/bloc/profile_page_settings_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/profile_settings_page/bloc/profile_settings_state.dart';
import 'package:test_project/presentation/pages/profile/settings/widgets/social_linked_profile_checkbox.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';

class ProfileSettingsPage extends StatelessWidget {
  const ProfileSettingsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ProfileSettingsPageCubit>();
    return Scaffold(
      appBar: AppBar(
        title: Text('profile'.tr(), style: TypographyTwCenW01Medium.title2),
      ),
      body: BlocConsumer<ProfileSettingsPageCubit, ProfileSettingsPageState>(
        bloc: cubit,
        listener: (context, state) {},
        builder: (context, state) {
          if (state is ProfileSettingsPageLoading)
            return Loader();
          else
            return SafeArea(
              minimum: AppInsets.horizontalInsets28,
              child: ListView(
                children: [
                  Divider(),
                  CustomTextField(
                    controller: cubit.nameController,
                    helperText: 'name'.tr(),
                    hintText: 'name'.tr(),
                  ),
                  AppSpacing.verticalSpace30,
                  CustomTextField(
                    controller: cubit.surnameController,
                    helperText: 'surname'.tr(),
                    hintText: 'surname'.tr(),
                  ),
                  AppSpacing.verticalSpace30,
                  CustomTextField(
                    controller: cubit.phoneController,
                    helperText: 'phone'.tr(),
                    hintText: 'phone'.tr(),
                  ),
                  AppSpacing.verticalSpace30,
                  CustomTextField(
                    controller: cubit.emailController,
                    helperText: 'email'.tr(),
                    hintText: 'email'.tr(),
                  ),
                  AppSpacing.verticalSpace30,
                  CustomTextField(
                    controller: cubit.ageController,
                    helperText: 'age'.tr(),
                    hintText: 'age'.tr(),
                  ),
                  AppSpacing.verticalSpace30,
                  CustomTextField(
                    controller: cubit.genderController,
                    helperText: 'gender'.tr(),
                    hintText: 'gender'.tr(),
                  ),
                  AppSpacing.verticalSpace30,
                  CustomTextField(
                    controller: cubit.nationalityController,
                    helperText: 'nationality'.tr(),
                    hintText: 'nationality'.tr(),
                  ),
                  AppSpacing.verticalSpace30,
                  CustomTextField(
                    controller: cubit.countryController,
                    helperText: 'country'.tr(),
                    hintText: 'country'.tr(),
                  ),
                  AppSpacing.verticalSpace30,
                  CustomTextField(
                    controller: cubit.heightController,
                    helperText: 'height'.tr(),
                    hintText: 'height'.tr(),
                  ),
                  AppSpacing.verticalSpace30,
                  CustomTextField(
                    controller: cubit.weightController,
                    helperText: 'weight'.tr(),
                    hintText: 'weight'.tr(),
                  ),
                  AppSpacing.verticalSpace30,
                  CustomTextField(
                    controller: cubit.dateOFBirthController,
                    helperText: 'birthday'.tr(),
                    hintText: 'birthday'.tr(),
                  ),
                  AppSpacing.verticalSpace30,
                  Divider(),
                  AppSpacing.verticalSpace20,
                  SocialLinkedCheckbox(title: 'Google aisha-arenas@gmail.com'),
                  AppSpacing.verticalSpace24,
                  Divider(),
                  AppSpacing.verticalSpace20,
                  SocialLinkedCheckbox(title: 'Facebook @aisha.arenas'),
                  AppSpacing.verticalSpace24,
                  Divider(),
                  AppSpacing.verticalSpace20,
                  SocialLinkedCheckbox(title: 'Instagram Add'),
                  AppSpacing.verticalSpace24,
                  Divider(),
                  AppSpacing.verticalSpace20,
                  AppSpacing.verticalSpace20,
                  CustomButton(onTap: () {}, text: 'save'.tr()),
                ],
              ),
            );
        },
      ),
    );
  }
}
