import 'package:test_project/core/models/user_profile_data.dart';

abstract class ProfileSettingsPageState {}

class ProfileSettingsPageInitial extends ProfileSettingsPageState {}

class ProfileSettingsPageLoading extends ProfileSettingsPageState {}

class ProfileSettingsPageSuccess extends ProfileSettingsPageState {
  final UserProfileData profileData;

  ProfileSettingsPageSuccess({required this.profileData});
}

class ProfileSettingsPageError extends ProfileSettingsPageState {
  final String error;

  ProfileSettingsPageError({required this.error});
}
