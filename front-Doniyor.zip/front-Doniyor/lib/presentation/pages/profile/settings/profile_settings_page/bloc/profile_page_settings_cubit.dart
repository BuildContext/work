import 'package:bloc/bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/core/models/user_profile_data.dart';
import 'package:test_project/domain/services/profile_service.dart';
import 'package:test_project/presentation/pages/profile/settings/profile_settings_page/bloc/profile_settings_state.dart';

class ProfileSettingsPageCubit extends Cubit<ProfileSettingsPageState> {
  ProfileSettingsPageCubit() : super(ProfileSettingsPageInitial()) {
    loadUserProfileData();
  }
  TextEditingController nameController = TextEditingController();
  TextEditingController surnameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController ageController = TextEditingController();
  TextEditingController genderController = TextEditingController();
  TextEditingController nationalityController = TextEditingController();
  TextEditingController countryController = TextEditingController();
  TextEditingController heightController = TextEditingController();
  TextEditingController weightController = TextEditingController();
  TextEditingController dateOFBirthController = TextEditingController();

  Future<void> loadUserProfileData() async {
    emit(ProfileSettingsPageLoading());
    final profile = await ProfileService.instance.loadProfileData();
    _assignValues(profile);
    emit(ProfileSettingsPageSuccess(profileData: profile));
  }

  void _assignValues(UserProfileData profileData) {
    nameController.text = profileData.name;
    surnameController.text = profileData.surname;
    phoneController.text = profileData.phone;
    emailController.text = profileData.email;
    ageController.text = profileData.age.toString();
    genderController.text = profileData.gender;
    nationalityController.text = profileData.nationality;
    countryController.text = profileData.country;
    heightController.text = profileData.height.toString();
    weightController.text = profileData.weight.toString();
    dateOFBirthController.text = DateFormat('dd.MM.yyyy').format(profileData.birthDay);
  }
}
