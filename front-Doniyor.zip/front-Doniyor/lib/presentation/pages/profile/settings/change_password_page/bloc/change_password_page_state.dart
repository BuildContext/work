abstract class ChangePasswordPageState {}

class ChangePasswordPageInitial extends ChangePasswordPageState {}

class ChangePasswordPageLoading extends ChangePasswordPageState {}

class ChangePasswordPageSuccess extends ChangePasswordPageState {
  final DateTime lastResetDate;

  ChangePasswordPageSuccess({required this.lastResetDate});
}

class ChangePasswordPageError extends ChangePasswordPageState {
  final String error;

  ChangePasswordPageError({required this.error});
}
