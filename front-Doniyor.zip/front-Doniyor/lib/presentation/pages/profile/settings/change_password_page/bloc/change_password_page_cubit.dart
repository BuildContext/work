import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:test_project/presentation/pages/profile/settings/change_password_page/bloc/change_password_page_state.dart';

class ChangePasswordPageCubit extends Cubit<ChangePasswordPageState> {
  ChangePasswordPageCubit() : super(ChangePasswordPageInitial()) {
    loadUserData();
  }

  TextEditingController currentPasswordController = TextEditingController();
  TextEditingController newPasswordController = TextEditingController();
  TextEditingController newPasswordConfirmationController = TextEditingController();

  Future<void> loadUserData() async {
    emit(ChangePasswordPageLoading());
    await Future.delayed(Duration(seconds: 2));
    emit(ChangePasswordPageSuccess(lastResetDate: DateTime.now().subtract(Duration(days: 365 ~/ 2))));
  }

  @override
  Future<void> close() {
    currentPasswordController.dispose();
    newPasswordController.dispose();
    newPasswordConfirmationController.dispose();
    return super.close();
  }
}
