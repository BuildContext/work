import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_project/presentation/custom_widgets/custom_text_field.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/pages/profile/settings/change_password_page/bloc/change_password_page_cubit.dart';
import 'package:test_project/presentation/pages/profile/settings/change_password_page/bloc/change_password_page_state.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class ChangePasswordPage extends StatelessWidget {
  const ChangePasswordPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<ChangePasswordPageCubit>();
    return Scaffold(
      appBar: AppBar(
        title: Text('password'.tr(), style: TypographyTwCenW01Medium.title2),
      ),
      body: BlocConsumer<ChangePasswordPageCubit, ChangePasswordPageState>(
        bloc: cubit,
        listener: (context, state) {},
        builder: (context, state) {
          if (state is ChangePasswordPageLoading) return Loader();
          if (state is ChangePasswordPageSuccess)
            return Padding(
              padding: AppInsets.horizontalInsets28,
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  AppSpacing.verticalSpace24,
                  Text(
                    'Your password must contain more than six characters, including numbers, letters and special characters (!\$@%*).',
                    style: TypographyNeueHaasUnicaW1G.basic2,
                  ),
                  AppSpacing.verticalSpace30,
                  CustomTextField(
                    controller: cubit.currentPasswordController,
                    helperText: 'CURRENT PASSWORD',
                    hintText: 'Enter current password',
                  ),
                  AppSpacing.verticalSpace30,
                  CustomTextField(
                    controller: cubit.newPasswordController,
                    helperText: 'CURRENT PASSWORD',
                    hintText: 'Enter current password',
                  ),
                  AppSpacing.verticalSpace30,
                  CustomTextField(
                    controller: cubit.newPasswordConfirmationController,
                    helperText: 'CURRENT PASSWORD',
                    hintText: 'Enter current password',
                  ),
                  AppSpacing.verticalSpace30,
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text:
                              'Updated on ${DateFormat('dd.MM.yyyy').format(state.lastResetDate)}. If you forgot your password, you can ',
                          style: TypographyNeueHaasUnicaW1G.basic2,
                        ),
                        TextSpan(
                          text: 'reset it.',
                          style: TypographyNeueHaasUnicaW1G.basic2.copyWith(color: AppColors.oliveDark),
                          recognizer: TapGestureRecognizer()..onTap = () {},
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          return Container();
        },
      ),
    );
  }
}
