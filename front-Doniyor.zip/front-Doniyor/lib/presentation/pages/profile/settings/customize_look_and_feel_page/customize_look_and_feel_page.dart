import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/presentation/pages/profile/settings/customize_look_and_feel_page/widgets/checkable_tile.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/typography.dart';

class CustomizeLookAndFeelPage extends StatelessWidget {
  const CustomizeLookAndFeelPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final list = ['Adaptive', 'Bright day', 'Calm night'];
    return Scaffold(
      appBar: AppBar(
        title: Text('customize_look_and_feel'.tr(), style: TypographyTwCenW01Medium.title2),
      ),
      body: ListView.separated(
        padding: AppInsets.horizontalInsets28.copyWith(top: 24),
        itemCount: 3,
        itemBuilder: (context, index) => CheckableTile(
          title: list.elementAt(index),
          isChecked: list.elementAt(index) == 'Bright day',
        ),
        separatorBuilder: (context, index) => Divider(thickness: 0.5),
      ),
    );
  }
}
