import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class CheckableTile extends StatefulWidget {
  final String title;
  final bool isChecked;

  const CheckableTile({
    Key? key,
    required this.title,
    required this.isChecked,
  }) : super(key: key);

  @override
  State<CheckableTile> createState() => _CheckableTileState();
}

class _CheckableTileState extends State<CheckableTile> {
  late bool _isChecked = widget.isChecked;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 64,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              widget.title,
              style: TypographyNeueHaasUnicaW1G.basic2,
            ),
          ),
          Checkbox(
            activeColor: AppColors.darkLight,
            checkColor: Colors.white,
            value: _isChecked,
            onChanged: (value) => setState(() => _isChecked = value ?? false),
          ),
        ],
      ),
    );
  }
}
