import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';

class AgreementPage extends StatelessWidget {
  const AgreementPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('agreement'.tr(), style: TypographyTwCenW01Medium.title2),
      ),
      body: ListView(
        padding: AppInsets.horizontalInsets28.copyWith(top: 40),
        children: [
          Text(
            'agreement'.tr().toUpperCase(),
            style: TypographyTwCenW01Medium.subtitle2,
          ),
          AppSpacing.verticalSpace24,
          Text(
            'The title is long two lines',
            style: TypographyTwCenW01Medium.title1,
          ),
          AppSpacing.verticalSpace16,
          Text(
            '10.10.2022',
            style: TypographyNeueHaasUnicaW1G.basic2,
          ),
          AppSpacing.verticalSpace20,
          AppSpacing.verticalSpace20,
          Text(
            '1',
            style: TypographyTwCenW01Medium.subtitle2,
          ),
          AppSpacing.verticalSpace16,
          Text(
            'The offer to pass a full quiz to determine your constitution and Vikrity.',
            style: TypographyNeueHaasUnicaW1G.basic2,
          ),
          AppSpacing.verticalSpace16,
          Text(
            'Comrades! the beginning of daily work on the formation of a position requires us to analyze the personnel training system, meets the urgent needs. Comrades! the beginning of daily work on the formation of a position requires us to analyze the personnel training system, meets the urgent needs.',
            style: TypographyNeueHaasUnicaW1G.basic3,
          ),
          AppSpacing.verticalSpace20,
          AppSpacing.verticalSpace20,
          Text(
            '1',
            style: TypographyTwCenW01Medium.subtitle2,
          ),
          AppSpacing.verticalSpace16,
          Text(
            'The offer to pass a full quiz to determine your constitution and Vikrity.',
            style: TypographyNeueHaasUnicaW1G.basic2,
          ),
          AppSpacing.verticalSpace16,
          Text(
            'Comrades! the beginning of daily work on the formation of a position requires us to analyze the personnel training system, meets the urgent needs. Comrades! the beginning of daily work on the formation of a position requires us to analyze the personnel training system, meets the urgent needs.',
            style: TypographyNeueHaasUnicaW1G.basic3,
          ),
          AppSpacing.verticalSpace20,
          AppSpacing.verticalSpace20,
          Text(
            '1',
            style: TypographyTwCenW01Medium.subtitle2,
          ),
          AppSpacing.verticalSpace16,
          Text(
            'The offer to pass a full quiz to determine your constitution and Vikrity.',
            style: TypographyNeueHaasUnicaW1G.basic2,
          ),
          AppSpacing.verticalSpace16,
          Text(
            'Comrades! the beginning of daily work on the formation of a position requires us to analyze the personnel training system, meets the urgent needs. Comrades! the beginning of daily work on the formation of a position requires us to analyze the personnel training system, meets the urgent needs.',
            style: TypographyNeueHaasUnicaW1G.basic3,
          ),
          AppSpacing.verticalSpace24,
          AppSpacing.verticalSpace10,
          CustomButton(
            onTap: () {},
            text: 'request'.tr(),
          ),
        ],
      ),
    );
  }
}
