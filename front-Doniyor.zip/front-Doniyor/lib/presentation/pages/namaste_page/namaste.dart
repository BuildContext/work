import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_project/domain/services/namaste_service.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/pages/auth/auth_wrapper/auth_wrapper_page.dart';
import 'package:test_project/presentation/pages/auth/login/auth_sheet/authorization_sheet.dart';
import 'package:test_project/presentation/pages/auth/login/auth_sheet/bloc/authorization_sheet_cubit.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class NamastePage extends StatefulWidget {
  const NamastePage({Key? key}) : super(key: key);

  @override
  State<NamastePage> createState() => _NamastePageState();
}

class _NamastePageState extends State<NamastePage> {
  QuoteModel quoteModel = QuoteModel.empty();
  CrossFadeState crossFadeState = CrossFadeState.showFirst;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      quoteModel = await NamasteService.instance.getQuoteFromHtmlDoc();
      setState(() => crossFadeState = CrossFadeState.showSecond);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedCrossFade(
        firstChild: Loader(),
        secondChild: Padding(
          padding: AppInsets.bodyPadding,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // SvgPicture.network(quoteModel.imageUrl),
              AppSpacing.verticalSpace12,
              Text(
                quoteModel.quote,
                style: TypographyTwCenW01Medium.title1,
              ),
              AppSpacing.verticalSpace8,
              Text(
                quoteModel.author,
                style: TypographyNeueHaasUnicaW1G.basic1.copyWith(fontWeight: FontWeight.w500),
                textAlign: TextAlign.end,
              ),
              AppSpacing.verticalSpace24,
              AppSpacing.verticalSpace24,
              CustomButton(
                onTap: () {
                  Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (context) => MultiBlocProvider(
                        providers: [
                          BlocProvider(create: (context) => AuthorizationSheetCubit(), child: AuthorizationSheet()),
                        ],
                        child: AuthWrapperPage(),
                      ),
                    ),
                    (route) => false,
                  );
                },
                text: 'Skip',
                color: AppColors.oliveColor,
              ),
            ],
          ),
        ),
        crossFadeState: crossFadeState,
        duration: Duration(milliseconds: 250),
      ),
    );
  }
}
