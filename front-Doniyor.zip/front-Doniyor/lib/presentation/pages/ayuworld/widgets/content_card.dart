import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';

class ContentCard extends StatelessWidget {
  final VoidCallback onTap;
  final String title;
  final String imageLink;
  final String placeholderPath;
  final List<ContentCategoryIcon> icons;

  const ContentCard({
    Key? key,
    required this.onTap,
    required this.title,
    required this.imageLink,
    required this.placeholderPath,
    required this.icons,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      color: Colors.white,
      child: Container(
        width: 152,
        margin: AppInsets.onlyRightInset16,
        child: InkWell(
          onTap: onTap,
          child: Stack(
            fit: StackFit.passthrough,
            children: [
              Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  CachedNetworkImage(
                    imageUrl: imageLink,
                    errorWidget: (context, url, trace) => Image.asset(placeholderPath),
                    progressIndicatorBuilder: (context, url, progress) => SizedBox(height: 152, child: Loader()),
                    imageBuilder: (context, imageProvider) => Container(
                      height: 152,
                      decoration: BoxDecoration(borderRadius: AppBorderRadius.borderRadiusAll6),
                      child: Image(image: imageProvider),
                    ),
                  ),
                  AppSpacing.verticalSpace12,
                  Text(title, style: TypographyTwCenW01Medium.subtitle1),
                  AppSpacing.verticalSpace14,
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: icons
                        .map<Widget>(
                          (category) => Padding(
                            padding: AppInsets.onlyRightInset8,
                            child: category.isLocal
                                ? SvgPicture.asset('assets/svgs/${category.iconPath}.svg')
                                : SvgPicture.network(category.iconPath),
                          ),
                        )
                        .toList(),
                  ),
                ],
              ),
              Padding(
                padding: AppInsets.insetsAll16,
                child: Align(alignment: Alignment.topRight, child: Icon(Icons.favorite_border)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
