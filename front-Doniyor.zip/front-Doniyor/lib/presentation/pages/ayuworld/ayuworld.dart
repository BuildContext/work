import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/presentation/custom_widgets/custom_drop_down_button.dart';
import 'package:test_project/presentation/custom_widgets/filter_sheet.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/custom_widgets/search_sheet.dart';
import 'package:test_project/presentation/pages/ayuworld/tabs/ayurveda.dart';
import 'package:test_project/presentation/pages/ayuworld/tabs/yoga.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

import 'cubit/knowledge_page_cubit.dart';
import 'cubit/knowledge_page_state.dart';

class AyuWorldPage extends StatefulWidget {
  const AyuWorldPage({Key? key}) : super(key: key);

  @override
  _AyuWorldPageState createState() => _AyuWorldPageState();
}

class _AyuWorldPageState extends State<AyuWorldPage> with SingleTickerProviderStateMixin {
  final cubit = AyuworldPageCubit();

  late TabController tabController = TabController(length: 2, vsync: this);

  // - World of Ayurveda
  // *Видосы
//  *Статьи

//   - Workd of Yoga
//   *Видосы
//  *Статьи

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await cubit.loadData();
    });
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ayuworld'),
        actions: [
          IconButton(
            onPressed: () => AppInteractionsHelper.showBottomSheet(
              context: context,
              child: FilterSheet(),
              title: 'filter'.tr(),
              hasBlurBarrier: true,
            ),
            icon: SvgPicture.asset('assets/svgs/filter.svg'),
          ),
          IconButton(
            onPressed: () => AppInteractionsHelper.showBottomSheet(
              context: context,
              child: SearchSheet(),
              hasBlurBarrier: true,
              title: 'search'.tr(),
            ),
            icon: SvgPicture.asset('assets/svgs/search.svg'),
          ),
        ],
      ),
      body: Padding(
        padding: AppInsets.bodyPadding,
        child: BlocConsumer<AyuworldPageCubit, AyuworldPageState>(
          bloc: cubit,
          listener: (context, state) {},
          builder: (context, state) {
            if (state is AyuworldLoading) {
              return Loader();
            } else if (state is AyuworldSuccess) {
              return Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text('What\'s bothering you?', style: TypographyTwCenW01Medium.title3),
                  AppSpacing.verticalSpace24,
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    padding: AppInsets.horizontalInsets12,
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        CustomDropDownButton<String>(
                          onChanged: (value) {},
                          backgroundColor: AppColors.oliveLight,
                          items: [
                            CustomDropDownOption<String>(title: 'All', value: 'value'),
                            CustomDropDownOption<String>(title: 'des', value: 'des'),
                            CustomDropDownOption<String>(title: 'asd', value: 'asd'),
                            CustomDropDownOption<String>(title: 'dsa', value: 'dsa'),
                          ],
                        ),
                        AppSpacing.horizontalSpace20,
                        CustomDropDownButton<String>(
                          onChanged: (value) {},
                          items: [
                            CustomDropDownOption<String>(title: 'Popular', value: 'popular'),
                            CustomDropDownOption<String>(title: 'des', value: 'des'),
                            CustomDropDownOption<String>(title: 'asd', value: 'asd'),
                            CustomDropDownOption<String>(title: 'dsa', value: 'dsa'),
                          ],
                        ),
                        AppSpacing.horizontalSpace20,
                        CustomDropDownButton<String>(
                          onChanged: (value) {},
                          items: [
                            CustomDropDownOption<String>(title: 'Make in 10 minutes', value: 'popular'),
                            CustomDropDownOption<String>(title: 'des', value: 'des'),
                            CustomDropDownOption<String>(title: 'asd', value: 'asd'),
                            CustomDropDownOption<String>(title: 'dsa', value: 'dsa'),
                          ],
                        ),
                      ],
                    ),
                  ),
                  AppSpacing.verticalSpace24,
                  Divider(thickness: 0.5),
                  SizedBox(
                    height: 24,
                    child: TabBar(
                      padding: AppInsets.horizontalInsets28,
                      controller: tabController,
                      indicatorColor: AppColors.darkLight,
                      labelStyle: TypographyTwCenW01Medium.caption2,
                      unselectedLabelStyle: TypographyTwCenW01Medium.caption2.copyWith(color: AppColors.greyLight),
                      labelColor: AppColors.dark,
                      unselectedLabelColor: AppColors.darkLight.withOpacity(0.5),
                      labelPadding: AppInsets.insetsOnlyBottom8,
                      indicatorPadding: EdgeInsets.zero,
                      indicatorWeight: 1.5,
                      tabs: [
                        Tab(text: 'World of Ayurveda'.toUpperCase(), iconMargin: EdgeInsets.zero),
                        Tab(text: 'World of Yoga'.toUpperCase(), iconMargin: EdgeInsets.zero),
                      ],
                    ),
                  ),
                  AppSpacing.verticalSpace16,
                  Expanded(
                    child: TabBarView(
                      controller: tabController,
                      children: [
                        AyurvedaTab(
                          ayurvedaNews: state.ayurvedaNews,
                          ayurvedaRecs: state.ayurvedaRecs,
                          quiz: state.quiz,
                          onRefresh: () => cubit.loadData(),
                        ),
                        YogaTab(
                          yogaNews: state.yogaNews,
                          yogaRecs: state.yogaRecs,
                          quiz: state.quiz,
                          onRefresh: () => cubit.loadData(),
                        ),
                      ],
                    ),
                  ),
                ],
              );
            } else {
              return Container();
            }
          },
        ),
      ),
    );
  }
}
