import 'package:test_project/core/models/news_model.dart';
import 'package:test_project/core/models/quiz.dart';

abstract class AyuworldPageState {}

class AyuworldInitial extends AyuworldPageState {}

class AyuworldLoading extends AyuworldPageState {}

class AyuworldSuccess extends AyuworldPageState {
  final List<NewsResult> ayurvedaNews;
  final List<NewsResult> ayurvedaRecs;
  final List<NewsResult> yogaNews;
  final List<NewsResult> yogaRecs;
  final Quiz quiz;

  AyuworldSuccess({
    required this.ayurvedaRecs,
    required this.ayurvedaNews,
    required this.yogaNews,
    required this.yogaRecs,
    required this.quiz,
  });
}

class AyuworldPageError extends AyuworldPageState {
  final String error;

  AyuworldPageError({required this.error});
}
