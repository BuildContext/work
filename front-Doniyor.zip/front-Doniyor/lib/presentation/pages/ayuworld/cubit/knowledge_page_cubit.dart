import 'package:bloc/bloc.dart';
import 'package:test_project/domain/services/ayuworld_service.dart';

import 'knowledge_page_state.dart';

class AyuworldPageCubit extends Cubit<AyuworldPageState> {
  AyuworldPageCubit() : super(AyuworldInitial());

  Future<void> loadData() async {
    emit(AyuworldLoading());

    final news = await AyuworldService.instance.loadNews(page: 1, size: 5);
    final quiz = await AyuworldService.instance.loadQuiz();
    news.fold(
      (l) => emit(AyuworldPageError(error: l.error)),
      (r) => emit(AyuworldSuccess(
        ayurvedaNews: r.results?.where((element) => !(element.isRecommended ?? true) && element.category != 'yoga').toList() ?? [],
        ayurvedaRecs: r.results?.where((element) => (element.isRecommended ?? false) && element.category != 'yoga').toList() ?? [],
        quiz: quiz,
        yogaNews: r.results?.where((element) => !(element.isRecommended ?? true) && element.category == 'yoga').toList() ?? [],
        yogaRecs: r.results?.where((element) => (element.isRecommended ?? false) && element.category == 'yoga').toList() ?? [],
      )),
    );
  }
}
