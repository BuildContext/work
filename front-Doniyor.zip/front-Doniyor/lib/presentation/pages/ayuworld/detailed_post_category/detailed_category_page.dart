import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/post.dart';
import 'package:test_project/core/models/recipe_category_item.dart';
import 'package:test_project/presentation/custom_widgets/filter_sheet.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/custom_widgets/search_sheet.dart';
import 'package:test_project/presentation/custom_widgets/vertical_small_content_card.dart';
import 'package:test_project/presentation/pages/ayumeal/recipe/detailed_recipe/detailed_recipe_page.dart';
import 'package:test_project/presentation/pages/ayuworld/detailed_post/detailed_post_page.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';
import 'package:test_project/tools/extentions/string_extensions.dart';

import 'cubit/detailed_category_page_cubit.dart';
import 'cubit/detailed_category_page_state.dart';

class DetailedCategoryPage extends StatefulWidget {
  final String categoryId;

  const DetailedCategoryPage({
    Key? key,
    required this.categoryId,
  }) : super(key: key);

  @override
  _DetailedCategoryPageState createState() => _DetailedCategoryPageState();
}

class _DetailedCategoryPageState extends State<DetailedCategoryPage> {
  final cubit = DetailedPostCategoryPageCubit();
  final List<ContentCategoryItem> _allContent = List.empty(growable: true);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      final list = await cubit.loadData(widget.categoryId);
      for (final category in list) {
        _allContent.addAll(category.items);
        _allContent.addAll(category.items);
      }
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.categoryId.capitalize, style: TypographyTwCenW01Medium.title2),
        actions: [
          IconButton(
            onPressed: () => AppInteractionsHelper.showBottomSheet(
              context: context,
              child: FilterSheet(),
              hasBlurBarrier: true,
              title: 'filter'.tr(),
            ),
            icon: SvgPicture.asset('assets/svgs/filter.svg'),
          ),
          IconButton(
            onPressed: () => AppInteractionsHelper.showBottomSheet(
              context: context,
              child: SearchSheet(),
              hasBlurBarrier: true,
              title: 'search'.tr(),
            ),
            icon: SvgPicture.asset('assets/svgs/search.svg'),
          ),
        ],
      ),
      body: BlocConsumer<DetailedPostCategoryPageCubit, DetailedCategoryPageState>(
        bloc: cubit,
        listener: (context, state) {},
        builder: (context, state) {
          if (state is DetailedCategoryLoading) return Loader();
          if (state is DetailedCategorySuccess)
            return GridView.builder(
              padding: AppInsets.horizontalInsets28.copyWith(top: 24),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 152 / 228,
              ),
              itemBuilder: (context, index) => VerticalSmallContentCard(
                placeholderPath: 'assets/pngs/recipe_small_placeholder.png',
                post: _allContent.elementAt(index),
                onLikePressed: () {},
                onTap: () {
                  if (_allContent.elementAt(index) is PostCategoryItem)
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DetailedPostPage(postId: _allContent.elementAt(index).id.toString()),
                      ),
                    );
                  if (_allContent.elementAt(index) is RecipeCategoryItem)
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DetailedRecipePage(item: _allContent.elementAt(index) as RecipeCategoryItem),
                      ),
                    );
                },
              ),
              itemCount: _allContent.length,
            );
          return Container();
        },
      ),
    );
  }
}
