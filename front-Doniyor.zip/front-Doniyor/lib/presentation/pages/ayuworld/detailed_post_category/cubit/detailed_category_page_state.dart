import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/quiz.dart';

abstract class DetailedCategoryPageState {}

class DetailedCategoryInitial extends DetailedCategoryPageState {}

class DetailedCategoryLoading extends DetailedCategoryPageState {}

class DetailedCategorySuccess extends DetailedCategoryPageState {
  final List<ContentCategory> posts;
  final Quiz quiz;

  DetailedCategorySuccess({
    required this.posts,
    required this.quiz,
  });
}

class DetailedCategoryError extends DetailedCategoryPageState {
  final String error;

  DetailedCategoryError({required this.error});
}
