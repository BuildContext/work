import 'package:bloc/bloc.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/domain/services/ayuworld_service.dart';

import 'detailed_category_page_state.dart';

class DetailedPostCategoryPageCubit extends Cubit<DetailedCategoryPageState> {
  DetailedPostCategoryPageCubit() : super(DetailedCategoryInitial());

  Future<List<ContentCategory>> loadData(String id) async {
    emit(DetailedCategoryLoading());
    await Future.delayed(Duration(seconds: 1), () {});

    final posts = await AyuworldService.instance.loadNews(page: 1, size: 5);
    final quiz = await AyuworldService.instance.loadQuiz();

    emit(DetailedCategorySuccess(posts: [], quiz: quiz));
    return [];
    // return posts;
  }
}
