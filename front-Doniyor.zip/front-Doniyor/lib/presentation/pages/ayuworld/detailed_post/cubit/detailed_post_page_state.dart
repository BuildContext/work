import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/news_model.dart';
import 'package:test_project/core/models/post.dart';
import 'package:test_project/core/models/youtube_video_details.dart';

abstract class DetailedPostPageState {}

class DetailedPostInitial extends DetailedPostPageState {}

class DetailedPostLoading extends DetailedPostPageState {}

class DetailedPostSuccess extends DetailedPostPageState {
  final List<RecommendedReading> readings;
  final ContentCategory elseSection;
  final NewsResult news;
  final YoutubeVideoDetails? videoDetails;

  DetailedPostSuccess({
    required this.news,
    required this.readings,
    required this.elseSection,
    this.videoDetails,
  });
}

class DetailedPostError extends DetailedPostPageState {
  final String error;

  DetailedPostError({required this.error});
}
