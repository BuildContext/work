import 'package:bloc/bloc.dart';
import 'package:test_project/core/models/news_model.dart';
import 'package:test_project/domain/services/ayuworld_service.dart';
import 'package:test_project/domain/services/youtube_service.dart';

import 'detailed_post_page_state.dart';

class DetailedPostPageCubit extends Cubit<DetailedPostPageState> {
  DetailedPostPageCubit() : super(DetailedPostInitial());

  Future<void> loadData(String postId) async {
    emit(DetailedPostLoading());

    final elseSection = await AyuworldService.instance.loadPostRelatedContent();
    final readings = await AyuworldService.instance.loadReadings();
    final postDetails = await AyuworldService.instance.loadNewsById(id: postId);
    NewsResult newsResult = NewsResult();
    postDetails.fold((l) => emit(DetailedPostError(error: l.error)), (r) {
      newsResult = r;
    });
    if (newsResult.youtubeLink == null || (newsResult.youtubeLink?.isEmpty ?? false)) {
      emit(DetailedPostSuccess(
        news: newsResult,
        readings: readings,
        elseSection: elseSection,
      ));
    } else {
      final youtubeVideoData = await YoutubeService.instance.getVideoDetails(newsResult.youtubeLink ?? '');
      youtubeVideoData.fold(
        (l) => emit(DetailedPostError(error: l.error)),
        (r) => emit(DetailedPostSuccess(
          news: newsResult,
          readings: readings,
          elseSection: elseSection,
          videoDetails: r,
        )),
      );
    }
  }
}
