import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/presentation/custom_widgets/content_section.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/custom_widgets/recommended_reading_tile.dart';
import 'package:test_project/presentation/custom_widgets/tag_tile.dart';
import 'package:test_project/presentation/custom_widgets/vertical_small_content_card.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import 'cubit/detailed_post_page_cubit.dart';
import 'cubit/detailed_post_page_state.dart';

class DetailedPostPage extends StatefulWidget {
  final String postId;

  const DetailedPostPage({Key? key, required this.postId}) : super(key: key);

  @override
  _DetailedPostPageState createState() => _DetailedPostPageState();
}

class _DetailedPostPageState extends State<DetailedPostPage> {
  final cubit = DetailedPostPageCubit();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await cubit.loadData(widget.postId);
    });
  }

  @override
  Widget build(BuildContext context) {
    double imageHeight = 484;
    return Scaffold(
      body: BlocConsumer<DetailedPostPageCubit, DetailedPostPageState>(
        bloc: cubit,
        listener: (context, state) {},
        builder: (context, state) {
          if (state is DetailedPostLoading) return Loader();
          if (state is DetailedPostSuccess)
            return ListView(
              children: [
                Stack(
                  fit: StackFit.passthrough,
                  children: [
                    CachedNetworkImage(
                      imageUrl: state.news.imageUrl ?? '',
                      errorWidget: (context, url, trace) => Image.asset('assets/pngs/post_detail_placeholder.png', fit: BoxFit.cover),
                      progressIndicatorBuilder: (context, url, progress) => SizedBox(height: imageHeight, child: Loader()),
                      imageBuilder: (context, imageProvider) => Container(
                        height: imageHeight,
                        decoration: BoxDecoration(borderRadius: AppBorderRadius.borderRadiusAll6),
                        child: Image(image: imageProvider),
                      ),
                    ),
                    Positioned(
                      bottom: 0,
                      child: Container(
                        height: imageHeight,
                        width: MediaQuery.of(context).size.width,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.white, Colors.white.withOpacity(0)],
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 50,
                      left: 32,
                      right: 28,
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          IconButton(
                              onPressed: () => Navigator.pop(context),
                              icon: Platform.isIOS ? Icon(Icons.arrow_back_ios) : Icon(Icons.arrow_back)),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(onPressed: () {}, icon: SvgPicture.asset('assets/svgs/share.svg')),
                              AppSpacing.horizontalSpace24,
                              IconButton(onPressed: () {}, icon: Icon(Icons.favorite_border)),
                            ],
                          )
                        ],
                      ),
                    ),
                    Positioned(
                      bottom: 28,
                      width: MediaQuery.of(context).size.width,
                      child: Padding(
                        padding: AppInsets.horizontalInsets28,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(state.news.category?.toUpperCase() ?? '', style: TypographyTwCenW01Medium.caption2),
                            AppSpacing.verticalSpace16,
                            Text(state.news.title ?? '', style: TypographyTwCenW01Medium.title1),
                            AppSpacing.verticalSpace24,
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                SvgPicture.asset('assets/svgs/clock_analog.svg'),
                                AppSpacing.horizontalSpace4,
                                Text('${state.news.timeToRead}', style: TypographyNeueHaasUnicaW1G.menu1),
                              ],
                            ),
                            AppSpacing.verticalSpace30,
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Expanded(
                                  child: CustomButton(
                                    text: 'Exclude',
                                    textStyle: TypographyNeueHaasUnicaW1G.buttonBold,
                                    onTap: () {},
                                    borderRadius: AppBorderRadius.borderRadiusAll6,
                                    color: AppColors.greyLight.withOpacity(0.1),
                                  ),
                                ),
                                AppSpacing.horizontalSpace16,
                                Expanded(
                                  child: CustomButton(
                                    text: 'Exclude',
                                    textStyle: TypographyNeueHaasUnicaW1G.buttonBold,
                                    onTap: () {},
                                    borderRadius: AppBorderRadius.borderRadiusAll6,
                                    color: AppColors.greyLight.withOpacity(0.1),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: AppInsets.horizontalInsets28,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      AppSpacing.verticalSpace24,
                      Divider(thickness: 0.5),
                      AppSpacing.verticalSpace16,
                      Text('TAGS', style: TypographyTwCenW01Medium.subtitle2),
                      AppSpacing.verticalSpace24,
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: state.news.tags
                                ?.map<Widget>((e) => TagTile(
                                      tag: ContentCategoryTag(title: e.name ?? ''),
                                      onTap: () {},
                                    ))
                                .toList() ??
                            [],
                      ),

                      AppSpacing.verticalSpace20,
                      AppSpacing.verticalSpace20,
                      Text(
                        state.news.title ?? '',
                        style: TypographyTwCenW01Medium.title1,
                      ),
                      AppSpacing.verticalSpace20,
                      Text(
                        state.news.text ?? '',
                        style: TypographyNeueHaasUnicaW1G.basic3,
                      ),
                      AppSpacing.verticalSpace24,
                      if (state.news.youtubeLink != null && state.videoDetails != null) ...[
                        Text(
                          state.videoDetails!.title!,
                          style: TypographyNeueHaasUnicaW1G.basic2,
                        ),
                        AppSpacing.verticalSpace16,
                        SizedBox(
                          height: 196,
                          width: MediaQuery.of(context).size.width,
                          child: YoutubePlayer(
                            controller: YoutubePlayerController(
                              initialVideoId: Uri.parse(state.news.youtubeLink ?? '').queryParameters['v'] ?? '',
                              flags: YoutubePlayerFlags(autoPlay: false),
                            ),
                          ),
                        ),
                      ],
                      Divider(thickness: 0.5),
                      AppSpacing.verticalSpace16,
                      Text('RECOMMENDATIONS', style: TypographyTwCenW01Medium.subtitle2),
                      AppSpacing.verticalSpace24,
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: state.readings.map<Widget>((e) => RecommendedReadingTile(reading: e, onTap: () {})).toList(),
                      ),
                      AppSpacing.verticalSpace24,
                      // AuthorCard(author: author),
                      ContentSection(
                        titleStyle: TypographyTwCenW01Medium.title3,
                        title: state.elseSection.categoryName,
                        children: state.elseSection.items
                            .map<Widget>(
                              (e) => VerticalSmallContentCard(
                                placeholderPath: 'assets/pngs/small_content_card_placeholder.png',
                                post: e,
                                onLikePressed: () {},
                                onTap: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => DetailedPostPage(postId: e.id.toString())),
                                ),
                              ),
                            )
                            .toList(),
                      ),
                      AppSpacing.verticalSpace24,
                      CustomButton(
                        text: 'Add to meal plan',
                        onTap: () {},
                        borderRadius: AppBorderRadius.borderRadiusAll6,
                        color: AppColors.oliveColor,
                        height: 50,
                        width: MediaQuery.of(context).size.width,
                        textStyle: TypographyNeueHaasUnicaW1G.buttonBold,
                      ),
                      AppSpacing.verticalSpace24,
                    ],
                  ),
                ),
              ],
            );
          return Container();
        },
      ),
    );
  }
}
