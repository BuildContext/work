import 'package:flutter/material.dart';
import 'package:test_project/core/models/news_model.dart';
import 'package:test_project/core/models/quiz.dart';
import 'package:test_project/presentation/custom_widgets/content_section.dart';
import 'package:test_project/presentation/custom_widgets/large_content_card.dart';
import 'package:test_project/presentation/custom_widgets/quiz_card.dart';
import 'package:test_project/presentation/pages/ayuworld/detailed_post/detailed_post_page.dart';
import 'package:test_project/presentation/pages/ayuworld/widgets/content_card.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';

class AyurvedaTab extends StatelessWidget {
  final List<NewsResult> ayurvedaNews;
  final List<NewsResult> ayurvedaRecs;
  final Quiz quiz;
  final Future<void> Function() onRefresh;

  const AyurvedaTab({
    Key? key,
    required this.ayurvedaNews,
    required this.ayurvedaRecs,
    required this.quiz,
    required this.onRefresh,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView(
        children: [
          if (ayurvedaRecs.isEmpty && ayurvedaNews.isEmpty) ...[
            AppSpacing.verticalSpace16,
            Text(
              'No content to display',
              style: TypographyNeueHaasUnicaW1G.buttonBold,
              textAlign: TextAlign.center,
            ),
            AppSpacing.verticalSpace16,
          ],
          if (ayurvedaRecs.isNotEmpty)
            ContentSection(
              titleStyle: TypographyTwCenW01Medium.title1,
              title: 'Recommendation',
              displayTopSpacing: false,
              displayDivider: false,
              children: ayurvedaRecs
                  .map((e) => LargeContentCard(
                        placeholderPath: 'assets/pngs/large_content_card_placeholder.png',
                        onLikePressed: () {},
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => DetailedPostPage(postId: e.id ?? ''),
                          ),
                        ),
                        title: e.title ?? '',
                        imageLink: e.imageUrl ?? '',
                        icons: [],
                        time: e.timeToRead ?? '',
                      ))
                  .toList(),
            ),
          if (ayurvedaNews.isNotEmpty)
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: ayurvedaNews
                    .map<Widget>(
                      (e) => ContentCard(
                        title: e.title ?? '',
                        placeholderPath: 'assets/pngs/small_content_card_placeholder.png',
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => DetailedPostPage(postId: e.id.toString())),
                        ),
                        icons: [],
                        imageLink: e.imageUrl ?? '',
                      ),
                    )
                    .toList(),
              ),
            ),
          AppSpacing.verticalSpace24,
          QuizCard(quiz: quiz),
          AppSpacing.verticalSpace24,
        ],
      ),
    );
  }
}
