import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/custom_widgets/custom_text_field.dart';
import 'package:test_project/presentation/pages/root_page/root_page.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class LoginWithPhoneForm extends StatefulWidget {
  const LoginWithPhoneForm({Key? key}) : super(key: key);

  @override
  _LoginWithPhoneFormState createState() => _LoginWithPhoneFormState();
}

class _LoginWithPhoneFormState extends State<LoginWithPhoneForm> {
  GlobalKey<FormState> _phoneFormKey = GlobalKey<FormState>();
  GlobalKey<FormState> _smsCodeFormKey = GlobalKey<FormState>();
  CrossFadeState _crossFadeState = CrossFadeState.showFirst;
  TextEditingController _phoneController = TextEditingController();
  TextEditingController _smsCodeController = TextEditingController();
  int timeRemained = 119;
  String token = '';

  _startCountDown() async {
    setState(() => timeRemained = 119);
    for (int i = 0; i < 119; i++) {
      if (timeRemained == 0 || timeRemained < 0) {
        setState(() => timeRemained = 0);
        break;
      }
      if (timeRemained > 0) {
        await Future.delayed(Duration(seconds: 1), () => setState(() => timeRemained--));
      }
    }
  }

  String _getFormattedTimerTime(int seconds) {
    Duration currentDuration = Duration(seconds: seconds);
    int mins = currentDuration.inMinutes;
    int secondsRemained = seconds - (mins * 60);
    return '$mins:$secondsRemained';
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _phoneController.dispose();
    _smsCodeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedCrossFade(
      duration: Duration(milliseconds: 250),
      crossFadeState: _crossFadeState,
      firstChild: Form(
        key: _phoneFormKey,
        child: Column(
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            AppSpacing.verticalSpace20,
            CustomTextField(
              keyboardType: TextInputType.phone,
              hintText: 'Phone number',
              helperText: 'Phone number',
              controller: _phoneController,
              validator: (value) {
                if (value?.isEmpty ?? false)
                  return 'This is required field';
                else
                  return null;
              },
            ),
            AppSpacing.verticalSpace20,
            AppSpacing.verticalSpace20,
            CustomButton(
              onTap: () async {
                if (_phoneFormKey.currentState?.validate() ?? false) {
                  await FirebaseAuth.instance.verifyPhoneNumber(
                    phoneNumber: _phoneController.text,
                    verificationCompleted: (credential) {},
                    verificationFailed: (authException) {
                      print(authException);
                    },
                    codeSent: (verificationToken, resendId) {
                      setState(() => token = verificationToken);
                    },
                    codeAutoRetrievalTimeout: (code) {
                      setState(() => _smsCodeController.text = code);
                    },
                    timeout: Duration(seconds: 120),
                  );
                  setState(() => _crossFadeState = CrossFadeState.showSecond);
                  _startCountDown();
                }
              },
              text: 'Send',
              textStyle: TypographyNeueHaasUnicaW1G.buttonBold,
            ),
            AppSpacing.verticalSpace20,
            AppSpacing.verticalSpace20,
            CustomButton(
              color: Colors.transparent,
              showBorder: false,
              onTap: () {},
              text: 'Are you already registered?',
              textStyle: TypographyNeueHaasUnicaW1G.basic3.copyWith(fontWeight: FontWeight.bold),
            ),
            CustomButton(
              color: Colors.transparent,
              showBorder: false,
              onTap: () {
                // Navigator.pop(context);
                // AppInteractionsHelper.showBottomSheet(
                //   context: context,
                //   builder: (context) => BottomSheetContainer(mainAxisSize: MainAxisSize.min, child: LoginWithPhoneForm()),
                // );
              },
              text: 'Login',
              textStyle: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
            ),
          ],
        ),
      ),
      secondChild: Form(
        key: _smsCodeFormKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            AppSpacing.verticalSpace16,
            Text('Authorization by phone number', style: TypographyTwCenW01Medium.title1),
            AppSpacing.verticalSpace20,
            AppSpacing.verticalSpace20,
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(text: 'A confirmation code was sent to your phone.\n', style: TypographyNeueHaasUnicaW1G.basic3),
                  TextSpan(
                    text: 'Repeat the SMS.',
                    style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
                    recognizer: TapGestureRecognizer()..onTap = () => _startCountDown(),
                  ),
                ],
              ),
            ),
            AppSpacing.verticalSpace20,
            AppSpacing.verticalSpace20,
            PinCodeTextField(
              pinTheme: PinTheme(
                shape: PinCodeFieldShape.box,
                fieldHeight: 50,
                fieldWidth: 50,
                selectedFillColor: AppColors.oliveDark,
                activeColor: AppColors.oliveDark,
                inactiveColor: AppColors.greyLight,
                borderRadius: AppBorderRadius.borderRadiusAll6,
                selectedColor: AppColors.darkLight,
              ),
              keyboardType: TextInputType.number,
              appContext: context,
              length: 6,
              onChanged: (value) {},
              controller: _smsCodeController,
              obscureText: false,
            ),
            AppSpacing.verticalSpace8,
            Text(
              'Resend code ${_getFormattedTimerTime(timeRemained)}'.toUpperCase(),
              style: TypographyNeueHaasUnicaW1G.caption3.copyWith(fontWeight: FontWeight.bold),
            ),
            AppSpacing.verticalSpace20,
            AppSpacing.verticalSpace20,
            CustomButton(
              onTap: () async {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => RootPage(),
                  ),
                  (route) => false,
                );
                if (_smsCodeController.text.length >= 6) {
                  final phoneAuth = PhoneAuthProvider.credential(verificationId: token, smsCode: _smsCodeController.text);
                  await FirebaseAuth.instance.signInWithCredential(phoneAuth);
                  Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => RootPage()), (route) => false);
                }
              },
              text: 'Save',
              textStyle: TypographyNeueHaasUnicaW1G.buttonBold,
            ),
            AppSpacing.verticalSpace20,
            AppSpacing.verticalSpace20,
            CustomButton(
              color: Colors.transparent,
              showBorder: false,
              onTap: () {},
              text: 'Are you already registered?',
              textStyle: TypographyNeueHaasUnicaW1G.basic3.copyWith(fontWeight: FontWeight.bold),
            ),
            CustomButton(
              color: Colors.transparent,
              showBorder: false,
              onTap: () {
                // Navigator.pop(context);
                // AppInteractionsHelper.showBottomSheet(
                //   context: context,
                //   builder: (context) => BottomSheetContainer(mainAxisSize: MainAxisSize.min, child: LoginWithPhoneForm()),
                // );
              },
              text: 'Login',
              textStyle: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
            ),
          ],
        ),
      ),
    );
  }
}
