abstract class AuthorizationSheetState{}
class AuthorizationSheetInitial extends AuthorizationSheetState {}
class AuthorizationSheetLoading extends AuthorizationSheetState {}
class AuthorizationSheetSuccess extends AuthorizationSheetState {}
class AuthorizationSheetError extends AuthorizationSheetState {
  final String error ;

  AuthorizationSheetError({required this.error});
}