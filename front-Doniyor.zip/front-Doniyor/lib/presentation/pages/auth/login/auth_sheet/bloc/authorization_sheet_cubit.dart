import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:test_project/domain/services/auth_service.dart';
import 'package:test_project/presentation/pages/auth/login/auth_sheet/bloc/auth_sheet_state.dart';

class AuthorizationSheetCubit extends Cubit<AuthorizationSheetState> {
  AuthorizationSheetCubit() : super(AuthorizationSheetInitial());

  Future<bool> loginWithGoogle(BuildContext context) async {
    emit(AuthorizationSheetLoading());
    final loginSucceed = await AuthService.instance.loginWithGoogle();
    if (loginSucceed is bool && loginSucceed) {
      return true;
    } else {
      emit(AuthorizationSheetError(error: loginSucceed));
      return false;
    }
  }
}
