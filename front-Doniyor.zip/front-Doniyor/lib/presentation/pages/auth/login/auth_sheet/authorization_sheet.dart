import 'package:easy_localization/src/public_ext.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/custom_widgets/error_snackbar.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/pages/auth/auth_wrapper/auth_wrapper_page.dart';
import 'package:test_project/presentation/pages/auth/login/auth_sheet/bloc/auth_sheet_state.dart';
import 'package:test_project/presentation/pages/auth/login/auth_sheet/bloc/authorization_sheet_cubit.dart';
import 'package:test_project/presentation/pages/auth/registration/privacy_policy_page.dart';
import 'package:test_project/presentation/pages/auth/registration/registration_page.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

import '../login_with_phone_form.dart';

class AuthorizationSheet extends StatelessWidget {
  const AuthorizationSheet({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AuthorizationSheetCubit>();
    return BlocConsumer<AuthorizationSheetCubit, AuthorizationSheetState>(
      bloc: cubit,
      builder: (context, state) {
        if (state is AuthorizationSheetLoading)
          return Expanded(child: Loader());
        else
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              AppSpacing.verticalSpace24,
              CustomButton(
                onTap: () {},
                color: AppColors.oliveDark,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset('assets/svgs/apple_logo.svg'),
                    AppSpacing.horizontalSpace20,
                    Text('login_via', style: TypographyNeueHaasUnicaW1G.buttonBold).tr(namedArgs: {'source': 'Apple'}),
                  ],
                ),
              ),
              AppSpacing.verticalSpace16,
              CustomButton(
                onTap: () async {
                  final success = await cubit.loginWithGoogle(context);
                  if (success)
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => AuthWrapperPage()),
                      (route) => false,
                    );
                },
                color: AppColors.oliveDark,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset('assets/svgs/google_logo.svg'),
                    AppSpacing.horizontalSpace20,
                    Text('login_via', style: TypographyNeueHaasUnicaW1G.buttonBold).tr(namedArgs: {'source': 'Google'}),
                  ],
                ),
              ),
              AppSpacing.verticalSpace16,
              CustomButton(
                onTap: () {},
                color: AppColors.oliveDark,
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset('assets/svgs/facebook_logo.svg'),
                    AppSpacing.horizontalSpace20,
                    Text('login_via', style: TypographyNeueHaasUnicaW1G.buttonBold).tr(namedArgs: {'source': 'Facebook'}),
                  ],
                ),
              ),
              AppSpacing.verticalSpace16,
              CustomButton(
                onTap: () async {
                  final termsAgreed = await Navigator.push(context, MaterialPageRoute(builder: (context) => PrivacyPolicyPage()));
                  if (termsAgreed is bool && termsAgreed == true) {
                    Navigator.pop(context);
                    AppInteractionsHelper.showBottomSheet(context: context, child: RegistrationForm(), title: 'Registration');
                  }
                },
                color: AppColors.oliveDark,
                text: 'register_by_phone'.tr(),
                textStyle: TypographyNeueHaasUnicaW1G.buttonBold,
              ),
              AppSpacing.verticalSpace24,
              Text(
                'are_you_registered'.tr(),
                style: TypographyNeueHaasUnicaW1G.basic3.copyWith(fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              CustomButton(
                color: Colors.transparent,
                showBorder: false,
                onTap: () {
                  Navigator.pop(context);
                  AppInteractionsHelper.showBottomSheet(context: context, child: LoginWithPhoneForm(), title: 'Login');
                },
                text: 'login'.tr(),
                textStyle: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
              ),
            ],
          );
      },
      listener: (context, state) {
        if (state is AuthorizationSheetError) {
          ScaffoldMessenger.of(context).showSnackBar(ErorrSnackBar(content: Text(state.error)));
        }
      },
    );
  }
}
