import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class PrivacyPolicyPage extends StatefulWidget {
  const PrivacyPolicyPage({Key? key}) : super(key: key);

  @override
  State<PrivacyPolicyPage> createState() => _PrivacyPolicyPageState();
}

class _PrivacyPolicyPageState extends State<PrivacyPolicyPage> {
  bool _isAgree = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.pop(context, _isAgree),
          icon: Platform.isIOS ? Icon(Icons.arrow_back_ios) : Icon(Icons.arrow_back),
        ),
        actions: [
          IconButton(onPressed: () {}, icon: SvgPicture.asset('assets/svgs/share.svg')),
          IconButton(onPressed: () {}, icon: Icon(Icons.favorite_border)),
        ],
      ),
      body: ListView(
        padding: AppInsets.horizontalInsets28,
        children: [
          AppSpacing.verticalSpace30,
          Text('PRIVACY POLICY', style: TypographyTwCenW01Medium.subtitle2),
          AppSpacing.verticalSpace24,
          Text('Review Ayulyfe Privacy Policy', style: TypographyTwCenW01Medium.title1),
          AppSpacing.verticalSpace16,
          Text(
            'Data: ${DateFormat('dd.MM.yyyy').format(DateTime.now())}',
            style: TypographyNeueHaasUnicaW1G.basic1.copyWith(color: AppColors.greyLight),
          ),
          AppSpacing.verticalSpace16,
          Text(
            '1. The offer to pass a full quiz to determine your constitution and Vikrity.',
            style: TypographyNeueHaasUnicaW1G.basic2.copyWith(fontWeight: FontWeight.bold),
          ),
          AppSpacing.verticalSpace16,
          Text(
            'Comrades! the beginning of daily work on the formation of a position requires us to analyze the personnel training system, meets the urgent needs. Comrades! the beginning of daily work on the formation of a position requires us to analyze the personnel training system, meets the urgent needs.',
            style: TypographyNeueHaasUnicaW1G.basic3,
          ),
          AppSpacing.verticalSpace24,
          Text(
            '2. The offer to pass a full quiz to determine your constitution and Vikrity.',
            style: TypographyNeueHaasUnicaW1G.basic2.copyWith(fontWeight: FontWeight.bold),
          ),
          AppSpacing.verticalSpace16,
          Text(
            'Comrades! the beginning of daily work on the formation of a position requires us to analyze the personnel training system, meets the urgent needs. Comrades! the beginning of daily work on the formation of a position requires us to analyze the personnel training system, meets the urgent needs.',
            style: TypographyNeueHaasUnicaW1G.basic3,
          ),
          AppSpacing.verticalSpace16,
          AppSpacing.verticalSpace20,
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Checkbox(
                value: _isAgree,
                onChanged: (value) => setState(() => _isAgree = value ?? !_isAgree),
                activeColor: AppColors.oliveDark,
              ),
              AppSpacing.horizontalSpace12,
              Text('Agree', style: TypographyNeueHaasUnicaW1G.menu1),
            ],
          ),
          AppSpacing.verticalSpace30,
          CustomButton(
            onTap: () {
              if (_isAgree) Navigator.pop(context, _isAgree);
            },
            text: 'Save',
            textStyle: TypographyNeueHaasUnicaW1G.buttonBold.copyWith(
              color: _isAgree ? AppColors.darkLight : AppColors.greyLight,
            ),
            color: _isAgree ? AppColors.oliveColor : Colors.white,
          ),
          AppSpacing.verticalSpace24,
          CustomButton(
            onTap: () => Navigator.pop(context, false),
            color: Colors.transparent,
            showBorder: false,
            text: 'No, thanks',
            textStyle: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
          ),
        ],
      ),
    );
  }
}
