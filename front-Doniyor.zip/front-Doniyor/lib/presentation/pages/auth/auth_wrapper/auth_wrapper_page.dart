import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:test_project/presentation/pages/auth/login/auth_sheet/authorization_sheet.dart';
import 'package:test_project/presentation/pages/auth/login/auth_sheet/bloc/authorization_sheet_cubit.dart';
import 'package:test_project/presentation/pages/root_page/root_page.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

class AuthWrapperPage extends StatefulWidget {
  const AuthWrapperPage({Key? key}) : super(key: key);

  @override
  State<AuthWrapperPage> createState() => _AuthWrapperPageState();
}

class _AuthWrapperPageState extends State<AuthWrapperPage> {
  late StreamSubscription subscription;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      subscription = FirebaseAuth.instance.authStateChanges().listen((event) {
        if (event?.uid == null)
          AppInteractionsHelper.showBottomSheet(
            context: context,
            child: BlocProvider(
              create: (context) => AuthorizationSheetCubit(),
              child: AuthorizationSheet(),
            ),
            enableDrag: false,
          );
      });
    });
  }

  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.oliveDark,
      body: Container(
        color: AppColors.oliveDark,
        child: StreamBuilder<User?>(
          stream: FirebaseAuth.instance.authStateChanges(),
          builder: (context, userSnapshot) {
            if (userSnapshot.hasData) return RootPage();
            return SizedBox();
          },
        ),
      ),
    );
  }
}
