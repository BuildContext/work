import 'package:flutter/material.dart';
import 'package:test_project/core/models/suggested_title.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';

class SuggestedTitles extends StatelessWidget {
  final List<SuggestedTitle> titles;

  const SuggestedTitles({
    Key? key,
    required this.titles,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [Divider(thickness: 0.5)]..addAll(titles.map<Widget>((e) => SuggestedTitleTile(title: e)).toList()),
    );
  }
}

class SuggestedTitleTile extends StatelessWidget {
  final SuggestedTitle title;
  const SuggestedTitleTile({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: AppInsets.verticalInsets12,
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(width: 0.5, color: Theme.of(context).dividerColor)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: [
          AppSpacing.horizontalSpace8,
          Expanded(
            child: Text(title.title, style: Theme.of(context).textTheme.subtitle1?.copyWith(fontFamily: 'NeueHaasUnica')),
          ),
          Icon(
            Icons.arrow_forward_ios_rounded,
            color: AppColors.dark.withOpacity(0.5),
          ),
          AppSpacing.horizontalSpace12,
        ],
      ),
    );
  }
}
