import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';

import 'loader.dart';

class VerticalSmallContentCard extends StatelessWidget {
  final ContentCategoryItem post;
  final VoidCallback? onLikePressed;
  final VoidCallback onTap;
  final int? calories;
  final String placeholderPath;

  const VerticalSmallContentCard({
    Key? key,
    required this.post,
    required this.placeholderPath,
    required this.onLikePressed,
    required this.onTap,
    this.calories,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      color: Colors.white,
      child: Container(
        width: 152,
        margin: AppInsets.onlyRightInset16,
        child: InkWell(
          onTap: onTap,
          child: Stack(
            fit: StackFit.passthrough,
            children: [
              Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  CachedNetworkImage(
                    imageUrl: post.imageLink,
                    height: 152,
                    errorWidget: (context, url, trace) => Image.asset(placeholderPath),
                    progressIndicatorBuilder: (context, url, progress) => SizedBox(height: 152, child: Loader()),
                    imageBuilder: (context, imageProvider) => ClipRRect(
                      borderRadius: AppBorderRadius.borderRadiusAll6,
                      child: Image(
                        image: imageProvider,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  AppSpacing.verticalSpace12,
                  Text(post.title, style: TypographyTwCenW01Medium.subtitle1),
                  AppSpacing.verticalSpace14,
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: post.icons
                        .map<Widget>((category) => Padding(
                              padding: AppInsets.onlyRightInset8,
                              child: category.isLocal
                                  ? SvgPicture.asset('assets/svgs/${category.iconPath}.svg')
                                  : SvgPicture.network(category.iconPath),
                            ))
                        .toList(),
                  ),
                ],
              ),
              Padding(
                padding: AppInsets.insetsAll16,
                child: Align(alignment: Alignment.topRight, child: Icon(Icons.favorite_border)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
