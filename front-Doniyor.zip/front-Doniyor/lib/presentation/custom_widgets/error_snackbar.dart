import 'package:flutter/material.dart';

class ErorrSnackBar extends SnackBar {
    ErorrSnackBar({required Widget content}) : super(content: content);


  @override
  Widget build(BuildContext context) {
    return SnackBar(content: content);
  }
}
