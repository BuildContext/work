import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/user_preference_model.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class FilterPreferenceChip extends StatefulWidget {
  final UserPreference preference;
  final ValueChanged<UserPreference> onPreferenceDeleted;
  final Color? color;
  final bool isRemovable;

  const FilterPreferenceChip({
    Key? key,
    required this.preference,
    required this.onPreferenceDeleted,
    this.color,
    this.isRemovable = true,
  }) : super(key: key);

  @override
  State<FilterPreferenceChip> createState() => _FilterPreferenceChipState();
}

class _FilterPreferenceChipState extends State<FilterPreferenceChip> {
  bool _isSelected = false;

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: AppBorderRadius.borderRadiusAll6,
      elevation: 0,
      color: _isSelected ? AppColors.oliveDark : AppColors.oliveLight,
      child: InkWell(
        onTap: () {
          widget.onPreferenceDeleted(widget.preference);
          setState(() => _isSelected = !_isSelected);
        },
        borderRadius: AppBorderRadius.borderRadiusAll6,
        child: Ink(
          decoration: BoxDecoration(
            color: _isSelected ? AppColors.oliveDark : AppColors.oliveLight,
            borderRadius: AppBorderRadius.borderRadiusAll6,
          ),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
          height: 40,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (widget.preference.iconPath.isNotEmpty) SvgPicture.asset(widget.preference.iconPath),
              if (widget.preference.iconPath.isNotEmpty) AppSpacing.horizontalSpace8,
              Text(widget.preference.title, style: TypographyNeueHaasUnicaW1G.basic3),
              if (_isSelected) AppSpacing.horizontalSpace30,
              if (_isSelected)
                GestureDetector(
                  onTap: () {
                    widget.onPreferenceDeleted(widget.preference);
                    setState(() => _isSelected = !_isSelected);
                  },
                  child: Icon(Icons.close, color: AppColors.dark),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
