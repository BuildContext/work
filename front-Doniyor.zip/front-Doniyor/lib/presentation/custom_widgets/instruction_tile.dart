import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:test_project/core/models/post.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class InstructionTile extends StatefulWidget {
  final PostInstruction instructions;
  final bool isEnabled;

  const InstructionTile({
    Key? key,
    required this.instructions,
    this.isEnabled = false,
  }) : super(key: key);

  @override
  State<InstructionTile> createState() => _InstructionTileState();
}

class _InstructionTileState extends State<InstructionTile> {
  bool isPlaying = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 96,
      width: MediaQuery.of(context).size.width,
      margin: AppInsets.onlyBottomInset24,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          CachedNetworkImage(
            imageUrl: widget.instructions.imageLink,
            height: 96,
            width: 96,
            errorWidget: (context, url, trace) => ClipRRect(
              borderRadius: AppBorderRadius.borderRadiusAll6,
              child: Image.asset(
                widget.isEnabled ? 'assets/pngs/post_detail_placeholder.png' : 'assets/pngs/instructions_desabled_photo.png',
                fit: BoxFit.cover,
              ),
            ),
            progressIndicatorBuilder: (context, url, progress) => SizedBox(height: 96, width: 96, child: Loader()),
            imageBuilder: (context, imageProvider) => ClipRRect(
              borderRadius: AppBorderRadius.borderRadiusAll6,
              child: Image(image: imageProvider, fit: BoxFit.cover),
            ),
          ),
          AppSpacing.horizontalSpace8,
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  child: Padding(
                    padding: AppInsets.onlyRightInset16,
                    child: Text(widget.instructions.title, style: TypographyTwCenW01Medium.subtitle1),
                  ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: widget.instructions.icons
                      .map<Widget>((category) => Padding(
                            padding: AppInsets.onlyRightInset16,
                            child: category.isLocal
                                ? SvgPicture.asset('assets/svgs/${category.iconPath}.svg')
                                : SvgPicture.network(category.iconPath),
                          ))
                      .toList()
                    ..add(Text('${widget.instructions.time.inMinutes} min', style: AppTheme.timeStyle)),
                ),
              ],
            ),
          ),
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              border: Border.all(
                color: widget.isEnabled ? AppColors.darkLight : AppColors.greyLight,
                width: 0.5,
              ),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.play_arrow,
              color: widget.isEnabled ? AppColors.darkLight : AppColors.greyLight,
            ),
          ),
        ],
      ),
    );
  }
}
