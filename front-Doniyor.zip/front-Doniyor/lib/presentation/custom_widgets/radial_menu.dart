import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_theme.dart';

class RadialMenu extends StatefulWidget {
  final Offset center;
  const RadialMenu({Key? key, required this.center}) : super(key: key);

  @override
  State<RadialMenu> createState() => _RadialMenuState();
}

class _RadialMenuState extends State<RadialMenu> with SingleTickerProviderStateMixin {
  late Offset _favouriteOffset = widget.center;
  late Offset _checkOffset = widget.center;
  late Offset _calendarOffset = widget.center;
  late Offset _shareButtonOffset = widget.center;
  late Offset _deleteOffset = widget.center;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance?.addPostFrameCallback((timeStamp) async {
      print('${MediaQuery.of(context).size.width - widget.center.dx}px to right edge');
      print('${MediaQuery.of(context).size.height - widget.center.dy}px to bottom edge');
      bool hasSpaceFromLeft = widget.center.dx > 80;
      bool hasSpaceFromRight = (MediaQuery.of(context).size.width - widget.center.dx) > 80;
      print('hasSpaceFromLeft: $hasSpaceFromLeft');
      print('hasSpaceFromRight: $hasSpaceFromRight');
      if (hasSpaceFromLeft && hasSpaceFromRight) {
        await _showOptionsFromLeftWithTilt();
      } else if (!hasSpaceFromLeft && hasSpaceFromRight) {
        await _showOptionsFromRight();
      } else {
        await _showOptionsFromLeft();
      }
    });
  }

  _showOptionsFromLeft() async {
    setState(() {
      _favouriteOffset = Offset(widget.center.dx, widget.center.dy + 80);
    });
    await Future.delayed(Duration(milliseconds: 125));
    setState(() {
      _checkOffset = Offset(widget.center.dx - 56, widget.center.dy + 56);
    });
    await Future.delayed(Duration(milliseconds: 125));
    setState(() {
      _calendarOffset = Offset(widget.center.dx - 80, widget.center.dy);
    });
    await Future.delayed(Duration(milliseconds: 125));
    setState(() {
      _shareButtonOffset = Offset(widget.center.dx - 56, widget.center.dy - 56);
    });
    await Future.delayed(Duration(milliseconds: 125));
    setState(() {
      _deleteOffset = Offset(widget.center.dx, widget.center.dy - 80);
    });
  }

  _showOptionsFromLeftWithTilt() async {
    setState(() {
      _favouriteOffset = Offset(widget.center.dx - 56, widget.center.dy + 56);
    });
    await Future.delayed(Duration(milliseconds: 125));
    setState(() {
      _checkOffset = Offset(widget.center.dx - 80, widget.center.dy);
    });
    await Future.delayed(Duration(milliseconds: 125));
    setState(() {
      _calendarOffset = Offset(widget.center.dx - 56, widget.center.dy - 56);
    });
    await Future.delayed(Duration(milliseconds: 125));
    setState(() {
      _shareButtonOffset = Offset(widget.center.dx, widget.center.dy - 80);
    });
    await Future.delayed(Duration(milliseconds: 125));
    setState(() {
      _deleteOffset = Offset(widget.center.dx + 56, widget.center.dy - 56);
    });
  }

  _showOptionsFromRight() async {
    setState(() {
      _favouriteOffset = Offset(widget.center.dx, widget.center.dy + 80);
    });
    await Future.delayed(Duration(milliseconds: 125));
    setState(() {
      _checkOffset = Offset(widget.center.dx + 56, widget.center.dy + 56);
    });
    await Future.delayed(Duration(milliseconds: 125));
    setState(() {
      _calendarOffset = Offset(widget.center.dx + 80, widget.center.dy);
    });
    await Future.delayed(Duration(milliseconds: 125));
    setState(() {
      _shareButtonOffset = Offset(widget.center.dx + 56, widget.center.dy - 56);
    });
    await Future.delayed(Duration(milliseconds: 125));
    setState(() {
      _deleteOffset = Offset(widget.center.dx, widget.center.dy - 80);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Positioned(
          top: widget.center.dy,
          left: widget.center.dx,
          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.oliveLight, width: 8),
            ),
          ),
        ),
        AnimatedPositioned(
          top: _favouriteOffset.dy,
          left: _favouriteOffset.dx,
          child: CustomIconedButton(
            icon: SvgPicture.asset('assets/svgs/favourites.svg'),
            onTap: () {},
          ),
          duration: Duration(milliseconds: 125),
        ),
        AnimatedPositioned(
          top: _checkOffset.dy,
          left: _checkOffset.dx,
          child: CustomIconedButton(
            icon: SvgPicture.asset('assets/svgs/checked_square.svg'),
            onTap: () {},
          ),
          duration: Duration(milliseconds: 125),
        ),
        AnimatedPositioned(
          top: _calendarOffset.dy,
          left: _calendarOffset.dx,
          child: CustomIconedButton(
            icon: SvgPicture.asset('assets/svgs/calendar.svg'),
            onTap: () {},
          ),
          duration: Duration(milliseconds: 125),
        ),
        AnimatedPositioned(
          top: _shareButtonOffset.dy,
          left: _shareButtonOffset.dx,
          child: CustomIconedButton(
            icon: SvgPicture.asset('assets/svgs/share.svg'),
            onTap: () {},
          ),
          duration: Duration(milliseconds: 125),
        ),
        AnimatedPositioned(
          top: _deleteOffset.dy,
          left: _deleteOffset.dx,
          child: CustomIconedButton(
            icon: SvgPicture.asset('assets/svgs/delete.svg'),
            onTap: () {},
          ),
          duration: Duration(milliseconds: 125),
        ),
      ],
    );
  }
}

class CustomIconedButton extends StatelessWidget {
  final VoidCallback onTap;
  final Widget icon;

  const CustomIconedButton({
    Key? key,
    required this.onTap,
    required this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      color: AppColors.oliveColor,
      shape: CircleBorder(),
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: onTap,
        child: Ink(
          height: 48,
          width: 48,
          padding: AppInsets.insetsAll8,
          decoration: BoxDecoration(
            color: AppColors.oliveColor,
            shape: BoxShape.circle,
          ),
          child: icon,
        ),
      ),
    );
  }
}
