import 'package:charts_flutter/flutter.dart' as charts;
import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class AyulifeChartLegendItem extends StatelessWidget {
  final bool isSelected;
  final String title;
  Color color = AppColors.darkLight;
  final String dataText;
  final bool showDataTextFirst;

  AyulifeChartLegendItem({
    Key? key,
    required this.isSelected,
    this.showDataTextFirst = true,
    required this.title,
    required this.dataText,
    dynamic color,
  }) : super(key: key) {
    if (color is Color) {
      this.color = color;
    }
    if (color is charts.Color) {
      this.color = Color.fromARGB(color.a, color.r, color.g, color.b);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: AppInsets.verticalInsets8,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
            ),
          ),
          AppSpacing.horizontalSpace4,
          RichText(
            text: TextSpan(
              children: [
                if (showDataTextFirst)
                  TextSpan(
                    text: '$dataText',
                    style: TypographyNeueHaasUnicaW1G.basic2.copyWith(
                      color: isSelected ? AppColors.darkLight : AppColors.dark.withOpacity(0.5),
                    ),
                  ),
                TextSpan(
                  text: '$title',
                  style: TypographyNeueHaasUnicaW1G.basic3.copyWith(
                    color: isSelected ? AppColors.darkLight : AppColors.dark.withOpacity(0.5),
                  ),
                ),
                if (!showDataTextFirst)
                  TextSpan(
                    text: '$dataText',
                    style: TypographyNeueHaasUnicaW1G.basic2.copyWith(
                      color: isSelected ? AppColors.darkLight : AppColors.dark.withOpacity(0.5),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
