import 'package:flutter/material.dart';
import 'package:test_project/presentation/custom_widgets/custom_text_field.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';

class SearchSheet extends StatefulWidget {
  const SearchSheet({Key? key}) : super(key: key);

  @override
  State<SearchSheet> createState() => _SearchSheetState();
}

class _SearchSheetState extends State<SearchSheet> {
  TextEditingController _requestController = TextEditingController();

  List<String> _mockSearchItems = [
    'Hi! This is first option of search',
    'Hi! This is second option of search',
    'Hi! This is third option of search',
    'Hi! This is 4th option of search',
    'Hi! This is 5th option of search',
    'Hi! This is 6th option of search',
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Divider(),
        AppSpacing.verticalSpace24,
        CustomTextField(
          controller: _requestController,
          hintText: 'Find a product or dish',
          helperText: 'Find a product or dish',
          onChanged: (value) => setState(() {}),
        ),
        AppSpacing.verticalSpace16,
        SizedBox(
          height: 175,
          child: ListView(
            children: List<Widget>.from(
              _mockSearchItems.where((element) => element.contains(_requestController.text) && _requestController.text.isNotEmpty).map(
                    (e) => Padding(
                      padding: AppInsets.verticalInsets8,
                      child: Text(e, style: TypographyNeueHaasUnicaW1G.basic1),
                    ),
                  ),
            ),
          ),
        ),
      ],
    );
  }
}
