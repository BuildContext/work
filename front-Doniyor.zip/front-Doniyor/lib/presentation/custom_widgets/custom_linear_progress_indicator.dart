import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class NutrientProgressIndicator extends StatelessWidget {
  final double value;
  final String title;
  final String measurementQuantity;
  final Color progressColor, backgroundColor;

  const NutrientProgressIndicator({
    Key? key,
    required this.value,
    required this.title,
    this.measurementQuantity = 'g',
    this.progressColor = AppColors.oliveColor,
    this.backgroundColor = AppColors.oliveLight,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      children: [
        Expanded(
          child: Text(title, style: TypographyNeueHaasUnicaW1G.basic2.copyWith(fontWeight: FontWeight.bold)),
        ),
        Container(
          width: 104,
          decoration: BoxDecoration(
            border: Border.all(color: AppColors.oliveDark, width: 0.5),
          ),
          child: LinearProgressIndicator(
            minHeight: 8,
            value: value == 0 ? 0 : value / (value * 2),
            backgroundColor: backgroundColor,
            color: progressColor,
          ),
        ),
        AppSpacing.horizontalSpace12,
        Text(
          '${value.toStringAsFixed(2)}$measurementQuantity',
          style: TypographyNeueHaasUnicaW1G.basic2.copyWith(fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}
