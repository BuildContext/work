import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:test_project/presentation/theme/app_theme.dart';

class AppSwitchButton extends StatefulWidget {
  final ValueChanged<bool> onSwitched;
  final bool? isEnabled;

  const AppSwitchButton({
    Key? key,
    required this.onSwitched,
    this.isEnabled,
  }) : super(key: key);

  @override
  State<AppSwitchButton> createState() => _AppSwitchButtonState();
}

class _AppSwitchButtonState extends State<AppSwitchButton> {
  late bool _isEnabled = widget.isEnabled ?? false;

  @override
  Widget build(BuildContext context) {
    return FlutterSwitch(
      value: _isEnabled,
      onToggle: (value) => setState(() => _isEnabled = value),
      height: 36,
      width: 60,
      activeColor: AppColors.oliveDark,
      toggleColor: AppColors.oliveLight,
    );
  }
}
