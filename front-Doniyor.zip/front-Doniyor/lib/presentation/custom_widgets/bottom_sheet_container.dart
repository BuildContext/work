import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class BottomSheetContainer extends StatelessWidget {
  final Widget child;
  final MainAxisSize mainAxisSize;
  final Color? color;
  final String? title;

  const BottomSheetContainer({
    Key? key,
    required this.child,
    this.title,
    this.mainAxisSize = MainAxisSize.min,
    this.color,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: AppInsets.horizontalInsets28,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
        color: color ?? Colors.white,
      ),
      child: Column(
        mainAxisSize: mainAxisSize,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: 20,
            child: Center(
              child: Container(
                alignment: Alignment.center,
                width: 72,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.oliveDark,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
          ),
          if (title != null) ...[
            AppSpacing.verticalSpace8,
            Text(title!, style: TypographyTwCenW01Medium.title1),
            AppSpacing.verticalSpace24,
          ],
          child,
        ],
      ),
    );
  }
}
