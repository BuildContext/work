import 'package:flutter/material.dart';

class CustomArcChartData {
  final double percentage;
  final String title;
  final Color color;

  CustomArcChartData({
    required this.percentage,
    required this.title,
    required this.color,
  });
}
