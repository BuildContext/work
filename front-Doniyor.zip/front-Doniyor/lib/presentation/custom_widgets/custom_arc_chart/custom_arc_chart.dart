import 'dart:math';

import 'package:flutter/material.dart';
import 'package:test_project/presentation/custom_widgets/ayulife_chart_legend_item.dart';
import 'package:test_project/presentation/custom_widgets/custom_arc_chart/data_models/custom_arc_chart_data_model.dart';
import 'package:test_project/presentation/pages/profile/dosha/widgets/chart_sorting_dome_button.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:touchable/touchable.dart';

class CustomArcChart extends StatefulWidget {
  final List<CustomArcChartData> data;

  const CustomArcChart({
    Key? key,
    required this.data,
  }) : super(key: key);

  @override
  State<CustomArcChart> createState() => _CustomArcChartState();
}

class _CustomArcChartState extends State<CustomArcChart> {
  int? selectedIndex;
  TapDownDetails? tapDetails;
  ValueNotifier<Offset> notifier = ValueNotifier(Offset.zero);
  SortingMode currentSortingMode = SortingMode.year;

  @override
  Widget build(BuildContext context) {
    final size = Size(MediaQuery.of(context).size.width - 100, 150);
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          mainAxisSize: MainAxisSize.max,
          children: [
            Text('0%', style: TypographyNeueHaasUnicaW1G.caption4),
            GestureDetector(
              onTapDown: (details) => setState(() => notifier.value = details.localPosition),
              child: CanvasTouchDetector(
                gesturesToOverride: [
                  GestureType.onTapDown,
                  GestureType.onTapUp,
                ],
                builder: (context) => CustomPaint(
                  willChange: true,
                  size: size,
                  painter: CustomArcChartPainter(
                    context: context,
                    onSectorChanged: (index) => setState(() => selectedIndex = index),
                    data: widget.data,
                    selectedIndex: selectedIndex,
                  ),
                ),
              ),
            ),
            Text('100%', style: TypographyNeueHaasUnicaW1G.caption4),
          ],
        ),
        AppSpacing.verticalSpace10,
        AppSpacing.verticalSpace8,
        Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            ChartSortingModeButton(
              modeName: '1D',
              onTap: () => setState(() => currentSortingMode = SortingMode.day),
              isSelected: SortingMode.day == currentSortingMode,
            ),
            ChartSortingModeButton(
              modeName: '1W',
              onTap: () => setState(() => currentSortingMode = SortingMode.week),
              isSelected: SortingMode.week == currentSortingMode,
            ),
            ChartSortingModeButton(
              modeName: '1M',
              onTap: () => setState(() => currentSortingMode = SortingMode.month),
              isSelected: SortingMode.month == currentSortingMode,
            ),
            ChartSortingModeButton(
              modeName: '1Y',
              onTap: () => setState(() => currentSortingMode = SortingMode.year),
              isSelected: SortingMode.year == currentSortingMode,
            ),
            ChartSortingModeButton(
              modeName: 'All',
              onTap: () => setState(() => currentSortingMode = SortingMode.all),
              isSelected: SortingMode.all == currentSortingMode,
            ),
          ],
        ),
        AppSpacing.verticalSpace10,
        AppSpacing.verticalSpace8,
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: widget.data
              .map((e) => AyulifeChartLegendItem(
                    showDataTextFirst: false,
                    isSelected: selectedIndex == widget.data.indexOf(e),
                    title: e.title,
                    dataText: ' ${e.percentage.toStringAsFixed(0)} %',
                    color: e.color,
                  ))
              .toList(),
        ),
      ],
    );
  }
}

class CustomArcChartPainter extends CustomPainter {
  final List<CustomArcChartData> data;
  int? selectedIndex;
  final BuildContext context;
  final ValueChanged<int> onSectorChanged;

  CustomArcChartPainter({
    required this.data,
    required this.context,
    this.selectedIndex,
    required this.onSectorChanged,
  });

  @override
  void paint(Canvas ordinalCanvas, Size size) {
    final canvas = TouchyCanvas(context, ordinalCanvas);
    List<double> radians = List.from(
      data.map((e) => pi * (e.percentage / 100)),
    );
    var rect = Rect.fromLTWH(8, 10, size.width - 12, size.height * 1.75);
    var startAngle = pi;
    var useCenter = false;
    var paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 16;

    for (int i = 0; i < data.length; i++) {
      paint.color = data.elementAt(i).color;
      if (i > 0) startAngle += radians.elementAt(i - 1);
      if (selectedIndex == i)
        paint..strokeWidth = 20;
      else
        paint..strokeWidth = 16;
      canvas.drawArc(
        rect,
        startAngle,
        radians.elementAt(i),
        useCenter,
        paint,
        onTapDown: (details) => onSectorChanged(i),
        onTapUp: (details) => onSectorChanged(i),
      );
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}

enum SortingMode { day, week, month, year, all }
