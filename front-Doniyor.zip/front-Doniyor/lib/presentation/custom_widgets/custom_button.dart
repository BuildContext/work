import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_theme.dart';

class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  final BorderRadius borderRadius;
  final Color? color;
  final double? width;
  final double? height;
  final TextStyle? textStyle;
  final Widget? child;
  final bool showBorder;

  const CustomButton({
    Key? key,
    this.text = '',
    this.showBorder = true,
    required this.onTap,
    this.borderRadius = AppBorderRadius.borderRadiusAll6,
    this.color = AppColors.oliveColor,
    this.width,
    this.height = 50,
    this.textStyle,
    this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: borderRadius,
      elevation: 0,
      color: color,
      child: InkWell(
        onTap: onTap,
        borderRadius: borderRadius,
        child: Ink(
          width: width,
          height: height,
          padding: AppInsets.insetsAll12,
          decoration: BoxDecoration(
            borderRadius: borderRadius,
            color: color,
            border: showBorder ? Border.all(color: AppColors.oliveDark, width: 0.5) : null,
          ),
          child: child != null ? child : Center(child: Text(text, style: textStyle ?? Theme.of(context).textTheme.bodyText1)),
        ),
      ),
    );
  }
}
