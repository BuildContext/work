import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:test_project/core/models/quiz.dart';
import 'package:test_project/presentation/pages/quiz_pages/quiz_page_selector.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/extentions/hex_color.dart';

class QuizCard extends StatelessWidget {
  final Quiz quiz;

  const QuizCard({
    Key? key,
    required this.quiz,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      color: HexColor(quiz.colorHex),
      borderRadius: AppBorderRadius.borderRadiusAll8,
      child: Ink(
        padding: EdgeInsets.fromLTRB(16, 17, 20, 17),
        decoration: BoxDecoration(
          color: HexColor(quiz.colorHex),
          borderRadius: AppBorderRadius.borderRadiusAll8,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Quiz: ${quiz.title}', style: TypographyTwCenW01Medium.title1),
            AppSpacing.verticalSpace12,
            Row(
              mainAxisSize: MainAxisSize.min,
              children: quiz.icons
                  .map<Widget>((category) => Padding(
                        padding: AppInsets.onlyRightInset16,
                        child: category.isLocal
                            ? SvgPicture.asset('assets/svgs/${category.iconPath}.svg')
                            : SvgPicture.network(category.iconPath),
                      ))
                  .toList()
                ..add(Text('${quiz.time.inMinutes} min', style: AppTheme.timeStyle)),
            ),
            AppSpacing.verticalSpace12,
            RichText(
              text: TextSpan(
                children: [
                  if (quiz.description.length < 150) TextSpan(text: quiz.description, style: TypographyNeueHaasUnicaW1G.basic2),
                  if (quiz.description.length > 150)
                    TextSpan(
                      text: quiz.description.replaceRange(150, quiz.description.length, ' ... '),
                      style: TypographyNeueHaasUnicaW1G.basic2,
                    ),
                  TextSpan(
                    text: 'More',
                    style: TypographyNeueHaasUnicaW1G.basic2.copyWith(color: AppColors.darkLight.withOpacity(0.5)),
                    recognizer: TapGestureRecognizer()
                      ..onTap = () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => QuizPage(quiz: quiz),
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
