import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class LargeContentCard extends StatelessWidget {
  final VoidCallback? onLikePressed;
  final VoidCallback onTap;
  final String title;
  final int? calories;
  final String placeholderPath;
  final String imageLink;
  final List<ContentCategoryIcon> icons;
  final String time;

  const LargeContentCard({
    Key? key,
    required this.onLikePressed,
    required this.placeholderPath,
    required this.onTap,
    required this.icons,
    this.calories,
    required this.title,
    required this.imageLink,
    required this.time,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      color: Colors.white,
      child: Container(
        margin: AppInsets.onlyRightInset16,
        width: 320,
        child: InkWell(
          onTap: onTap,
          child: Stack(
            fit: StackFit.passthrough,
            children: [
              Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  CachedNetworkImage(
                    imageUrl: imageLink,
                    errorWidget: (context, url, trace) => Image.asset(placeholderPath),
                    progressIndicatorBuilder: (context, url, progress) => SizedBox(height: 177, child: Loader()),
                    imageBuilder: (context, imageProvider) => Container(
                      height: 177,
                      clipBehavior: Clip.hardEdge,
                      decoration: BoxDecoration(borderRadius: AppBorderRadius.borderRadiusAll6),
                      child: Image(
                        image: imageProvider,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  AppSpacing.verticalSpace12,
                  Text(title, style: TypographyTwCenW01Medium.subtitle1),
                  AppSpacing.verticalSpace14,
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: icons
                        .map<Widget>((category) => Padding(
                              padding: AppInsets.onlyRightInset16,
                              child: category.isLocal
                                  ? SvgPicture.asset('assets/svgs/${category.iconPath}.svg')
                                  : SvgPicture.network(category.iconPath),
                            ))
                        .toList()
                      ..addAll([
                        Text('$time', style: AppTheme.timeStyle),
                        AppSpacing.horizontalSpace8,
                        if (calories != null) Text('${calories}kCal', style: AppTheme.timeStyle),
                      ]),
                  ),
                ],
              ),
              Padding(
                padding: AppInsets.insetsAll16,
                child: Align(alignment: Alignment.topRight, child: Icon(Icons.favorite_border)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
