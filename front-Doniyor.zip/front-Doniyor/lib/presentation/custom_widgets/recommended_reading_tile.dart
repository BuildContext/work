import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:test_project/core/models/post.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/extentions/hex_color.dart';

class RecommendedReadingTile extends StatelessWidget {
  final RecommendedReading reading;
  final VoidCallback onTap;

  const RecommendedReadingTile({
    Key? key,
    required this.reading,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: AppInsets.onlyBottomInset24,
      child: Material(
        borderRadius: AppBorderRadius.borderRadiusAll8,
        elevation: 0,
        color: HexColor(reading.hexColor),
        child: InkWell(
          onTap: onTap,
          borderRadius: AppBorderRadius.borderRadiusAll8,
          child: Ink(
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.fromLTRB(16, 17, 20, 17),
            decoration: BoxDecoration(
              color: HexColor(reading.hexColor),
              borderRadius: AppBorderRadius.borderRadiusAll8,
            ),
            child: Stack(
              children: [
                Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(reading.heading, style: TypographyTwCenW01Medium.title1),
                    AppSpacing.verticalSpace12,
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: reading.icons
                          .map((e) => Padding(
                                padding: AppInsets.onlyRightInset16,
                                child: e.isLocal ? SvgPicture.asset('assets/svgs/${e.iconPath}.svg') : SvgPicture.network(e.iconPath),
                              ))
                          .toList(),
                    ),
                    AppSpacing.verticalSpace12,
                    Text(reading.description, style: TypographyNeueHaasUnicaW1G.basic2),
                  ],
                ),
                Positioned(top: 16, right: 16, child: Icon(Icons.favorite_border)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
