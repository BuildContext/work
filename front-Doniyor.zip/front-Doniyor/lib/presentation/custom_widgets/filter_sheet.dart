import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/core/models/user_preference_model.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/custom_widgets/custom_drop_down_button.dart';
import 'package:test_project/presentation/custom_widgets/user_preference_tile.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class FilterSheet extends StatefulWidget {
  const FilterSheet({Key? key}) : super(key: key);

  @override
  State<FilterSheet> createState() => _FilterSheetState();
}

class _FilterSheetState extends State<FilterSheet> {
  bool _categoryChosen = false;
  List<UserPreference> _filterPreferences = [
    UserPreference(title: 'Seasonal', iconPath: ''),
    UserPreference(title: 'Summer', iconPath: ''),
    UserPreference(title: 'Autumn', iconPath: ''),
    UserPreference(title: 'Winter', iconPath: ''),
    UserPreference(title: 'Christmas', iconPath: ''),
    UserPreference(title: 'Spring', iconPath: ''),
  ];
  List<UserPreference> _appliedFilters = [
    UserPreference(title: 'Most Popular', iconPath: ''),
    UserPreference(title: 'Make In 10 Mins', iconPath: ''),
    UserPreference(title: 'Mediterranean Drems', iconPath: ''),
  ];
  List<UserPreference> _selectedFilterPreferences = [];

  @override
  void initState() {
    super.initState();
  }

  bool get shouldShowAppliedFilters => _selectedFilterPreferences.isNotEmpty;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (shouldShowAppliedFilters) ...[
          AppSpacing.verticalSpace20,
          AppSpacing.verticalSpace20,
          Text('applied_filters'.tr().toUpperCase(), style: TypographyTwCenW01Medium.subtitle2),
          AppSpacing.verticalSpace24,
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _appliedFilters
                .map(
                  (e) => FilterPreferenceChip(
                    preference: e,
                    onPreferenceDeleted: (preference) {},
                    color: e.title == 'Winter' ? AppColors.oliveDark : AppColors.oliveLight,
                    isRemovable: true,
                  ),
                )
                .toList(),
          ),
        ],
        AppSpacing.verticalSpace20,
        Text('category'.tr().toUpperCase(), style: TypographyTwCenW01Medium.subtitle2),
        AppSpacing.verticalSpace24,
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              CustomDropDownButton(
                onChanged: (value) => setState(() => _categoryChosen = true),
                items: [
                  CustomDropDownOption(title: 'menu'.tr(), value: 'menu'),
                  CustomDropDownOption(title: 'seasons'.tr(), value: 'seasons'),
                ],
              ),
              CustomDropDownButton(
                onChanged: (value) => setState(() => _categoryChosen = true),
                items: [
                  CustomDropDownOption(title: 'ingredients'.tr(), value: 'ingredients'),
                  CustomDropDownOption(title: 'recipes'.tr(), value: 'recipes'),
                ],
              ),
              CustomDropDownButton(
                onChanged: (value) => setState(() => _categoryChosen = true),
                items: [
                  CustomDropDownOption(title: 'exclude'.tr(), value: 'exclude'),
                  CustomDropDownOption(title: 'include'.tr(), value: 'include'),
                ],
              ),
            ],
          ),
        ),
        if (_categoryChosen) ...[
          AppSpacing.verticalSpace20,
          AppSpacing.verticalSpace20,
          Text('tags'.tr().toUpperCase(), style: TypographyTwCenW01Medium.subtitle2),
          AppSpacing.verticalSpace24,
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _filterPreferences
                .map(
                  (e) => FilterPreferenceChip(
                    preference: e,
                    onPreferenceDeleted: (preference) {
                      setState(() {
                        if (_selectedFilterPreferences.contains(preference))
                          _selectedFilterPreferences.remove(preference);
                        else
                          _selectedFilterPreferences.add(preference);
                      });
                    },
                    color: e.title == 'Winter' ? AppColors.oliveDark : AppColors.oliveLight,
                    isRemovable: e.title == 'Winter',
                  ),
                )
                .toList(),
          ),
          AppSpacing.verticalSpace20,
          AppSpacing.verticalSpace20,
        ],
        if (_categoryChosen)
          CustomButton(
            onTap: () {},
            text: 'apply'.tr(),
          ),
        AppSpacing.verticalSpace24,
      ],
    );
  }
}
