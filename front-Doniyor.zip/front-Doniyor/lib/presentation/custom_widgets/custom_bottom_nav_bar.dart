import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';

class CustomBottomNavigationBar extends StatefulWidget {
  final ValueChanged<int> onIndexChanged;
  final List<CustomNavigationBarItem> items;
  final Color? backgroundColor;

  const CustomBottomNavigationBar({
    Key? key,
    required this.onIndexChanged,
    required this.items,
    this.backgroundColor,
  }) : super(key: key);

  @override
  _CustomBottomNavigationBarState createState() => _CustomBottomNavigationBarState();
}

class _CustomBottomNavigationBarState extends State<CustomBottomNavigationBar> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 84,
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
        color: widget.backgroundColor ?? Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            offset: Offset(0, 1),
            blurRadius: 1.0,
            spreadRadius: 1.0,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: widget.items.map<Widget>(
          (item) {
            int tappedIndex = widget.items.indexOf(item);
            return GestureDetector(
              onTap: () {
                setState(() => _index = tappedIndex);
                widget.onIndexChanged(tappedIndex);
              },
              child: item.child != null
                  ? item.child
                  : Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SvgPicture.asset(
                          item.icon,
                          color: tappedIndex == _index
                              ? Theme.of(context).bottomNavigationBarTheme.selectedItemColor
                              : Theme.of(context).bottomNavigationBarTheme.unselectedItemColor,
                        ),
                        AppSpacing.verticalSpace12,
                        Container(
                          width: 4,
                          height: 4,
                          decoration: BoxDecoration(
                            color: tappedIndex == _index
                                ? Theme.of(context).bottomNavigationBarTheme.selectedItemColor
                                : Colors.transparent,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ],
                    ),
            );
          },
        ).toList(),
      ),
    );
  }
}

class CustomNavigationBarTab extends StatelessWidget {
  final Widget child;
  final GlobalKey<NavigatorState> navigatorKey;

  const CustomNavigationBarTab({
    Key? key,
    required this.child,
    required this.navigatorKey,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Navigator(
      key: navigatorKey,
      onGenerateRoute: (context) => MaterialPageRoute(builder: (context) => child),
    );
  }
}

class CustomNavigationBarItem {
  final String icon;
  final Widget? child;

  const CustomNavigationBarItem({
    this.icon = '',
    this.child,
  });
}
