import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class ProfileStatCard extends StatelessWidget {
  final double? height;
  final Widget icon, footer;
  final String header;

  const ProfileStatCard({
    Key? key,
    this.height,
    required this.header,
    required this.icon,
    required this.footer,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        color: AppColors.oliveLight,
        borderRadius: AppBorderRadius.borderRadiusAll8,
        border: Border.all(color: AppColors.oliveDark, width: 0.5),
      ),
      padding: AppInsets.insetsAll8,
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            header.toUpperCase(),
            style: TypographyTwCenW01Medium.subtitle2,
          ),
          icon,
          footer,
        ],
      ),
    );
  }
}
