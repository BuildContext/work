import 'package:flutter/material.dart';

class CustomTextField extends StatefulWidget {
  final TextEditingController controller;
  final String? helperText, hintText;
  final String? Function(String?)? validator;
  final TextInputType? keyboardType;
  final void Function(String)? onChanged;
  final int? maxLines;
  final int? minLines;

  CustomTextField({
    Key? key,
    required this.controller,
    this.keyboardType,
    this.onChanged,
    this.helperText,
    this.hintText,
    this.validator,
    this.maxLines,
    this.minLines,
  }) : super(key: key);

  @override
  State<CustomTextField> createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> {
  late bool _hideHelper = widget.controller.text.isEmpty;

  @override
  void initState() {
    super.initState();
    widget.controller.addListener(() {
      setState(() => _hideHelper = widget.controller.text.isEmpty);
    });
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      minLines: widget.minLines,
      maxLines: widget.maxLines,
      controller: widget.controller,
      validator: widget.validator,
      keyboardType: widget.keyboardType,
      onChanged: widget.onChanged,
      decoration: InputDecoration(
        // label: Text(label.toUpperCase()),
        helperText: _hideHelper ? '' : widget.helperText,
        hintText: widget.hintText,
      ),
    );
  }
}
