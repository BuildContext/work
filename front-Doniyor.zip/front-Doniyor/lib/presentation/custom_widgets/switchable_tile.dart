import 'package:flutter/material.dart';
import 'package:test_project/presentation/custom_widgets/app_switch_button.dart';
import 'package:test_project/presentation/theme/typography.dart';

class SwitchableTile extends StatelessWidget {
  final String title;
  final bool isEnabled;

  const SwitchableTile({
    Key? key,
    required this.title,
    required this.isEnabled,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 64,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              title,
              style: TypographyNeueHaasUnicaW1G.basic2,
            ),
          ),
          AppSwitchButton(
            onSwitched: (value) {},
            isEnabled: isEnabled,
          ),
        ],
      ),
    );
  }
}
