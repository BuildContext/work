import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:test_project/presentation/custom_widgets/custom_button.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class QuestionBottomSheet extends StatefulWidget {
  final String question;
  final String description;
  final Widget secondChild;

  const QuestionBottomSheet({
    Key? key,
    required this.question,
    required this.description,
    required this.secondChild,
  }) : super(key: key);

  @override
  State<QuestionBottomSheet> createState() => _QuestionBottomSheetState();
}

class _QuestionBottomSheetState extends State<QuestionBottomSheet> {
  CrossFadeState _crossFadeState = CrossFadeState.showFirst;

  @override
  Widget build(BuildContext context) {
    return AnimatedCrossFade(
      duration: Duration(milliseconds: 250),
      crossFadeState: _crossFadeState,
      firstChild: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(widget.question, style: TypographyTwCenW01Medium.title1),
          AppSpacing.verticalSpace16,
          AppSpacing.verticalSpace16,
          Text(widget.description, style: TypographyNeueHaasUnicaW1G.basic2),
          AppSpacing.verticalSpace20,
          AppSpacing.verticalSpace16,
          CustomButton(
            onTap: () => setState(() => _crossFadeState = CrossFadeState.showSecond),
            text: 'approve'.tr(),
            textStyle: TypographyNeueHaasUnicaW1G.buttonBold,
          ),
          AppSpacing.verticalSpace24,
          CustomButton(
            onTap: () => Navigator.pop(context),
            color: Colors.white,
            text: 'skip'.tr(),
            showBorder: false,
            textStyle: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight),
          ),
        ],
      ),
      secondChild: widget.secondChild,
    );
  }
}
