import 'dart:ui';

import 'package:flutter/material.dart';

class BlurBackBottomSheetContainer extends StatelessWidget {
  final Widget child;
  const BlurBackBottomSheetContainer({
    Key? key,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
      child: Container(
        color: Colors.transparent,
        child: child,
      ),
    );
  }
}
