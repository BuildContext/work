import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:test_project/core/models/post.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class AuthorCard extends StatelessWidget {
  final PostAuthor author;

  const AuthorCard({Key? key, required this.author}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 173,
      width: MediaQuery.of(context).size.width,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Align(
            alignment: Alignment.topLeft,
            child: CachedNetworkImage(
              imageUrl: author.avatar,
              errorWidget: (context, url, trace) => Image.asset('assets/pngs/avatar_placeholder.png'),
              progressIndicatorBuilder: (context, url, progress) => SizedBox(height: 64, width: 64, child: Loader()),
              imageBuilder: (context, imageProvider) => Container(
                height: 64,
                width: 64,
                decoration: BoxDecoration(shape: BoxShape.circle),
                child: Image(image: imageProvider),
              ),
            ),
          ),
          AppSpacing.horizontalSpace16,
          Expanded(
            child: Padding(
              padding: AppInsets.onlyTopInset10,
              child: RichText(
                text: TextSpan(
                  children: [
                    TextSpan(text: author.name, style: TypographyNeueHaasUnicaW1G.basic1),
                    TextSpan(text: '\n'),
                    TextSpan(
                      text: author.position,
                      style: TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.dark.withOpacity(0.5)),
                    ),
                    TextSpan(text: '\n'),
                    TextSpan(text: '\n'),
                    if (author.description.length < 150) TextSpan(text: author.description, style: TypographyNeueHaasUnicaW1G.basic2),
                    if (author.description.length > 150)
                      TextSpan(
                        text: author.description.replaceRange(150, author.description.length, ' ... '),
                        style: TypographyNeueHaasUnicaW1G.basic2,
                      ),
                    if (author.description.length > 150)
                      TextSpan(
                        text: 'More',
                        style: TypographyNeueHaasUnicaW1G.basic2.copyWith(color: AppColors.dark.withOpacity(0.5)),
                        recognizer: TapGestureRecognizer()..onTap = () => print('asc'),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
