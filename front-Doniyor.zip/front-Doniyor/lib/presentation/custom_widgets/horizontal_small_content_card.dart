import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';

class HorizontalSmallContentCard extends StatelessWidget {
  final ContentCategoryItem post;
  final VoidCallback? onLikePressed;
  final VoidCallback onTap;
  final int? calories;
  final String placeholderPath;

  const HorizontalSmallContentCard({
    Key? key,
    required this.post,
    required this.onLikePressed,
    required this.onTap,
    this.calories,
    required this.placeholderPath,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      color: Colors.white,
      child: Container(
        width: 320,
        height: 96,
        margin: AppInsets.onlyRightInset16,
        child: InkWell(
          onTap: () {},
          child: Stack(
            fit: StackFit.passthrough,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CachedNetworkImage(
                    imageUrl: post.imageLink,
                    errorWidget: (context, url, trace) => Image.asset(placeholderPath),
                    progressIndicatorBuilder: (context, url, progress) => SizedBox(height: 96, width: 96, child: Loader()),
                    imageBuilder: (context, imageProvider) => Container(
                      height: 96,
                      width: 96,
                      clipBehavior: Clip.hardEdge,
                      decoration: BoxDecoration(borderRadius: AppBorderRadius.borderRadiusAll6),
                      child: Image(
                        image: imageProvider,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  AppSpacing.horizontalSpace8,
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(
                            child: Padding(
                          padding: AppInsets.onlyRightInset16,
                          child: Text(post.title, style: Theme.of(context).textTheme.subtitle1),
                        )),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: post.icons
                              .map<Widget>((category) => Padding(
                                    padding: AppInsets.onlyRightInset16,
                                    child: category.isLocal
                                        ? SvgPicture.asset('assets/svgs/${category.iconPath}.svg')
                                        : SvgPicture.network(category.iconPath),
                                  ))
                              .toList()
                            ..addAll([
                              Text('${post.time.inMinutes} min', style: AppTheme.timeStyle),
                              AppSpacing.horizontalSpace8,
                              if (calories != null) Text('${calories}kCal', style: AppTheme.timeStyle),
                            ]),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Padding(
                padding: AppInsets.insetsAll16,
                child: Align(alignment: Alignment.topRight, child: Icon(Icons.favorite_border)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
