import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/recipe_category_item.dart';
import 'package:test_project/presentation/custom_widgets/loader.dart';
import 'package:test_project/presentation/custom_widgets/radial_menu.dart';
import 'package:test_project/presentation/pages/ayuplan/widget/ayuplan_menu_sheet.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';
import 'package:test_project/tools/app_interactions_helper.dart';

class MealplanRecipeCard extends StatefulWidget {
  final RecipeCategoryItem recipe;
  final VoidCallback onTap;

  const MealplanRecipeCard({
    Key? key,
    required this.recipe,
    required this.onTap,
  }) : super(key: key);

  @override
  State<MealplanRecipeCard> createState() => _MealplanRecipeCardState();
}

class _MealplanRecipeCardState extends State<MealplanRecipeCard> {
  bool isDisabled = false;
  Offset _tapGlobalOffset = Offset.zero;

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      color: Colors.white,
      child: GestureDetector(
        onTapDown: (tapDetails) => setState(() => _tapGlobalOffset = tapDetails.globalPosition - Offset(24, 75)),
        child: Container(
          margin: AppInsets.onlyRightInset16.copyWith(bottom: 24),
          child: InkWell(
            onTap: widget.onTap,
            onLongPress: () {
              setState(() => isDisabled = true);
              showDialog(
                context: context,
                builder: (context) => RadialMenu(
                  center: _tapGlobalOffset,
                ),
              ).then((value) => setState(() => isDisabled = false));
            },
            child: Ink(
              height: 96,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  CachedNetworkImage(
                    imageUrl: widget.recipe.imageLink,
                    height: 96,
                    width: 96,
                    errorWidget: (context, url, trace) {
                      if (isDisabled)
                        return Image.asset('assets/pngs/recipe_small_disabled_placeholder.png');
                      else
                        return Image.asset('assets/pngs/recipe_small_placeholder.png');
                    },
                    progressIndicatorBuilder: (context, url, progress) => Center(child: Loader()),
                    imageBuilder: (context, imageProvider) => ClipRRect(
                      borderRadius: AppBorderRadius.borderRadiusAll8,
                      child: Image(image: imageProvider),
                    ),
                  ),
                  AppSpacing.horizontalSpace8,
                  Column(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(widget.recipe.title, style: TypographyTwCenW01Medium.subtitle1),
                      AppSpacing.verticalSpace14,
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: widget.recipe.icons
                            .map<Widget>((category) => Padding(
                                  padding: AppInsets.onlyRightInset8,
                                  child: category.isLocal
                                      ? SvgPicture.asset('assets/svgs/${category.iconPath}.svg')
                                      : SvgPicture.network(category.iconPath),
                                ))
                            .toList()
                          ..addAll(
                            [
                              Text('${widget.recipe.time.inMinutes} min', style: AppTheme.timeStyle),
                              AppSpacing.horizontalSpace8,
                              Text('${widget.recipe.calories}kCal', style: AppTheme.timeStyle),
                            ],
                          ),
                      ),
                    ],
                  ),
                  Expanded(child: SizedBox()),
                  IconButton(
                    icon: Icon(Icons.more_vert),
                    onPressed: () => AppInteractionsHelper.showBottomSheet(
                      context: context,
                      child: AyuplanMenuSheet(recipe: widget.recipe),
                      color: Colors.white,
                      barrierColor: AppColors.oliveDark,
                      title: 'actions'.tr(),
                    ),
                    padding: EdgeInsets.zero,
                    constraints: BoxConstraints.loose(Size(20, 20)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
