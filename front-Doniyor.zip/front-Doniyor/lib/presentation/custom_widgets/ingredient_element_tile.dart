import 'package:flutter/material.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';

class FoodItemElementTile extends StatelessWidget {
  final FoodElement element;
  final TextStyle? textStyle;
  final VoidCallback? onOptionsClicked;

  const FoodItemElementTile({Key? key, required this.element, required this.textStyle, this.onOptionsClicked}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    bool hasOptions = onOptionsClicked != null;
    return Padding(
      padding: AppInsets.verticalInsets8,
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(child: Text('${element.title}', style: textStyle)),
          Text('${element.amount.toStringAsFixed(2)}${element.measurementType}', style: textStyle),
          if (hasOptions) AppSpacing.horizontalSpace24,
          if (hasOptions) IconButton(onPressed: () {}, icon: Icon(Icons.more_vert)),
        ],
      ),
    );
  }
}
