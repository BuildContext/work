import 'package:flutter/material.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/presentation/custom_widgets/vertical_small_content_card.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/typography.dart';

class ContentSection extends StatelessWidget {
  final String? title;
  final TextStyle? titleStyle;
  final VoidCallback? onMore;
  final List<Widget> children;
  final List<ContentCategory> subCategories;
  final bool displayTopSpacing;
  final bool displayDivider;
  final Axis scrollDirection;

  const ContentSection({
    Key? key,
    required this.title,
    this.titleStyle,
    this.onMore,
    this.displayDivider = true,
    this.displayTopSpacing = true,
    required this.children,
    this.subCategories = const [],
    this.scrollDirection = Axis.horizontal,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (displayTopSpacing) AppSpacing.verticalSpace24,
        if (displayDivider) Divider(thickness: 0.5),
        if (onMore != null)
          if (title != null)
            Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(title!, style: titleStyle),
                TextButton(onPressed: onMore, child: Text('More', style: TypographyTwCenW01Medium.subtitle2))
              ],
            ),
        if (onMore == null)
          if (title != null) Text(title!, style: titleStyle),
        AppSpacing.verticalSpace24,
        if (scrollDirection == Axis.horizontal)
          SingleChildScrollView(
            scrollDirection: scrollDirection,
            child: Row(mainAxisSize: MainAxisSize.min, children: children),
          ),
        if (scrollDirection == Axis.vertical)
          SingleChildScrollView(
            scrollDirection: scrollDirection,
            child: Column(mainAxisSize: MainAxisSize.min, children: children),
          ),
        if (subCategories.isNotEmpty)
          for (final category in subCategories)
            ContentSection(
              children: category.items
                  .map<Widget>(
                    (e) => VerticalSmallContentCard(
                      placeholderPath: 'assets/pngs/recipe_small_placeholder.png',
                      post: e,
                      onLikePressed: () {},
                      onTap: () {},
                    ),
                  )
                  .toList(),
              titleStyle: TypographyTwCenW01Medium.subtitle2,
              onMore: onMore,
              title: category.categoryName.toUpperCase(),
            ),
      ],
    );
  }
}
