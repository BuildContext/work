import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/typography.dart';

class CustomDropDownButton<T> extends StatefulWidget {
  final List<CustomDropDownOption<T>> items;
  final Color? backgroundColor;
  final void Function(T?) onChanged;

  const CustomDropDownButton({
    Key? key,
    this.backgroundColor,
    required this.items,
    required this.onChanged,
  }) : super(key: key);

  @override
  State<CustomDropDownButton<T>> createState() => _CustomDropDownButtonState<T>();
}

class _CustomDropDownButtonState<T> extends State<CustomDropDownButton<T>> {
  late CustomDropDownOption<T> _selectedItem;

  @override
  void initState() {
    super.initState();
    _selectedItem = widget.items.first;
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      color: widget.backgroundColor ?? Colors.white,
      borderRadius: AppBorderRadius.borderRadiusAll6,
      child: InkWell(
        borderRadius: AppBorderRadius.borderRadiusAll6,
        onTap: () {},
        child: Ink(
          height: 50,
          padding: AppInsets.insetsAll12,
          decoration: BoxDecoration(
            borderRadius: AppBorderRadius.borderRadiusAll6,
            color: widget.backgroundColor ?? Colors.white,
          ),
          child: DropdownButton<T>(
            onChanged: widget.onChanged,
            elevation: 2,
            isExpanded: false,
            underline: SizedBox(),
            borderRadius: AppBorderRadius.borderRadiusAll6,
            dropdownColor: widget.backgroundColor ?? Colors.white,
            value: _selectedItem.value,
            items: widget.items
                .map<DropdownMenuItem<T>>(
                  (e) => DropdownMenuItem<T>(
                    child: Text(
                      e.title,
                      style: TypographyNeueHaasUnicaW1G.basic1,
                    ),
                    value: e.value,
                  ),
                )
                .toList(),
          ),
          // child: Row(
          //   mainAxisSize: MainAxisSize.min,
          //   children: [
          //     Text(_selectedItem.title, style: Theme.of(context).textTheme.subtitle1),
          //     AppSpacing.horizontalSpace24,
          //     PopupMenuButton<String>(
          //       elevation: 1.5,
          //       padding: EdgeInsets.zero,
          //       shape: RoundedRectangleBorder(borderRadius: AppBorderRadius.borderRadiusAll6),
          //       itemBuilder: (context) => widgets.items
          //           .map<PopupMenuItem<String>>((item) => PopupMenuItem<String>(child: Text(item.title), value: item.value.toString()))
          //           .toList(),
          //       onSelected: (value) {},
          //       icon: Icon(Icons.keyboard_arrow_down, color: Colors.black),
          //     ),
          //   ],
          // ),
        ),
      ),
    );
  }
}

class CustomDropDownOption<T> {
  final String title;
  final T value;

  CustomDropDownOption({
    required this.title,
    required this.value,
  });
}
