import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/presentation/theme/app_border_radius.dart';
import 'package:test_project/presentation/theme/app_insets.dart';
import 'package:test_project/presentation/theme/app_spacing.dart';
import 'package:test_project/presentation/theme/app_theme.dart';
import 'package:test_project/presentation/theme/typography.dart';

class TagTile extends StatelessWidget {
  final ContentCategoryTag tag;
  final VoidCallback onTap;

  const TagTile({Key? key, required this.tag, required this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 0,
      color: AppColors.oliveLight,
      shape: RoundedRectangleBorder(
        borderRadius: AppBorderRadius.borderRadiusAll6,
        side: BorderSide(color: AppColors.oliveColor, width: 0.5),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: AppBorderRadius.borderRadiusAll6,
        child: Ink(
          height: 40,
          padding: AppInsets.insetsAll12,
          decoration: BoxDecoration(
            borderRadius: AppBorderRadius.borderRadiusAll6,
            color: AppColors.oliveLight,
          ),
          child: tag.iconLink != null
              ? Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SvgPicture.asset(tag.iconLink!),
                    AppSpacing.horizontalSpace12,
                    Text(tag.title, style: TypographyNeueHaasUnicaW1G.tagline),
                  ],
                )
              : Text(tag.title, style: TypographyNeueHaasUnicaW1G.tagline),
        ),
      ),
    );
  }
}
