import 'package:flutter/cupertino.dart';

class AppSpacing {
  AppSpacing._();

  /// vertical spacing
  static const verticalSpace8 = const SizedBox(height: 8);
  static const verticalSpace10 = const SizedBox(height: 10);
  static const verticalSpace12 = const SizedBox(height: 12);
  static const verticalSpace14 = const SizedBox(height: 14);
  static const verticalSpace16 = const SizedBox(height: 16);
  static const verticalSpace20 = const SizedBox(height: 20);
  static const verticalSpace24 = const SizedBox(height: 24);
  static const verticalSpace30 = const SizedBox(height: 30);

  /// horizontal spacing
  static const horizontalSpace4 = const SizedBox(width: 4);
  static const horizontalSpace8 = const SizedBox(width: 8);
  static const horizontalSpace10 = const SizedBox(width: 10);
  static const horizontalSpace12 = const SizedBox(width: 12);
  static const horizontalSpace16 = const SizedBox(width: 16);
  static const horizontalSpace20 = const SizedBox(width: 20);
  static const horizontalSpace24 = const SizedBox(width: 24);
  static const horizontalSpace30 = const SizedBox(width: 30);
}
