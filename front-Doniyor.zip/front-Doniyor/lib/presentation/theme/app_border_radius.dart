import 'package:flutter/cupertino.dart';

class AppBorderRadius {
  AppBorderRadius._();
  static const BorderRadius borderRadiusOnlyTop16 =
      const BorderRadius.only(topLeft: Radius.circular(16), topRight: Radius.circular(16));

  static const BorderRadius borderRadiusAll6 = const BorderRadius.all(Radius.circular(6));
  static const BorderRadius borderRadiusAll8 = const BorderRadius.all(Radius.circular(8));

  static const BorderRadius enoughToMakeItCircle = const BorderRadius.all(Radius.circular(1000));
}
