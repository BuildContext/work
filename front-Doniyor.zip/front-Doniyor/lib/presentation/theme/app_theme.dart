import 'package:flutter/material.dart';
import 'package:test_project/presentation/theme/typography.dart';

class AppTheme {
  AppTheme._();

  static final lightTheme = ThemeData(
    appBarTheme: AppBarTheme(
      color: Colors.white,
      elevation: 1,
      iconTheme: IconThemeData(size: 24, color: AppColors.darkLight),
      titleTextStyle: TypographyCyrence.header2,
      centerTitle: false,
    ),
    scaffoldBackgroundColor: Colors.white,
    dividerColor: AppColors.greyLight,
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      showSelectedLabels: false,
      showUnselectedLabels: false,
      elevation: 1.0,
      backgroundColor: Colors.white,
      selectedItemColor: AppColors.dark,
      unselectedItemColor: AppColors.darkLight,
    ),
    inputDecorationTheme: InputDecorationTheme(
      labelStyle: TypographyNeueHaasUnicaW1G.caption3,
      errorStyle: TypographyNeueHaasUnicaW1G.caption3.copyWith(color: AppColors.oliveDark),
      hintStyle: TypographyNeueHaasUnicaW1G.caption3,
      helperStyle: TypographyNeueHaasUnicaW1G.caption3,
      border: UnderlineInputBorder(borderSide: BorderSide(color: AppColors.greyLight, width: 0.5)),
      enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: AppColors.darkLight, width: 0.5)),
      errorBorder: UnderlineInputBorder(borderSide: BorderSide(color: AppColors.darkLight, width: 0.5)),
      focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: AppColors.darkLight, width: 0.5)),
      focusedErrorBorder: UnderlineInputBorder(borderSide: BorderSide(color: AppColors.darkLight, width: 0.5)),
      disabledBorder: InputBorder.none,
    ),
    textButtonTheme: TextButtonThemeData(
      style: ButtonStyle(
        padding: MaterialStateProperty.resolveWith((states) => EdgeInsets.zero),
        textStyle:
            MaterialStateProperty.resolveWith((states) => TypographyNeueHaasUnicaW1G.basic3.copyWith(color: AppColors.greyLight)),
        elevation: MaterialStateProperty.resolveWith((states) => 0),
      ),
    ),
  );
  static TextStyle timeStyle = TextStyle(color: AppColors.dark.withOpacity(0.5), fontSize: 8, fontFamily: 'NeueHaasUnica');
}

class AppColors {
  AppColors._();

  static const Color darkLight = const Color(0xff535356);
  static const Color disabledText = const Color(0xff7C7C7E);
  static const Color greyLight = const Color(0xffc4c4c4);

  static const Color dark = const Color(0xff1f1f1f);
  static const Color oliveColor = const Color(0xffDBDDD0);
  static const Color oliveLight = const Color(0xffF7F6F2);
  static const Color oliveDark = const Color(0xffC5C8B3);
  static const Color lavender = const Color(0xffDD9DCA);
  static const Color lavenderInvisible = const Color(0xffF2E3E8);
  static const Color orangeLight = const Color(0xffF7CB85);
  static const Color orangeInvisible = const Color(0xffF7E9CD);
  static const Color ice = const Color(0xff92D8DE);
  static const Color iceInvisible = const Color(0xffE6F0F1);
  static const Color greenLight = const Color(0xff9FB3A2);
  static const Color greenLightInvisible = const Color(0xffDDE2D7);
}
