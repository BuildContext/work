import 'package:flutter/material.dart';

import 'app_theme.dart';

class TypographyCyrence {
  TypographyCyrence._();

  static const TextStyle hengHeader2 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 50,
    fontFamily: 'Cyrene',
    fontWeight: FontWeight.w400,
  );
  static const TextStyle header2 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 32,
    fontFamily: 'Cyrene',
    fontWeight: FontWeight.w400,
  );
}

class TypographyTwCenW01Medium {
  TypographyTwCenW01Medium._();
  static const TextStyle hengHeader2 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 50,
    fontFamily: 'Tw Cen',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle header2 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 40,
    fontFamily: 'Tw Cen',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle title1 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 30,
    fontFamily: 'Tw Cen',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle title2 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 25,
    fontFamily: 'Tw Cen',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle title3 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 22,
    fontFamily: 'Tw Cen',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle subtitle1 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 18,
    fontFamily: 'Tw Cen',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle subtitle2 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 12,
    fontFamily: 'Tw Cen',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle subtitle3 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 10,
    fontFamily: 'Tw Cen',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle caption1 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 16,
    fontFamily: 'Tw Cen',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle caption2 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 12,
    fontFamily: 'Tw Cen',
    fontWeight: FontWeight.w500,
  );
}

class TypographyNeueHaasUnicaW1G {
  TypographyNeueHaasUnicaW1G._();
  static const TextStyle basic1 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 18,
    fontFamily: 'NeueHaasUnicaW1G',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle basic2 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 16,
    fontFamily: 'NeueHaasUnicaW1G',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle basic3 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 12,
    fontFamily: 'NeueHaasUnicaW1G',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle link1 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 18,
    fontFamily: 'NeueHaasUnicaW1G',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle link2 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 15,
    fontFamily: 'NeueHaasUnicaW1G',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle link3 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 12,
    fontFamily: 'NeueHaasUnicaW1G',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle menu1 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 15,
    fontFamily: 'NeueHaasUnicaW1G',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle menu2 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 14,
    fontFamily: 'NeueHaasUnicaW1G',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle menu3 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 10,
    fontFamily: 'NeueHaasUnicaW1G',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle button = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 14,
    fontFamily: 'NeueHaasUnicaW1G',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle buttonBold = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 14,
    fontFamily: 'NeueHaasUnicaW1G',
    fontWeight: FontWeight.bold,
  );
  static const TextStyle tagline = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 12,
    fontFamily: 'NeueHaasUnicaW1G',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle caption3 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 12,
    fontFamily: 'NeueHaasUnicaW1G',
    fontWeight: FontWeight.w500,
  );
  static const TextStyle caption4 = const TextStyle(
    color: AppColors.darkLight,
    fontSize: 6,
    fontFamily: 'NeueHaasUnicaW1G',
    fontWeight: FontWeight.w500,
  );
}
