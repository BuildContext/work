import 'package:flutter/material.dart';

class AppInsets {
  AppInsets._();

  static const bodyPadding = const EdgeInsets.fromLTRB(16, 14, 16, 0);

  static const horizontalInsets4 = const EdgeInsets.symmetric(horizontal: 4);
  static const horizontalInsets8 = const EdgeInsets.symmetric(horizontal: 8);
  static const horizontalInsets12 = const EdgeInsets.symmetric(horizontal: 12);
  static const horizontalInsets16 = const EdgeInsets.symmetric(horizontal: 16);
  static const horizontalInsets24 = const EdgeInsets.symmetric(horizontal: 24);
  static const horizontalInsets28 = const EdgeInsets.symmetric(horizontal: 28);
  static const horizontalInsets36 = const EdgeInsets.symmetric(horizontal: 36);

  static const verticalInsets4 = const EdgeInsets.symmetric(vertical: 4);
  static const verticalInsets8 = const EdgeInsets.symmetric(vertical: 8);
  static const verticalInsets12 = const EdgeInsets.symmetric(vertical: 12);
  static const verticalInsets16 = const EdgeInsets.symmetric(vertical: 16);

  static const insetsOnlyBottom8 = const EdgeInsets.only(bottom: 8);

  static const insetsAll8 = const EdgeInsets.all(8);
  static const insetsAll12 = const EdgeInsets.all(12);
  static const insetsAll16 = const EdgeInsets.all(16);

  static const onlyRightInset8 = const EdgeInsets.only(right: 8);
  static const onlyRightInset16 = const EdgeInsets.only(right: 16);
  static const onlyBottomInset24 = const EdgeInsets.only(bottom: 24);
  static const onlyLeftInset8 = const EdgeInsets.only(left: 8);
  static const onlyLeftInset12 = const EdgeInsets.only(left: 12);
  static const onlyTopInset10 = const EdgeInsets.only(top: 10);
}
