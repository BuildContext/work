import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:test_project/presentation/pages/namaste_page/namaste.dart';

import 'presentation/theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();
  await Firebase.initializeApp();
  runApp(
    EasyLocalization(
      child: MyApp(),
      supportedLocales: [
        Locale('ru', 'RU'),
        Locale('en', 'US'),
      ],
      fallbackLocale: Locale('en', 'US'),
      startLocale: Locale('en', 'US'),
      useFallbackTranslations: true,
      path: 'assets/translations',
      saveLocale: true,
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widgets is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,
      title: 'Ayulife',
      theme: AppTheme.lightTheme,
      themeMode: ThemeMode.light,
      home: NamastePage(),
    );
  }
}
