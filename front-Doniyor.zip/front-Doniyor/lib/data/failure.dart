class RequestFailure {
  final String error;
  final int code;

  RequestFailure({
    required this.error,
    required this.code,
  });
}
