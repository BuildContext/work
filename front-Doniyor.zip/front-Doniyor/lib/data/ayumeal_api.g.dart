// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ayumeal_api.dart';

// **************************************************************************
// RetrofitGenerator
// **************************************************************************

// ignore_for_file: unnecessary_brace_in_string_interps

class _ApiClient implements ApiClient {
  _ApiClient(this._dio, {this.baseUrl}) {
    baseUrl ??= 'http://142.93.161.109:8001/';
  }

  final Dio _dio;

  String? baseUrl;

  @override
  Future<Ingredient> getIngredients(page, pageSize) async {
    const _extra = <String, dynamic>{};
    final queryParameters = <String, dynamic>{r'page': page, r'page_size': pageSize};
    final _headers = <String, dynamic>{};
    final _data = <String, dynamic>{};
    final _result = await _dio.fetch<Map<String, dynamic>>(_setStreamType<Ingredient>(
        Options(method: 'GET', headers: _headers, extra: _extra)
            .compose(_dio.options, 'api/admin/ingredients', queryParameters: queryParameters, data: _data)
            .copyWith(baseUrl: baseUrl ?? _dio.options.baseUrl)));
    final value = Ingredient.fromJson(_result.data!);
    return value;
  }

  @override
  Future<IngredientResult> getIngredientById(ingredientId) async {
    const _extra = <String, dynamic>{};
    final queryParameters = <String, dynamic>{};
    final _headers = <String, dynamic>{};
    final _data = <String, dynamic>{};
    final _result = await _dio.fetch<Map<String, dynamic>>(_setStreamType<IngredientResult>(
        Options(method: 'GET', headers: _headers, extra: _extra)
            .compose(_dio.options, 'api/admin/ingredients/${ingredientId}', queryParameters: queryParameters, data: _data)
            .copyWith(baseUrl: baseUrl ?? _dio.options.baseUrl)));
    final value = IngredientResult.fromJson(_result.data!);
    return value;
  }

  @override
  Future<NewsModel> getNews(page, pageSize) async {
    const _extra = <String, dynamic>{};
    final queryParameters = <String, dynamic>{r'page': page, r'page_size': pageSize};
    final _headers = <String, dynamic>{};
    final _data = <String, dynamic>{};
    final _result = await _dio.fetch<Map<String, dynamic>>(_setStreamType<NewsModel>(
        Options(method: 'GET', headers: _headers, extra: _extra)
            .compose(_dio.options, '/api/admin/news', queryParameters: queryParameters, data: _data)
            .copyWith(baseUrl: baseUrl ?? _dio.options.baseUrl)));
    final value = NewsModel.fromJson(_result.data!);
    return value;
  }

  @override
  Future<NewsResult> getNewsById(id) async {
    const _extra = <String, dynamic>{};
    final queryParameters = <String, dynamic>{};
    final _headers = <String, dynamic>{};
    final _data = <String, dynamic>{};
    final _result = await _dio.fetch<Map<String, dynamic>>(_setStreamType<NewsResult>(
        Options(method: 'GET', headers: _headers, extra: _extra)
            .compose(_dio.options, 'api/admin/news/${id}', queryParameters: queryParameters, data: _data)
            .copyWith(baseUrl: baseUrl ?? _dio.options.baseUrl)));
    final value = NewsResult.fromJson(_result.data!);
    return value;
  }

  @override
  Future<RecipeModel> getRecipes(page, pageSize) async {
    const _extra = <String, dynamic>{};
    final queryParameters = <String, dynamic>{r'page': page, r'page_size': pageSize};
    final _headers = <String, dynamic>{};
    final _data = <String, dynamic>{};
    final _result = await _dio.fetch<Map<String, dynamic>>(_setStreamType<RecipeModel>(
        Options(method: 'GET', headers: _headers, extra: _extra)
            .compose(_dio.options, 'api/admin/recipes', queryParameters: queryParameters, data: _data)
            .copyWith(baseUrl: baseUrl ?? _dio.options.baseUrl)));
    final value = RecipeModel.fromJson(_result.data!);
    return value;
  }

  RequestOptions _setStreamType<T>(RequestOptions requestOptions) {
    if (T != dynamic && !(requestOptions.responseType == ResponseType.bytes || requestOptions.responseType == ResponseType.stream)) {
      if (T == String) {
        requestOptions.responseType = ResponseType.plain;
      } else {
        requestOptions.responseType = ResponseType.json;
      }
    }
    return requestOptions;
  }
}
