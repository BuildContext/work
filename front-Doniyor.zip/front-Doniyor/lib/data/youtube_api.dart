import 'package:dio/dio.dart';
import 'package:retrofit/http.dart';
import 'package:test_project/core/models/youtube_video_details.dart';

part 'youtube_api.g.dart';

@RestApi(baseUrl: 'https://www.youtube.com/')
abstract class YoutubeApi {
  static YoutubeApi get instance => _YoutubeApi(_dio);

  static final Dio _dio = Dio()
    ..interceptors.add(LogInterceptor(responseBody: true))
    ..options = BaseOptions(headers: {});

  @GET('oembed')
  Future<YoutubeVideoDetails> getYoutubeVideoData(
    @Query('url') String url,
  );
}
