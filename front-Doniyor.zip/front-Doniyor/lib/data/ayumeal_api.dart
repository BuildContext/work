import 'package:dio/dio.dart';
import 'package:retrofit/http.dart';
import 'package:test_project/core/models/ingredient.dart';
import 'package:test_project/core/models/news_model.dart';
import 'package:test_project/core/models/recipe_model.dart';

part 'ayumeal_api.g.dart';

@RestApi(baseUrl: 'http://142.93.161.109:8001/')
abstract class ApiClient {
  static ApiClient get instance => _ApiClient(_dio);

  static final Dio _dio = Dio()
    ..interceptors.add(LogInterceptor(responseBody: true))
    ..options = BaseOptions(headers: {});

  @GET('api/admin/ingredients')
  Future<Ingredient> getIngredients(
    @Query('page') int page,
    @Query('page_size') int pageSize,
  );

  @GET('api/admin/ingredients/{id}')
  Future<IngredientResult> getIngredientById(
    @Path('id') String ingredientId,
  );

  @GET('/api/admin/news')
  Future<NewsModel> getNews(
    @Query('page') int page,
    @Query('page_size') int pageSize,
  );

  @GET('api/admin/news/{id}')
  Future<NewsResult> getNewsById(
    @Path('id') String id,
  );

  @GET('api/admin/recipes')
  Future<RecipeModel> getRecipes(
    @Query('page') int page,
    @Query('page_size') int pageSize,
  );
}
