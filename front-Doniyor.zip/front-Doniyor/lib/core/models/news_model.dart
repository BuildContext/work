class NewsModel {
  NewsModel({
    this.count,
    this.totalPages,
    this.next,
    this.previous,
    this.results,
  });

  NewsModel.fromJson(dynamic json) {
    count = json['count'];
    totalPages = json['total_pages'];
    next = json['next'];
    previous = json['previous'];
    if (json['results'] != null) {
      results = [];
      json['results'].forEach((v) {
        results?.add(NewsResult.fromJson(v));
      });
    }
  }
  int? count;
  int? totalPages;
  dynamic next;
  dynamic previous;
  List<NewsResult>? results;
  NewsModel copyWith({
    int? count,
    int? totalPages,
    dynamic next,
    dynamic previous,
    List<NewsResult>? results,
  }) =>
      NewsModel(
        count: count ?? this.count,
        totalPages: totalPages ?? this.totalPages,
        next: next ?? this.next,
        previous: previous ?? this.previous,
        results: results ?? this.results,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['count'] = count;
    map['total_pages'] = totalPages;
    map['next'] = next;
    map['previous'] = previous;
    if (results != null) {
      map['results'] = results?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

class NewsResult {
  NewsResult({
    this.youtubeLink,
    this.timeToRead,
    this.tags,
    this.category,
    this.imageUrl,
    this.text,
    this.title,
    this.id,
    this.isRecommended,
  });

  NewsResult.fromJson(dynamic json) {
    youtubeLink = json['youtube_link'];
    timeToRead = json['time_to_read'];
    if (json['tags'] != null) {
      tags = [];
      json['tags'].forEach((v) {
        tags?.add(Tags.fromJson(v));
      });
    }
    category = json['category'];
    imageUrl = json['image_url'];
    text = json['text'];
    title = json['title'];
    id = json['id'];
    isRecommended = json['is_recommended'];
  }
  String? youtubeLink;
  String? timeToRead;
  List<Tags>? tags;
  String? category;
  String? imageUrl;
  String? text;
  String? title;
  String? id;
  bool? isRecommended;
  NewsResult copyWith({
    String? youtubeLink,
    String? timeToRead,
    List<Tags>? tags,
    String? category,
    dynamic imageUrl,
    String? text,
    String? title,
    String? id,
    bool? isRecommended,
  }) =>
      NewsResult(
        youtubeLink: youtubeLink ?? this.youtubeLink,
        timeToRead: timeToRead ?? this.timeToRead,
        tags: tags ?? this.tags,
        category: category ?? this.category,
        imageUrl: imageUrl ?? this.imageUrl,
        text: text ?? this.text,
        title: title ?? this.title,
        id: id ?? this.id,
        isRecommended: isRecommended ?? this.isRecommended,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['youtube_link'] = youtubeLink;
    map['time_to_read'] = timeToRead;
    if (tags != null) {
      map['tags'] = tags?.map((v) => v.toJson()).toList();
    }
    map['category'] = category;
    map['image_url'] = imageUrl;
    map['text'] = text;
    map['title'] = title;
    map['id'] = id;
    map['is_recommended'] = isRecommended;
    return map;
  }
}

class Tags {
  Tags({
    this.name,
    this.isMain,
  });

  Tags.fromJson(dynamic json) {
    name = json['name'];
    isMain = json['is_main'];
  }
  String? name;
  bool? isMain;
  Tags copyWith({
    String? name,
    bool? isMain,
  }) =>
      Tags(
        name: name ?? this.name,
        isMain: isMain ?? this.isMain,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = name;
    map['is_main'] = isMain;
    return map;
  }
}
