class RecipeModel {
  RecipeModel({
    this.count,
    this.totalPages,
    this.next,
    this.previous,
    this.results,
  });

  RecipeModel.fromJson(dynamic json) {
    count = json['count'];
    totalPages = json['total_pages'];
    next = json['next'];
    previous = json['previous'];
    if (json['results'] != null) {
      results = [];
      json['results'].forEach((v) {
        results?.add(RecipeResult.fromJson(v));
      });
    }
  }
  int? count;
  int? totalPages;
  dynamic next;
  dynamic previous;
  List<RecipeResult>? results;
  RecipeModel copyWith({
    int? count,
    int? totalPages,
    dynamic next,
    dynamic previous,
    List<RecipeResult>? results,
  }) =>
      RecipeModel(
        count: count ?? this.count,
        totalPages: totalPages ?? this.totalPages,
        next: next ?? this.next,
        previous: previous ?? this.previous,
        results: results ?? this.results,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['count'] = count;
    map['total_pages'] = totalPages;
    map['next'] = next;
    map['previous'] = previous;
    if (results != null) {
      map['results'] = results?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

class RecipeResult {
  RecipeResult({
    this.title,
    this.image,
    this.description,
    this.nutrionalFacts,
    this.preparationTime,
    this.cookingTime,
    this.cookingSteps,
    this.ingredients,
    this.typeOfDish,
    this.ayurveda,
    this.mealTiming,
    this.seasons,
    this.goodForDisease,
    this.goodForDoshaType,
    this.goodForAgni,
    this.goodForPhysiology,
    this.goodForPhysicalActivity,
    this.goodForMindGunas,
    this.badForDisease,
    this.badForDoshaType,
    this.badForAgni,
    this.badForPhysiology,
    this.badForPhysicalActivity,
    this.badForMindGunas,
    this.cuisineStyle,
    this.regionalCuisine,
    this.id,
  });

  RecipeResult.fromJson(dynamic json) {
    title = json['title'];
    image = json['image'];
    description = json['description'];
    nutrionalFacts = json['nutrional_facts'];
    preparationTime = json['preparation_time'];
    cookingTime = json['cooking_time'];
    cookingSteps = json['cooking_steps'] != null ? json['cooking_steps'].cast<String>() : [];
    if (json['ingredients'] != null) {
      ingredients = [];
      json['ingredients'].forEach((v) {
        ingredients?.add(RecipeIngredient.fromJson(v));
      });
    }
    if (json['type_of_dish'] != null) {
      typeOfDish = [];
      json['type_of_dish'].forEach((v) {
        typeOfDish?.add(RecipeTypeOfDish.fromJson(v));
      });
    }
    if (json['ayurveda'] != null) {
      ayurveda = [];
      json['ayurveda'].forEach((v) {
        ayurveda?.add(RecipeAyurveda.fromJson(v));
      });
    }
    if (json['meal_timing'] != null) {
      mealTiming = [];
      json['meal_timing'].forEach((v) {
        mealTiming?.add(RecipeMealTiming.fromJson(v));
      });
    }
    if (json['seasons'] != null) {
      seasons = [];
      json['seasons'].forEach((v) {
        seasons?.add(RecipeSeasons.fromJson(v));
      });
    }
    if (json['good_for_disease'] != null) {
      goodForDisease = [];
      json['good_for_disease'].forEach((v) {
        goodForDisease?.add(GoodForDisease.fromJson(v));
      });
    }
    if (json['good_for_dosha_type'] != null) {
      goodForDoshaType = [];
      json['good_for_dosha_type'].forEach((v) {
        goodForDoshaType?.add(GoodForDoshaType.fromJson(v));
      });
    }
    if (json['good_for_agni'] != null) {
      goodForAgni = [];
      json['good_for_agni'].forEach((v) {
        goodForAgni?.add(GoodForAgni.fromJson(v));
      });
    }
    if (json['good_for_physiology'] != null) {
      goodForPhysiology = [];
      json['good_for_physiology'].forEach((v) {
        goodForPhysiology?.add(GoodForPhysiology.fromJson(v));
      });
    }
    if (json['good_for_physical_activity'] != null) {
      goodForPhysicalActivity = [];
      json['good_for_physical_activity'].forEach((v) {
        goodForPhysicalActivity?.add(GoodForPhysicalActivity.fromJson(v));
      });
    }
    if (json['good_for_mind_gunas'] != null) {
      goodForMindGunas = [];
      json['good_for_mind_gunas'].forEach((v) {
        goodForMindGunas?.add(GoodForMindGunas.fromJson(v));
      });
    }
    if (json['bad_for_disease'] != null) {
      badForDisease = [];
      json['bad_for_disease'].forEach((v) {
        badForDisease?.add(BadForDisease.fromJson(v));
      });
    }
    if (json['bad_for_dosha_type'] != null) {
      badForDoshaType = [];
      json['bad_for_dosha_type'].forEach((v) {
        badForDoshaType?.add(BadForDoshaType.fromJson(v));
      });
    }
    if (json['bad_for_agni'] != null) {
      badForAgni = [];
      json['bad_for_agni'].forEach((v) {
        badForAgni?.add(BadForAgni.fromJson(v));
      });
    }
    if (json['bad_for_physiology'] != null) {
      badForPhysiology = [];
      json['bad_for_physiology'].forEach((v) {
        badForPhysiology?.add(BadForPhysiology.fromJson(v));
      });
    }
    if (json['bad_for_physical_activity'] != null) {
      badForPhysicalActivity = [];
      json['bad_for_physical_activity'].forEach((v) {
        badForPhysicalActivity?.add(BadForPhysicalActivity.fromJson(v));
      });
    }
    if (json['bad_for_mind_gunas'] != null) {
      badForMindGunas = [];
      json['bad_for_mind_gunas'].forEach((v) {
        badForMindGunas?.add(BadForMindGunas.fromJson(v));
      });
    }
    if (json['cuisine_style'] != null) {
      cuisineStyle = [];
      json['cuisine_style'].forEach((v) {
        cuisineStyle?.add(CuisineStyle.fromJson(v));
      });
    }
    if (json['regional_cuisine'] != null) {
      regionalCuisine = [];
      json['regional_cuisine'].forEach((v) {
        regionalCuisine?.add(RegionalCuisine.fromJson(v));
      });
    }
    id = json['id'];
  }
  String? title;
  String? image;
  String? description;
  String? nutrionalFacts;
  String? preparationTime;
  String? cookingTime;
  List<String>? cookingSteps;
  List<RecipeIngredient>? ingredients;
  List<RecipeTypeOfDish>? typeOfDish;
  List<RecipeAyurveda>? ayurveda;
  List<RecipeMealTiming>? mealTiming;
  List<RecipeSeasons>? seasons;
  List<GoodForDisease>? goodForDisease;
  List<GoodForDoshaType>? goodForDoshaType;
  List<GoodForAgni>? goodForAgni;
  List<GoodForPhysiology>? goodForPhysiology;
  List<GoodForPhysicalActivity>? goodForPhysicalActivity;
  List<GoodForMindGunas>? goodForMindGunas;
  List<BadForDisease>? badForDisease;
  List<BadForDoshaType>? badForDoshaType;
  List<BadForAgni>? badForAgni;
  List<BadForPhysiology>? badForPhysiology;
  List<BadForPhysicalActivity>? badForPhysicalActivity;
  List<BadForMindGunas>? badForMindGunas;
  List<CuisineStyle>? cuisineStyle;
  List<RegionalCuisine>? regionalCuisine;
  String? id;
  RecipeResult copyWith({
    String? title,
    String? image,
    String? description,
    String? nutrionalFacts,
    String? preparationTime,
    String? cookingTime,
    List<String>? cookingSteps,
    List<RecipeIngredient>? ingredients,
    List<RecipeTypeOfDish>? typeOfDish,
    List<RecipeAyurveda>? ayurveda,
    List<RecipeMealTiming>? mealTiming,
    List<RecipeSeasons>? seasons,
    List<GoodForDisease>? goodForDisease,
    List<GoodForDoshaType>? goodForDoshaType,
    List<GoodForAgni>? goodForAgni,
    List<GoodForPhysiology>? goodForPhysiology,
    List<GoodForPhysicalActivity>? goodForPhysicalActivity,
    List<GoodForMindGunas>? goodForMindGunas,
    List<BadForDisease>? badForDisease,
    List<BadForDoshaType>? badForDoshaType,
    List<BadForAgni>? badForAgni,
    List<BadForPhysiology>? badForPhysiology,
    List<BadForPhysicalActivity>? badForPhysicalActivity,
    List<BadForMindGunas>? badForMindGunas,
    List<CuisineStyle>? cuisineStyle,
    List<RegionalCuisine>? regionalCuisine,
    String? id,
  }) =>
      RecipeResult(
        title: title ?? this.title,
        image: image ?? this.image,
        description: description ?? this.description,
        nutrionalFacts: nutrionalFacts ?? this.nutrionalFacts,
        preparationTime: preparationTime ?? this.preparationTime,
        cookingTime: cookingTime ?? this.cookingTime,
        cookingSteps: cookingSteps ?? this.cookingSteps,
        ingredients: ingredients ?? this.ingredients,
        typeOfDish: typeOfDish ?? this.typeOfDish,
        ayurveda: ayurveda ?? this.ayurveda,
        mealTiming: mealTiming ?? this.mealTiming,
        seasons: seasons ?? this.seasons,
        goodForDisease: goodForDisease ?? this.goodForDisease,
        goodForDoshaType: goodForDoshaType ?? this.goodForDoshaType,
        goodForAgni: goodForAgni ?? this.goodForAgni,
        goodForPhysiology: goodForPhysiology ?? this.goodForPhysiology,
        goodForPhysicalActivity: goodForPhysicalActivity ?? this.goodForPhysicalActivity,
        goodForMindGunas: goodForMindGunas ?? this.goodForMindGunas,
        badForDisease: badForDisease ?? this.badForDisease,
        badForDoshaType: badForDoshaType ?? this.badForDoshaType,
        badForAgni: badForAgni ?? this.badForAgni,
        badForPhysiology: badForPhysiology ?? this.badForPhysiology,
        badForPhysicalActivity: badForPhysicalActivity ?? this.badForPhysicalActivity,
        badForMindGunas: badForMindGunas ?? this.badForMindGunas,
        cuisineStyle: cuisineStyle ?? this.cuisineStyle,
        regionalCuisine: regionalCuisine ?? this.regionalCuisine,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['image'] = image;
    map['description'] = description;
    map['nutrional_facts'] = nutrionalFacts;
    map['preparation_time'] = preparationTime;
    map['cooking_time'] = cookingTime;
    map['cooking_steps'] = cookingSteps;
    if (ingredients != null) {
      map['ingredients'] = ingredients?.map((v) => v.toJson()).toList();
    }
    if (typeOfDish != null) {
      map['type_of_dish'] = typeOfDish?.map((v) => v.toJson()).toList();
    }
    if (ayurveda != null) {
      map['ayurveda'] = ayurveda?.map((v) => v.toJson()).toList();
    }
    if (mealTiming != null) {
      map['meal_timing'] = mealTiming?.map((v) => v.toJson()).toList();
    }
    if (seasons != null) {
      map['seasons'] = seasons?.map((v) => v.toJson()).toList();
    }
    if (goodForDisease != null) {
      map['good_for_disease'] = goodForDisease?.map((v) => v.toJson()).toList();
    }
    if (goodForDoshaType != null) {
      map['good_for_dosha_type'] = goodForDoshaType?.map((v) => v.toJson()).toList();
    }
    if (goodForAgni != null) {
      map['good_for_agni'] = goodForAgni?.map((v) => v.toJson()).toList();
    }
    if (goodForPhysiology != null) {
      map['good_for_physiology'] = goodForPhysiology?.map((v) => v.toJson()).toList();
    }
    if (goodForPhysicalActivity != null) {
      map['good_for_physical_activity'] = goodForPhysicalActivity?.map((v) => v.toJson()).toList();
    }
    if (goodForMindGunas != null) {
      map['good_for_mind_gunas'] = goodForMindGunas?.map((v) => v.toJson()).toList();
    }
    if (badForDisease != null) {
      map['bad_for_disease'] = badForDisease?.map((v) => v.toJson()).toList();
    }
    if (badForDoshaType != null) {
      map['bad_for_dosha_type'] = badForDoshaType?.map((v) => v.toJson()).toList();
    }
    if (badForAgni != null) {
      map['bad_for_agni'] = badForAgni?.map((v) => v.toJson()).toList();
    }
    if (badForPhysiology != null) {
      map['bad_for_physiology'] = badForPhysiology?.map((v) => v.toJson()).toList();
    }
    if (badForPhysicalActivity != null) {
      map['bad_for_physical_activity'] = badForPhysicalActivity?.map((v) => v.toJson()).toList();
    }
    if (badForMindGunas != null) {
      map['bad_for_mind_gunas'] = badForMindGunas?.map((v) => v.toJson()).toList();
    }
    if (cuisineStyle != null) {
      map['cuisine_style'] = cuisineStyle?.map((v) => v.toJson()).toList();
    }
    if (regionalCuisine != null) {
      map['regional_cuisine'] = regionalCuisine?.map((v) => v.toJson()).toList();
    }
    map['id'] = id;
    return map;
  }
}

class RegionalCuisine {
  RegionalCuisine({
    this.title,
    this.id,
  });

  RegionalCuisine.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  RegionalCuisine copyWith({
    String? title,
    String? id,
  }) =>
      RegionalCuisine(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class CuisineStyle {
  CuisineStyle({
    this.title,
    this.id,
  });

  CuisineStyle.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  CuisineStyle copyWith({
    String? title,
    String? id,
  }) =>
      CuisineStyle(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class BadForMindGunas {
  BadForMindGunas({
    this.title,
    this.id,
  });

  BadForMindGunas.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  BadForMindGunas copyWith({
    String? title,
    String? id,
  }) =>
      BadForMindGunas(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class BadForPhysicalActivity {
  BadForPhysicalActivity({
    this.title,
    this.id,
  });

  BadForPhysicalActivity.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  BadForPhysicalActivity copyWith({
    String? title,
    String? id,
  }) =>
      BadForPhysicalActivity(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class BadForPhysiology {
  BadForPhysiology({
    this.title,
    this.id,
  });

  BadForPhysiology.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  BadForPhysiology copyWith({
    String? title,
    String? id,
  }) =>
      BadForPhysiology(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class BadForAgni {
  BadForAgni({
    this.title,
    this.id,
  });

  BadForAgni.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  BadForAgni copyWith({
    String? title,
    String? id,
  }) =>
      BadForAgni(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class BadForDoshaType {
  BadForDoshaType({
    this.title,
    this.id,
  });

  BadForDoshaType.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  BadForDoshaType copyWith({
    String? title,
    String? id,
  }) =>
      BadForDoshaType(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class BadForDisease {
  BadForDisease({
    this.title,
    this.id,
  });

  BadForDisease.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  BadForDisease copyWith({
    String? title,
    String? id,
  }) =>
      BadForDisease(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class GoodForMindGunas {
  GoodForMindGunas({
    this.title,
    this.id,
  });

  GoodForMindGunas.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  GoodForMindGunas copyWith({
    String? title,
    String? id,
  }) =>
      GoodForMindGunas(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class GoodForPhysicalActivity {
  GoodForPhysicalActivity({
    this.title,
    this.id,
  });

  GoodForPhysicalActivity.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  GoodForPhysicalActivity copyWith({
    String? title,
    String? id,
  }) =>
      GoodForPhysicalActivity(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class GoodForPhysiology {
  GoodForPhysiology({
    this.title,
    this.id,
  });

  GoodForPhysiology.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  GoodForPhysiology copyWith({
    String? title,
    String? id,
  }) =>
      GoodForPhysiology(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class GoodForAgni {
  GoodForAgni({
    this.title,
    this.id,
  });

  GoodForAgni.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  GoodForAgni copyWith({
    String? title,
    String? id,
  }) =>
      GoodForAgni(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class GoodForDoshaType {
  GoodForDoshaType({
    this.title,
    this.id,
  });

  GoodForDoshaType.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  GoodForDoshaType copyWith({
    String? title,
    String? id,
  }) =>
      GoodForDoshaType(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class GoodForDisease {
  GoodForDisease({
    this.title,
    this.id,
  });

  GoodForDisease.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  GoodForDisease copyWith({
    String? title,
    String? id,
  }) =>
      GoodForDisease(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class RecipeSeasons {
  RecipeSeasons({
    this.title,
    this.id,
  });

  RecipeSeasons.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  RecipeSeasons copyWith({
    String? title,
    String? id,
  }) =>
      RecipeSeasons(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class RecipeMealTiming {
  RecipeMealTiming({
    this.title,
    this.id,
  });

  RecipeMealTiming.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  RecipeMealTiming copyWith({
    String? title,
    String? id,
  }) =>
      RecipeMealTiming(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class RecipeAyurveda {
  RecipeAyurveda({
    this.title,
    this.id,
  });

  RecipeAyurveda.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  RecipeAyurveda copyWith({
    String? title,
    String? id,
  }) =>
      RecipeAyurveda(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class RecipeTypeOfDish {
  RecipeTypeOfDish({
    this.title,
    this.id,
  });

  RecipeTypeOfDish.fromJson(dynamic json) {
    title = json['title'];
    id = json['id'];
  }
  String? title;
  String? id;
  RecipeTypeOfDish copyWith({
    String? title,
    String? id,
  }) =>
      RecipeTypeOfDish(
        title: title ?? this.title,
        id: id ?? this.id,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['id'] = id;
    return map;
  }
}

class RecipeIngredient {
  RecipeIngredient({
    this.ingredient,
    this.unit,
    this.type,
    this.id,
    this.quantity,
  });

  RecipeIngredient.fromJson(dynamic json) {
    ingredient = json['ingredient'];
    unit = json['unit'];
    type = json['type'];
    id = json['id'];
    quantity = json['quantity'];
  }
  String? ingredient;
  String? unit;
  String? type;
  String? id;
  double? quantity;
  RecipeIngredient copyWith({
    String? ingredient,
    String? unit,
    String? type,
    String? id,
    double? quantity,
  }) =>
      RecipeIngredient(
        ingredient: ingredient ?? this.ingredient,
        unit: unit ?? this.unit,
        type: type ?? this.type,
        id: id ?? this.id,
        quantity: quantity ?? this.quantity,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['ingredient'] = ingredient;
    map['unit'] = unit;
    map['type'] = type;
    map['id'] = id;
    map['quantity'] = quantity;
    return map;
  }
}
