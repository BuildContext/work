class PainPointModel {
  final String title;
  final int levelOfDiscomfort;
  final int frequency;

  PainPointModel({
    required this.title,
    required this.levelOfDiscomfort,
    required this.frequency,
  });
}
