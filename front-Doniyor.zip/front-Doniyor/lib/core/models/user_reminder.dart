import 'package:flutter/material.dart';

class UserReminder {
  final String title;
  final String type;
  final TimeOfDay time;
  final bool isEnabled;
  final List<int> enabledWeekDays;

  UserReminder({
    required this.title,
    required this.type,
    required this.time,
    required this.isEnabled,
    required this.enabledWeekDays,
  });
}
