class SuggestedTitle {
  final String title;

  SuggestedTitle({
    required this.title,
  });
}
