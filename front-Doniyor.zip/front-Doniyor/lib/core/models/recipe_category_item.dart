import 'package:test_project/core/models/abstractions.dart';

class RecipeCategoryItem extends ContentCategoryItem {
  final int calories;
  final int salt;
  final int fibre;
  final bool isAdded;
  final List<ContentCategoryTag> goodFor;
  final List<ContentCategoryTag> badFor;
  final List<RecipeStep> steps;
  final String stepsTitle;
  final String description;
  final double fats;
  final double carbohydrates;
  final double protein;
  final List<FoodElement> fatsList;
  final List<FoodElement> carbohydratesList;
  final List<FoodElement> primaryIngredients;
  final List<FoodElement> secondaryIngredients;

  int get numberOfSteps => steps.length;

  RecipeCategoryItem({
    required this.calories,
    required this.description,
    required this.salt,
    required this.isAdded,
    required this.fibre,
    required this.primaryIngredients,
    required this.secondaryIngredients,
    required this.goodFor,
    required this.badFor,
    required this.steps,
    required this.stepsTitle,
    required this.fats,
    required this.fatsList,
    required this.carbohydrates,
    required this.carbohydratesList,
    required this.protein,
    required String title,
    required bool isLiked,
    required Duration time,
    required String categoryName,
    required String id,
    required List<ContentCategoryIcon> icons,
    required String imageLink,
  }) : super(
          id: id,
          title: title,
          time: time,
          categoryName: categoryName,
          goodFor: goodFor,
          icons: icons,
          imageLink: imageLink,
        );
}

class RecipeStep {
  final String title;
  final String description;
  final int stepOrderNumber;
  final int secondsToComplete;
  final int temperature;
  final List<FoodElement> ingredients;

  RecipeStep({
    required this.stepOrderNumber,
    this.secondsToComplete = 0,
    this.temperature = 0,
    required this.title,
    required this.description,
    required this.ingredients,
  });

  bool get needsHeatTreatment => secondsToComplete > 0 && temperature > 0;
}
