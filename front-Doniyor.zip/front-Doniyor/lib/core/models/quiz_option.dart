abstract class QuizOption {
  final String title;
  final String value;

  QuizOption({
    required this.title,
    required this.value,
  });
}

class SelectableQuizOption extends QuizOption {
  final bool isSelected;

  SelectableQuizOption({
    required this.isSelected,
    required String title,
    required String value,
  }) : super(title: title, value: value);
}
