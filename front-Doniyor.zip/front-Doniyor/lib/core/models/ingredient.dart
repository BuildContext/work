class Ingredient {
  Ingredient({
    this.count,
    this.totalPages,
    this.next,
    this.previous,
    this.results,
  });

  Ingredient.fromJson(dynamic json) {
    count = json['count'];
    totalPages = json['total_pages'];
    next = json['next'];
    previous = json['previous'];
    if (json['results'] != null) {
      results = [];
      json['results'].forEach((v) {
        results?.add(IngredientResult.fromJson(v));
      });
    }
  }
  int? count;
  int? totalPages;
  dynamic next;
  dynamic previous;
  List<IngredientResult>? results;
  Ingredient copyWith({
    int? count,
    int? totalPages,
    dynamic next,
    dynamic previous,
    List<IngredientResult>? results,
  }) =>
      Ingredient(
        count: count ?? this.count,
        totalPages: totalPages ?? this.totalPages,
        next: next ?? this.next,
        previous: previous ?? this.previous,
        results: results ?? this.results,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['count'] = count;
    map['total_pages'] = totalPages;
    map['next'] = next;
    map['previous'] = previous;
    if (results != null) {
      map['results'] = results?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

class IngredientResult {
  IngredientResult({
    this.nutrients,
    this.hasPurines,
    this.goodFor,
    this.ageGroup,
    this.regionalCommonFood,
    this.badFor,
    this.usedPart,
    this.energy,
    this.imageUrl,
    this.classificationType,
    this.taste,
    this.goodForDay,
    this.isVegeterian,
    this.goodForNight,
    this.hasGluten,
    this.description,
    this.actions,
    this.title,
    this.id,
    this.body,
  });

  IngredientResult.fromJson(dynamic json) {
    if (json['nutrients'] != null) {
      nutrients = [];
      json['nutrients'].forEach((v) {
        nutrients?.add(Nutrient.fromJson(v));
      });
    }
    hasPurines = json['has_purines'];
    if (json['good_for'] != null) {
      goodFor = [];
      json['good_for'].forEach((v) {
        goodFor?.add(GoodFor.fromJson(v));
      });
    }
    ageGroup = json['age_group'] != null ? AgeGroup.fromJson(json['age_group']) : null;
    regionalCommonFood = json['regional_common_food'] != null ? RegionalCommonFood.fromJson(json['regional_common_food']) : null;
    if (json['bad_for'] != null) {
      badFor = [];
      json['bad_for'].forEach((v) {
        badFor?.add(BadFor.fromJson(v));
      });
    }
    usedPart = json['used_part'];
    energy = json['energy'];
    imageUrl = json['image_url'];
    classificationType = json['classification_type'] != null ? ClassificationType.fromJson(json['classification_type']) : null;
    taste = json['taste'] != null ? Taste.fromJson(json['taste']) : null;
    goodForDay = json['good_for_day'];
    isVegeterian = json['is_vegeterian'];
    goodForNight = json['good_for_night'];
    hasGluten = json['has_gluten'];
    description = json['description'];
    if (json['actions'] != null) {
      actions = [];
      json['actions'].forEach((v) {
        actions?.add(Actions.fromJson(v));
      });
    }
    title = json['title'];
    id = json['id'];
    body = json['body'];
  }
  List<Nutrient>? nutrients;
  bool? hasPurines;
  List<GoodFor>? goodFor;
  AgeGroup? ageGroup;
  RegionalCommonFood? regionalCommonFood;
  List<BadFor>? badFor;
  String? usedPart;
  int? energy;
  String? imageUrl;
  ClassificationType? classificationType;
  Taste? taste;
  bool? goodForDay;
  bool? isVegeterian;
  bool? goodForNight;
  bool? hasGluten;
  String? description;
  List<Actions>? actions;
  String? title;
  String? id;
  String? body;

  List<Nutrient> get minerals =>
      nutrients
          ?.where(
            (element) => element.nutrientType == 'mineral',
          )
          .toList() ??
      [];

  List<Nutrient> get vitamins =>
      nutrients
          ?.where(
            (element) => element.nutrientType == 'vitamin',
          )
          .toList() ??
      [];

  double? getProteinAmount() {
    double sum = 0;
    final proteins = nutrients?.where((element) => element.nutrientType == 'protein').toList() ?? [];
    if (proteins.isEmpty) return 0;
    for (final protein in proteins) {
      sum += protein.amount ?? 0;
    }
    return sum;
  }

  List<Nutrient> get carbohydrates =>
      nutrients
          ?.where(
            (element) => element.nutrientType == 'carbohydrate',
          )
          .toList() ??
      [];

  List<Nutrient> get fats =>
      nutrients
          ?.where(
            (element) => element.nutrientType == 'fat',
          )
          .toList() ??
      [];

  List<Nutrient> get others =>
      nutrients
          ?.where(
            (element) => element.nutrientType == 'other',
          )
          .toList() ??
      [];
  List<Nutrient> get proteins =>
      nutrients
          ?.where(
            (element) => element.nutrientType == 'protein',
          )
          .toList() ??
      [];

  IngredientResult copyWith({
    List<Nutrient>? nutrients,
    bool? hasPurines,
    List<GoodFor>? goodFor,
    AgeGroup? ageGroup,
    RegionalCommonFood? regionalCommonFood,
    List<BadFor>? badFor,
    String? usedPart,
    int? energy,
    String? imageUrl,
    ClassificationType? classificationType,
    Taste? taste,
    bool? goodForDay,
    bool? isVegeterian,
    bool? goodForNight,
    bool? hasGluten,
    String? description,
    List<Actions>? actions,
    String? title,
    String? id,
    String? body,
  }) =>
      IngredientResult(
        nutrients: nutrients ?? this.nutrients,
        hasPurines: hasPurines ?? this.hasPurines,
        goodFor: goodFor ?? this.goodFor,
        ageGroup: ageGroup ?? this.ageGroup,
        regionalCommonFood: regionalCommonFood ?? this.regionalCommonFood,
        badFor: badFor ?? this.badFor,
        usedPart: usedPart ?? this.usedPart,
        energy: energy ?? this.energy,
        imageUrl: imageUrl ?? this.imageUrl,
        classificationType: classificationType ?? this.classificationType,
        taste: taste ?? this.taste,
        goodForDay: goodForDay ?? this.goodForDay,
        isVegeterian: isVegeterian ?? this.isVegeterian,
        goodForNight: goodForNight ?? this.goodForNight,
        hasGluten: hasGluten ?? this.hasGluten,
        description: description ?? this.description,
        actions: actions ?? this.actions,
        title: title ?? this.title,
        id: id ?? this.id,
        body: body ?? this.body,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (nutrients != null) {
      map['nutrients'] = nutrients?.map((v) => v.toJson()).toList();
    }
    map['has_purines'] = hasPurines;
    if (goodFor != null) {
      map['good_for'] = goodFor?.map((v) => v.toJson()).toList();
    }
    if (ageGroup != null) {
      map['age_group'] = ageGroup?.toJson();
    }
    if (regionalCommonFood != null) {
      map['regional_common_food'] = regionalCommonFood?.toJson();
    }
    if (badFor != null) {
      map['bad_for'] = badFor?.map((v) => v.toJson()).toList();
    }
    map['used_part'] = usedPart;
    map['energy'] = energy;
    map['image_url'] = imageUrl;
    if (classificationType != null) {
      map['classification_type'] = classificationType?.toJson();
    }
    if (taste != null) {
      map['taste'] = taste?.toJson();
    }
    map['good_for_day'] = goodForDay;
    map['is_vegeterian'] = isVegeterian;
    map['good_for_night'] = goodForNight;
    map['has_gluten'] = hasGluten;
    map['description'] = description;
    if (actions != null) {
      map['actions'] = actions?.map((v) => v.toJson()).toList();
    }
    map['title'] = title;
    map['id'] = id;
    map['body'] = body;
    return map;
  }
}

class Actions {
  Actions({
    this.actionId,
    this.title,
  });

  Actions.fromJson(dynamic json) {
    actionId = json['action_id'];
    title = json['title'];
  }
  String? actionId;
  String? title;
  Actions copyWith({
    String? actionId,
    String? title,
  }) =>
      Actions(
        actionId: actionId ?? this.actionId,
        title: title ?? this.title,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['action_id'] = actionId;
    map['title'] = title;
    return map;
  }
}

class Taste {
  Taste({
    this.tasteId,
    this.title,
  });

  Taste.fromJson(dynamic json) {
    tasteId = json['taste_id'];
    title = json['title'];
  }
  String? tasteId;
  String? title;
  Taste copyWith({
    String? tasteId,
    String? title,
  }) =>
      Taste(
        tasteId: tasteId ?? this.tasteId,
        title: title ?? this.title,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['taste_id'] = tasteId;
    map['title'] = title;
    return map;
  }
}

class ClassificationType {
  ClassificationType({
    this.title,
    this.classificationTypeId,
  });

  ClassificationType.fromJson(dynamic json) {
    title = json['title'];
    classificationTypeId = json['classification_type_id'];
  }
  String? title;
  String? classificationTypeId;
  ClassificationType copyWith({
    String? title,
    String? classificationTypeId,
  }) =>
      ClassificationType(
        title: title ?? this.title,
        classificationTypeId: classificationTypeId ?? this.classificationTypeId,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['classification_type_id'] = classificationTypeId;
    return map;
  }
}

class BadFor {
  BadFor({
    this.ingredientPropertyId,
    this.title,
  });

  BadFor.fromJson(dynamic json) {
    ingredientPropertyId = json['ingredient_property_id'];
    title = json['title'];
  }
  String? ingredientPropertyId;
  String? title;
  BadFor copyWith({
    String? ingredientPropertyId,
    String? title,
  }) =>
      BadFor(
        ingredientPropertyId: ingredientPropertyId ?? this.ingredientPropertyId,
        title: title ?? this.title,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['ingredient_property_id'] = ingredientPropertyId;
    map['title'] = title;
    return map;
  }
}

class RegionalCommonFood {
  RegionalCommonFood({
    this.countryId,
    this.title,
    this.countryCode,
  });

  RegionalCommonFood.fromJson(dynamic json) {
    countryId = json['country_id'];
    title = json['title'];
    countryCode = json['country_code'];
  }
  String? countryId;
  String? title;
  String? countryCode;
  RegionalCommonFood copyWith({
    String? countryId,
    String? title,
    String? countryCode,
  }) =>
      RegionalCommonFood(
        countryId: countryId ?? this.countryId,
        title: title ?? this.title,
        countryCode: countryCode ?? this.countryCode,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['country_id'] = countryId;
    map['title'] = title;
    map['country_code'] = countryCode;
    return map;
  }
}

class AgeGroup {
  AgeGroup({
    this.diapazone,
    this.ageGroupId,
  });

  AgeGroup.fromJson(dynamic json) {
    diapazone = json['diapazone'];
    ageGroupId = json['age_group_id'];
  }
  String? diapazone;
  String? ageGroupId;
  AgeGroup copyWith({
    String? diapazone,
    String? ageGroupId,
  }) =>
      AgeGroup(
        diapazone: diapazone ?? this.diapazone,
        ageGroupId: ageGroupId ?? this.ageGroupId,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['diapazone'] = diapazone;
    map['age_group_id'] = ageGroupId;
    return map;
  }
}

class GoodFor {
  GoodFor({
    this.ingredientPropertyId,
    this.title,
  });

  GoodFor.fromJson(dynamic json) {
    ingredientPropertyId = json['ingredient_property_id'];
    title = json['title'];
  }
  String? ingredientPropertyId;
  String? title;
  GoodFor copyWith({
    String? ingredientPropertyId,
    String? title,
  }) =>
      GoodFor(
        ingredientPropertyId: ingredientPropertyId ?? this.ingredientPropertyId,
        title: title ?? this.title,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['ingredient_property_id'] = ingredientPropertyId;
    map['title'] = title;
    return map;
  }
}

class Nutrient {
  Nutrient({
    this.title,
    this.nutrientId,
    this.unit,
    this.amount,
    this.nutrientType,
  });

  Nutrient.fromJson(dynamic json) {
    title = json['title'];
    nutrientId = json['nutrient_id'];
    unit = json['unit'];
    amount = json['amount'];
    nutrientType = json['nutrient_type'];
  }
  String? title;
  String? nutrientId;
  String? unit;
  double? amount;
  String? nutrientType;
  Nutrient copyWith({
    String? title,
    String? nutrientId,
    String? unit,
    double? amount,
    String? nutrientType,
  }) =>
      Nutrient(
        title: title ?? this.title,
        nutrientId: nutrientId ?? this.nutrientId,
        unit: unit ?? this.unit,
        amount: amount ?? this.amount,
        nutrientType: nutrientType ?? this.nutrientType,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['nutrient_id'] = nutrientId;
    map['unit'] = unit;
    map['amount'] = amount;
    map['nutrient_type'] = nutrientType;
    return map;
  }
}
