class UserAccessType {
  final String title;
  final bool isEnabled;

  UserAccessType({required this.title, required this.isEnabled});
}
