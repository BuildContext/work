import 'package:test_project/core/models/post.dart';
import 'package:test_project/core/models/quiz_option.dart';

import 'abstractions.dart';

class Quiz {
  final String colorHex;
  final String title;
  final List<ContentCategoryIcon> icons;
  final Duration time;
  final String description;
  final PostAuthor? author;
  final String type;
  final List<QuizOption> options;

  bool get hasAuthor => author != null;

  Quiz({
    required this.colorHex,
    required this.title,
    required this.icons,
    required this.time,
    required this.description,
    required this.type,
    required this.options,
    this.author,
  });
}
