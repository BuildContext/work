class ShoppingListItem {
  final String title;
  final int amount;
  final String measurementType;
  final bool isChecked;

  ShoppingListItem({
    required this.title,
    required this.amount,
    required this.measurementType,
    required this.isChecked,
  });
}
