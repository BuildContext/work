class UserPreference {
  final String title;
  final String iconPath;

  UserPreference({
    required this.title,
    required this.iconPath,
  });
}
