import 'abstractions.dart';

class PostAuthor {
  final String name;
  final String avatar;
  final String description;
  final String position;

  PostAuthor({
    required this.name,
    required this.avatar,
    required this.description,
    required this.position,
  });
}

class PostCategoryItem extends ContentCategoryItem {
  final String description;
  final bool isLiked;
  final String categoryName;
  final List<PostInstruction> instructions;
  final PostAuthor author;

  PostCategoryItem({
    required this.instructions,
    required this.author,
    required this.categoryName,
    required this.description,
    required this.isLiked,
    required String title,
    required String id,
    required Duration time,
    required List<ContentCategoryTag> goodFor,
    required List<ContentCategoryIcon> icons,
    required String imageLink,
  }) : super(id: id, title: title, categoryName: categoryName, time: time, goodFor: goodFor, icons: icons, imageLink: imageLink);

  PostCategoryItem copyWith({
    String? title,
    String? description,
    bool? isLiked,
    Duration? time,
    String? categoryName,
    List<ContentCategoryTag>? tags,
    List<ContentCategoryIcon>? icons,
    String? imageLink,
    List<PostInstruction>? instructions,
    PostAuthor? author,
    String? id,
  }) =>
      PostCategoryItem(
        id: id ?? this.id,
        title: title ?? this.title,
        categoryName: categoryName ?? this.categoryName,
        author: author ?? this.author,
        description: description ?? this.description,
        isLiked: isLiked ?? this.isLiked,
        time: time ?? this.time,
        instructions: instructions ?? this.instructions,
        goodFor: tags ?? this.goodFor,
        icons: icons ?? this.icons,
        imageLink: imageLink ?? this.imageLink,
      );
}

class PostInstruction {
  final List<ContentCategoryIcon> icons;
  final String title;
  final String imageLink;
  final Duration time;

  PostInstruction({
    required this.icons,
    required this.time,
    required this.title,
    required this.imageLink,
  });
}

class RecommendedReading {
  final String heading;
  final String description;
  final List<ContentCategoryIcon> icons;
  final bool isLiked;
  final String hexColor;

  RecommendedReading({
    required this.heading,
    required this.description,
    required this.icons,
    required this.isLiked,
    required this.hexColor,
  });
}
