import 'package:charts_flutter/flutter.dart' as charts;
import 'package:flutter/material.dart';

abstract class AyulifeChartDataModel {
  final String title;
  final int value;
  final charts.Color color;

  AyulifeChartDataModel({
    required this.title,
    required this.value,
    required Color color,
  }) : this.color = charts.Color(
          r: color.red,
          g: color.green,
          b: color.blue,
          a: color.alpha,
        );

  Color get dartColor => Color.fromARGB(color.a, color.r, color.g, color.b);
}
