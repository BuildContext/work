import 'dart:ui';

class CustomPieChartDataItem {
  final String title;
  final int value;
  final Color color;

  CustomPieChartDataItem({
    required this.title,
    required this.value,
    required this.color,
  });
}
