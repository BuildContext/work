import 'dart:ui';

import 'package:test_project/core/models/chart_models/ayulife_chart_data_model.dart';

class DoshaBalanceData extends AyulifeChartDataModel {
  DoshaBalanceData({
    required String title,
    required int percentage,
    required Color color,
  }) : super(
          title: title,
          value: percentage,
          color: color,
        );
}
