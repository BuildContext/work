import 'dart:ui';

import 'package:test_project/core/models/chart_models/ayulife_chart_data_model.dart';

class UserBalanceChartData extends AyulifeChartDataModel {
  final int numberOfEvents;
  final DateTime date;

  UserBalanceChartData({
    required String title,
    this.numberOfEvents = 3,
    required this.date,
    required int value,
    required Color color,
  }) : super(
          title: title,
          value: value,
          color: color,
        );
}
