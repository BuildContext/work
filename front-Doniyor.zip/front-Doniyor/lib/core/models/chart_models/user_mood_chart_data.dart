import 'dart:ui';

import 'package:test_project/core/models/chart_models/ayulife_chart_data_model.dart';

class UserMoodChartData extends AyulifeChartDataModel {
  final String data;
  UserMoodChartData({
    required this.data,
    required String title,
    required int value,
    required Color color,
  }) : super(
          title: title,
          value: value,
          color: color,
        );
}
