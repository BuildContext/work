import 'dart:ui';

class CustomProfileChartDataItem {
  final DateTime date;
  final int value;
  final Color color;

  CustomProfileChartDataItem({
    required this.date,
    required this.value,
    required this.color,
  });
}

class CustomProfileChartDataSeries {
  final List<CustomProfileChartDataItem> items;
  final Color highlightColor;
  final String title;

  CustomProfileChartDataSeries({
    required this.title,
    required this.items,
    required this.highlightColor,
  });
}
