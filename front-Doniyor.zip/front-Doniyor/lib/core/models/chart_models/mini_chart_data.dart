import 'dart:ui';

class MiniChartDataItem {
  final double percentage;
  final Color color;

  MiniChartDataItem({
    required this.color,
    required this.percentage,
  });
}

class MiniChartDataSeries {
  final List<MiniChartDataItem> items;

  MiniChartDataSeries({required this.items});
}
