class UserProfileData {
  final String name;
  final String surname;
  final String phone;
  final String email;
  final int age;
  final String gender;
  final String nationality;
  final String country;
  final int height;
  final int weight;
  final DateTime birthDay;

  UserProfileData({
    required this.name,
    required this.surname,
    required this.phone,
    required this.email,
    required this.age,
    required this.gender,
    required this.nationality,
    required this.country,
    required this.height,
    required this.weight,
    required this.birthDay,
  });
}
