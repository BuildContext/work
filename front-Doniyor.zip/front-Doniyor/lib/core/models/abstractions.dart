class ContentCategory {
  final String categoryName;
  final List<ContentCategory> subcategoryItems;
  final List<ContentCategoryItem> items;

  ContentCategory({
    this.subcategoryItems = const [],
    required this.categoryName,
    required this.items,
  });
}

class ContentCategoryItem {
  final String title;
  final String categoryName;
  final String id;
  final Duration time;
  final List<ContentCategoryTag> goodFor;
  final List<ContentCategoryIcon> icons;
  final String imageLink;

  ContentCategoryItem({
    required this.id,
    required this.categoryName,
    required this.title,
    required this.time,
    required this.goodFor,
    required this.icons,
    required this.imageLink,
  });
}

class ContentCategoryTag {
  final String title;
  final String? iconLink;

  ContentCategoryTag({required this.title, this.iconLink});
}

class ContentCategoryIcon {
  final String iconPath;
  final bool isLocal;

  ContentCategoryIcon({
    required this.iconPath,
    required this.isLocal,
  });
}

class FoodElement {
  final String id;
  final String title;
  final String measurementType;
  final double amount;
  final bool isChecked;

  FoodElement({
    this.id = '',
    required this.title,
    required this.measurementType,
    required this.amount,
    this.isChecked = false,
  });

  FoodElement copyWith({
    String? title,
    String? measurementType,
    double? amount,
    bool? isChecked,
  }) =>
      FoodElement(
        title: title ?? this.title,
        measurementType: measurementType ?? this.measurementType,
        amount: amount ?? this.amount,
        isChecked: isChecked ?? this.isChecked,
      );

  bool isTheSameWithOther(FoodElement other) =>
      this.title == other.title && this.measurementType == other.measurementType && this.amount == other.amount;
}
