class NotificationType {
  final String title;
  final bool isEnabled;

  NotificationType({
    required this.title,
    required this.isEnabled,
  });
}
