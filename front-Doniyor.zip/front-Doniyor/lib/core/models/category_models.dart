import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/ingredient.dart';
import 'package:test_project/core/models/post.dart';
import 'package:test_project/core/models/recipe_category_item.dart';

class PostCategory extends ContentCategory {
  final List<PostCategoryItem> items;

  PostCategory({
    required String name,
    required this.items,
    required List<PostCategory> subCategories,
  }) : super(
          categoryName: name,
          items: items,
          subcategoryItems: subCategories,
        );
}

class RecipeCategory extends ContentCategory {
  final List<RecipeCategoryItem> items;

  RecipeCategory({
    required String name,
    required this.items,
    required List<RecipeCategory> subCategories,
  }) : super(
          categoryName: name,
          items: items,
          subcategoryItems: subCategories,
        );
}

class IngredientCategory {
  final List<IngredientResult> items;
  final String categoryName;

  IngredientCategory({
    required this.categoryName,
    required this.items,
  });
}
