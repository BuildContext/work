class UserSubscriptionData {
  final String serviceName;
  final DateTime nextPaymentDate;
  final double price;
  final DateTime lastPaidDate;

  UserSubscriptionData({
    required this.serviceName,
    required this.lastPaidDate,
    required this.nextPaymentDate,
    required this.price,
  });
}
