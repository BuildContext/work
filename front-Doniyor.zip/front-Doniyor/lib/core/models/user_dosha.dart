class UserDosha {
  final int vataPercentage;
  final int pittaPercentage;

  UserDosha({
    required this.vataPercentage,
    required this.pittaPercentage,
  });
}
