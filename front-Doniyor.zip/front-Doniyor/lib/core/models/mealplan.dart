import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:test_project/core/models/abstractions.dart';
import 'package:test_project/core/models/category_models.dart';
import 'package:test_project/core/models/recipe_category_item.dart';

class MealPlan {
  final RecipeCategory breakfast;
  final RecipeCategory lunch;
  final RecipeCategory snack;
  final RecipeCategory dinner;

  MealPlan({
    required this.breakfast,
    required this.lunch,
    required this.snack,
    required this.dinner,
  });

  Future<List<FoodElement>> getShoppingListFromMealplan() async {
    final breakfastList = await compute<List<RecipeCategoryItem>, List<FoodElement>>(_getElements, breakfast.items);
    final lunchList = await compute<List<RecipeCategoryItem>, List<FoodElement>>(_getElements, lunch.items);
    final snackList = await compute<List<RecipeCategoryItem>, List<FoodElement>>(_getElements, snack.items);
    final dinnerList = await compute<List<RecipeCategoryItem>, List<FoodElement>>(_getElements, dinner.items);

    return [...breakfastList, ...lunchList, ...snackList, ...dinnerList];
  }
}

List<FoodElement> _getElements(List<RecipeCategoryItem> item) {
  List<FoodElement> finalList = List.empty(growable: true);
  item.forEach((outerElement) {
    outerElement.secondaryIngredients.forEach((innerElement) {
      finalList.add(innerElement);
    });
    outerElement.primaryIngredients.forEach((innerElement) {
      finalList.add(innerElement);
    });
  });
  return finalList;
}

// List<FoodElement> _mergedElements(List<FoodElement> elements) {
//   List<FoodElement> finalList = [];
//   for (int i = 0; i < elements.length; i++) {
//
//   }
// }
