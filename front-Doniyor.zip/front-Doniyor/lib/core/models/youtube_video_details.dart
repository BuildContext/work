class YoutubeVideoDetails {
  YoutubeVideoDetails({
    this.title,
    this.authorName,
    this.authorUrl,
    this.type,
    this.height,
    this.width,
    this.version,
    this.providerName,
    this.providerUrl,
    this.thumbnailHeight,
    this.thumbnailWidth,
    this.thumbnailUrl,
    this.html,
  });

  YoutubeVideoDetails.fromJson(dynamic json) {
    title = json['title'];
    authorName = json['author_name'];
    authorUrl = json['author_url'];
    type = json['type'];
    height = json['height'];
    width = json['width'];
    version = json['version'];
    providerName = json['provider_name'];
    providerUrl = json['provider_url'];
    thumbnailHeight = json['thumbnail_height'];
    thumbnailWidth = json['thumbnail_width'];
    thumbnailUrl = json['thumbnail_url'];
    html = json['html'];
  }
  String? title;
  String? authorName;
  String? authorUrl;
  String? type;
  int? height;
  int? width;
  String? version;
  String? providerName;
  String? providerUrl;
  int? thumbnailHeight;
  int? thumbnailWidth;
  String? thumbnailUrl;
  String? html;
  YoutubeVideoDetails copyWith({
    String? title,
    String? authorName,
    String? authorUrl,
    String? type,
    int? height,
    int? width,
    String? version,
    String? providerName,
    String? providerUrl,
    int? thumbnailHeight,
    int? thumbnailWidth,
    String? thumbnailUrl,
    String? html,
  }) =>
      YoutubeVideoDetails(
        title: title ?? this.title,
        authorName: authorName ?? this.authorName,
        authorUrl: authorUrl ?? this.authorUrl,
        type: type ?? this.type,
        height: height ?? this.height,
        width: width ?? this.width,
        version: version ?? this.version,
        providerName: providerName ?? this.providerName,
        providerUrl: providerUrl ?? this.providerUrl,
        thumbnailHeight: thumbnailHeight ?? this.thumbnailHeight,
        thumbnailWidth: thumbnailWidth ?? this.thumbnailWidth,
        thumbnailUrl: thumbnailUrl ?? this.thumbnailUrl,
        html: html ?? this.html,
      );
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['title'] = title;
    map['author_name'] = authorName;
    map['author_url'] = authorUrl;
    map['type'] = type;
    map['height'] = height;
    map['width'] = width;
    map['version'] = version;
    map['provider_name'] = providerName;
    map['provider_url'] = providerUrl;
    map['thumbnail_height'] = thumbnailHeight;
    map['thumbnail_width'] = thumbnailWidth;
    map['thumbnail_url'] = thumbnailUrl;
    map['html'] = html;
    return map;
  }
}
